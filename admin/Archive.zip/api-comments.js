'use strict';
console.log('Loading function');
console.log('Loading function continue');

/* Import Libraries */
var mysql = require('mysql');
var uuid  = require('uuid');
var randomstring = require("randomstring");
var validator = require('validator');

var stringz = require('stringz');


 console.log('Loaded main functions');

var AWS = require("aws-sdk");

 console.log('Loaded function aws sdk');




var accessKey = process.env.ACCESS_KEY;       
var secretKey = process.env.SECREY_KEY;

 console.log('accessKey: ' + accessKey);
 console.log('secretKey: ' + secretKey);
 console.log('');
console.log('');
console.log('');

var s3 = new AWS.S3({ apiVersion: '2006-03-01',
                     accessKeyId: 'AKIAJHK65DH7FA25B4VA',    
                     secretAccessKey: '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'    
                     });

 console.log('Loaded function AWS S3');

var gm = require('gm')            
    .subClass({ imageMagick: true }); // Enable ImageMagick integration.



 console.log('Loaded function imageMagick');


var APP_NAME  = "Dromo";
var MAX_CHARACTER_LENGTH = 30;
var ALLOW_MORE_THAN_ONE_ACCOUNT = false;

var ALBUM_BUCKET = "dromo-albums";
var ALBUM_BUCKET_PRIVATE = "dromo-albums-private";
var ALBUM_BUCKET_PUBLIC  = "dromo-albums-public";

// var ALBUM_COVER_BUCKET = "dromo-albums-cover";
var PRIVATE_TEMP_BUCKET = "dromo-albums-tmp";


let kOpenPublicAlbum       = "OpenPublicAlbum";
let kOpenPrivateAlbum      = "OpenPrivateAlbum";
let kDidViewMedia          = "DidViewMedia";




let kGuid       = "guid";
let kAcctId     = "acctId";
let kGender     = "gender";
let kUserName   = "userName";
let kFirstName  = "firstName";
let kLastName   = "lastName";
let kFullName   = "fullName";
let kVerified   = "verified";
let kCity       = "city";
let kState      = "state";
let kCountry    = "country";
let kAbout      = "about";
let kDomain     = "domain";
let kUserPhoto  = "userPhoto";

let kAlbumId    = "albumId";
let kType       = "type";

let kTimestamp  = "timestamp";
let kDate       = "date";


let kErrorMessage   = "errorMessage";
let kSuccess        = "success";
let kActive         = "active";

let kTitle           = "title";
let kCreateDate      = "createDate";
let kExpireDate      = "expireDate";


let kThumbnail              = "thumbnail";
let kAlbumCover             = "albumCover";
let kNewestMediaTimestamp   = "newestTimestamp";
// let kNewestMediaUrl         = "newestUrl";

let kCount = "count";




let kIsGroupAlbum               = "isGroupAlbum";
let kGroupSelectedFollowers     = "groupSelectedFollowers";
let kIsAllSelectedForGroupAlbum = "isAllSelectedForGroupAlbum";



console.log('Loading function 3');
//TODO: Get OpenUserAlbums
        // 2) Insert into only open albums

let kLastViewedMediaUrl         = "lastUrl";
let kLastViewedMediaTimestamp   = "lastTimestamp";

let kProfileUrl = "profileUrl";


       

let kLikeCount = "likeCount";
let kDislikeCount = "dislikeCount";
       

let kViews = "views";
let kExplicit = "explicit";

let kExplicitOverride = "explicitOverride"; // Administration overrides the explicit nature of content


let kAllowFollowersView     =  "allowFollowersView";
let kAllowFollowingsView    =  "allowFollowingsView";


let kBookmarked  = "BookmarkAlbum"
let kUnbookmarked = "UnbookmarkAlbum"




var ErrorMessageGeneric = APP_NAME + " is having some problems. Try again shortly.";
//APP_NAME + " is experiencing problems. Try again shortly";



// Helper function used to validate input
function invalidCharacters(username) {
    var regexp = /^[a-zA-Z0-9-_.]+$/;
    if ( regexp.test(username) ) { 
        return false;
    }
    return true;
}
     

function isInvalidUsername(username) {
    if (username === undefined || username === null ||  username.length < 1 || username === "") {
        return "Please enter a username";
    }
    if (username.length > MAX_CHARACTER_LENGTH) {
        return "Username is too long. It can be at most " + MAX_CHARACTER_LENGTH + " characters long.";  
    }
    
    if ( invalidCharacters(username) ){
        return "Username can only have letters, numbers, and ._-";  
    }        
}


 console.log('Loading function 4');


function printError(err) {
    console.log(err);
    console.error('Error Stack is: ' + err.stack);


    // console.log('Error is :', JSON.stringify(err, null, 2));
    // console.log('Error is :', JSON.stringify(err.code, null, 2));
    // console.log('Error Message :', err.errorMessage);
                                    
    // console.error('Error Stack stringify: ' + JSON.stringify(err.stack, null, 2));
}

console.log('creating connection');

var connection = mysql.createConnection({
    host     : 'mysqldromotest.cyoa59avdmjr.us-east-1.rds.amazonaws.com',
    user     : 'hannyalybear',
    password : 'SummerIsNearAndYellow1',
    database : 'dromotestmysqldb',
    charset  : 'utf8mb4_unicode_ci' 
});


var Relationship = {
    Unknown               : 0,
    NoneExist             : 1,
    FollowRequested       : 2,        
    IsFollowing           : 3,   
    // BlockedUser           : 4,
    CanceledFollowRequest : 5
};

// var Relationships = {
//     SentFriendRequest       : "SFR",        //S
//     ReceivedFriendRequest   : "RFR",//  - R 
//     AcceptedFriendRequest   : "AFR",//  - A"
//     FriendAcceptedRequest   : "RFRA", // FAR // - F      
//     CanceledFriendRequest   : "CFR" //  - C
// };

var UpdateAction = {
    Friends  : "Friends",
    Title    : "Title"
};

var MediaType = {
    Video: "video",
    Photo: "photo",
    Gif: "gif"
}


var ActiveValues = {
    Active            : 0,
    Unknown           : 1,   
    DoesNotExist      : 2,   // Company suspended
    Deleted           : 3,   // User deleted 
    Disabled          : 4,   // User disbaled??
    DisabledConfirmed : 5,   // Company suspended
};
 console.log('Loading function 5');


let SECONDS_IN_MINUTE = 60; 
let MINUTES_IN_HOUR = 60;   // 3,600
let HOURS_IN_DAY = 24;      // 86,400
let NUMBER_OF_DAYS = 7;     // 172,800

let S3_EXPIRE_LIMIT =  SECONDS_IN_MINUTE * MINUTES_IN_HOUR * HOURS_IN_DAY * NUMBER_OF_DAYS;
 // 1 day = 86400
 // 172 800 = 48 hours
// let S3_EXPIRE_LIMIT                 = 6*86400;  // 24 hours  1440 minutes, 8640 = 6 days, 10080, 7 days



function generateRandomString() {
    return randomstring.generate({
        length: 12,
        charset: 'alphanumeric'
    });
}

function generateRandomURL() {
    return generateRandomString() ; // + mediaExtension(type);
}

function bytesToMb(bytes) {
    return bytes/ (1024 * 1024);
}

function isImageBelowSizeThreshold(mbSize) {

    if (mbSize < 10) {
        return true;
    }
    return false;
}


function isVideoBelowSizeThreshold(mbSize) {
    // Be on the safe side
    if (mbSize < 200) { // == 30 seconds @ 60 fps 1080 HD ~ 100 MB
        return true;
    }
    return false;
}


function mediaExtension(type) {
    
    switch (type) {
        case MediaType.Photo:
            return ".jpg";
        case MediaType.Video:
            return ".mp4";
        case MediaType.Gif:
            return ".gif";
    }
}

function contentType(type) {
    
    switch (type) {
        case MediaType.Photo:
            return 'image/jpeg';
        case MediaType.Video:
            return "video/mp4";
        case MediaType.Gif:
            return "image/gif";
    }
}



 console.log('Loading function 6');


// Multiple albums may have access to this content
function albumMediaKey(guid, mediaUrl, mediaContentType) {
    return guid + "/media/" + mediaKeyWithExtension(mediaUrl, mediaContentType);
}


// Multiple albums may have access to this content
function albumCoverKey(guid, mediaUrl) {
    return guid + "/cover/" + mediaKeyWithExtension(mediaUrl, MediaType.Photo);
}


// Multiple albums may have access to this content
function albumCoverThumbnailKey(guid, mediaUrl) {
    return guid + "/thumb/" + mediaKeyWithExtension(mediaUrl, MediaType.Photo);
}


// Multiple albums may have access to this content
function albumFirstMediaKey(guid, mediaUrl) {
    return guid + "/media/" + mediaUrl;
}


 function mediaKeyWithExtension(mediaKey, mediaContentType) {
     return mediaKey + mediaExtension(mediaContentType);
 }



var Messages = {
    AlbumGone: "This album seems to have disappeared"
}



let kIsRefreshing       = "isRefreshing";
let kLastAlbumIsNew     = "isNew";
let kIndex              = "index";
let kNewSecion      = "newSection"




let kMedia      = "media";
let kMediaURL   = "mediaUrl";
let kFGuid      = "fguid"
let kTimelimit  = "timelimit";

let kSignedUrl =  "signedUrl";


let kNumberOfItems = "numberOfItems";


// let kFriends = "friends";
 let kInclusive = "isInclusive"


let kAlbumIds   = "albumIds";

let kTmpMediaKey = "tmpMediaKey";
let kTmpCoverKey = "tmpCoverKey"





let MAX_NUM_OF_ALBUMS = 5;
let MAX_NUM_OF_CONTENT = 10;


/***
 * 
 *      App response code
 * 
 */

let kProfile = "profile";
let kAlbum = "album";
let kAlbums = "albums";

console.log('Loading function 7');

function albumsResponse( albums) {
    var response = {};
    response[kActive] = ActiveValues.Active;
    response[kAlbums] = albums; 
    return response
}


function mediaResponse( album) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kAlbum]   = album; 
    return response
}


// dont need error message for this
function updateViewResponse(success) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kSuccess] = success; 
    return response;
}



function bookmarkResponse(bookMarked) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kSuccess] = bookMarked ? 1 : 0; 
    return response;
}



function getAlbumsResponse( albums) {
    var response = {}
    response[kActive]  = ActiveValues.Active;
    response[kAlbums]  = albums;
    return response;
}

function createAlbumResponse( albumId) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kAlbumId] = albumId;
    response[kSuccess] = true; 
    return response;
}


function uploadMediaResponse( mediaKey, signedUrl, timestamp) {
    var response = {};
    response[kTimestamp] = timestamp;
    response[kActive]    = ActiveValues.Active;
    response[kMediaURL]  = mediaKey; 
    response[kSignedUrl] = signedUrl; 
    return response;
}


function activeResponse(activeStatus, errorMessage) {
    var response = {};
    response[kActive]       = activeStatus;
    response[kErrorMessage] = errorMessage;
    return response;
}

function errorResponse(errorMessage) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kErrorMessage] = errorMessage;
    return response;
}
 console.log('Loading function 8');


function activeErrorMessage(activeValue) {

    var errorMessage;
    switch (activeValue) {
        case ActiveValues.Unknown:
            errorMessage = "You are not logged in";
            break;
        case ActiveValues.DoesNotExist:
            errorMessage = "This account does not exist";
            break;
        case ActiveValues.Deleted:
            errorMessage = "This account does not exist";
            break;
        case ActiveValues.Disabled:
            errorMessage = "This account has been disbaled"
            break;
        case ActiveValues.DisabledConfirmed:
            errorMessage = "This account has been disbaled"
            break;
        default:
            errorMessage = ErrorMessageGeneric
            break;
    }
    return errorMessage;
}


// var GatewayPaths = {
//     // ListMyAlbums: "/albums/private/me",
//     // UserAlbums : "/albums/private/friend/album"
//     // OpenUserAlbums : "/albums/private/friend/album"
//     // FriendsAlbums : "/albums/private/friend/album"
//     // FriendsAlbums : "/albums/private/friend/album"
//     // FriendsAlbums : "/albums/private/friend/album"
// };


let kPrivate = "private";



/*

    Shell Command: 
cd comments; ./compress.sh api-comments Rail-Comment-mobilehub-1247959479; cd ..

./compress.sh api-comments Rail-Comment-mobilehub-1247959479


*/


/**
 * 
 * 
 *  Under search screen
 * 
 *      Search by:  
*                  Username, 
*                  Album Title, 
*                  events, 
*                  location: (town, city) New Brunswick, NJ or  Rutgers University (New Brunswick)
*                  place: Rutgers University (New Brunswick), Times Square, Tieman Square
 * 
 *      
 *          Disovery
 *              Trending/Popular
 *              Local
 *              Events
 *              
 * 
 * 
 *      Query parameters: popularity as clicked per search term
 * 
 *          Username, location, place : By popularity
 *          Album title and events: By likes 
 * 
 * 
 *          Disovery parameters: : By likes and paid sponsorships
 * 
 *          Local: Local businesses
 *          Events: Global event like star wars premier
 * 
 * 
 * 
 *      How to get random 40 items
 *        
 *          Trending/Popular
 * 
 *      SELECT *
 *      FROM popular_albums
 *      WHERE likes = ?  AND views = ? 
 *      
 * 
 * 
 * 
 * 
 */


let kExpireDays = "expire";
var DEFAULT_DAYS_TO_EXPIRE = 2;

let kStartWithUnseen       = "StartWithNew";
let kPreviousItems          = "PreviousItems"

let kFirstUrl = "firstUrl";
let kSignedFirstUrl = "signedFirstUrl";




    function isStringWithLength(word) {
        return typeof word === 'string' && word.length > 0;
    }

    // function isNumber(number) {
    //     return typeof number === 'number';
    // }
    function isNumber (o) {
        return ! isNaN (o-0) && o !== null && o !== "" && o !== false;
    }

    function isInt(value) {
        if (isNaN(value)) {
            return false;
        }
        var x = parseFloat(value);
        return (x | 0) === x;
    }




let kFollowersListAdd  = "followersToAdd";
let kFollowersListRemove = "followersToRemove";

        /**
         * 
         *  Used when the app is in Low Celluar/ Use less Data Mode
         * 
         *  This function will be called by the user when they click on an album.
         * 
         */

console.log('Loading function 9');

exports.handler = (event, context, callback) => {
    var responseCode = 200;
    var requestBody, pathParams, queryStringParams, headerParams, stage,
    stageVariables, cognitoIdentityId, httpMethod, sourceIp, userAgent,
    requestId, resourcePath;
    console.log("request: " + JSON.stringify(event));

    // Request Body
    requestBody = JSON.parse(event.body);

    // if (requestBody !== undefined && requestBody !== null) {

    //     // Set 'test-status' field in the request to test sending a specific response status code (e.g., 503)
    //     // responseCode = JSON.parse(requestBody)['test-status'];
    //     console.log("responseCode: " + responseCode);
    // }

    // Path Parameters
    pathParams = event.path;
    console.log("pathParams: " + pathParams);

    // Query String Parameters
    queryStringParams = event.queryStringParameters;
    console.log("queryStringParams: " + queryStringParams);

    // Header Parameters
    headerParams = event.headers;
    console.log("headerParams: " + headerParams);

    if (event.requestContext !== null && event.requestContext !== undefined) {

        var requestContext = event.requestContext;
        console.log("requestContext: " + requestContext);

        // API Gateway Stage
        stage = requestContext.stage;
        console.log("API Gateway Stage: " + stage);

        // Unique Request ID
        requestId = requestContext.requestId;
        console.log("Unique Request ID: " + requestId);

        // Resource Path
        resourcePath = requestContext.resourcePath;
        console.log("Resource Path: " + resourcePath);

        var identity = requestContext.identity;
        console.log("identity: " + identity);

        // Amazon Cognito User Identity
        cognitoIdentityId = identity.cognitoIdentityId;
        console.log("Amazon Cognito User Identity: " + cognitoIdentityId);

        // Source IP
        sourceIp = identity.sourceIp;
        console.log("Source IP: " + sourceIp);

        // User-Agent
        userAgent = identity.userAgent;
        console.log("User-Agent: " + userAgent);

    }

    // API Gateway Stage Variables
    stageVariables = event.stageVariables;

    // HTTP Method (e.g., POST, GET, HEAD)
    httpMethod = event.httpMethod;
    console.log("HTTP Method: " + httpMethod);




    // TODO: Put your application logic here...

    context.callbackWaitsForEmptyEventLoop = false;


 console.log('accessKey: ' + accessKey);
 console.log('secretKey: ' + secretKey);


    function finalAppResponse( responseBody) {
        console.log("responseBody: " + JSON.stringify(responseBody));

        var response = {
            statusCode: responseCode,
            headers: {
                "x-custom-header" : "custom header value"
            },
            body: JSON.stringify(responseBody)
        };
        console.log("response: " + JSON.stringify(response));
        callback( null, response);
    } 




 
    let errorMessageDeleteAlbum = APP_NAME + " cannot delete album this album at this time. Try again shortly.";

    function uploadErrorMessage() {

        if (isStringWithLength(mediaContentType) && (mediaContentType === MediaType.Photo || mediaContentType === MediaType.Video)) {
            return APP_NAME + " cannot upload your " + mediaContentType + " at this time. Try again shortly.";
        } else {
            return APP_NAME + " cannot upload your content at this time. Try again shortly.";
        }
    }

    


    // Rollback on failure
    function rollbackAppError(message) {
        var response = {};
        response[kActive]       = ActiveValues.Active;
        response[kErrorMessage] = message;
        
        connection.rollback(function() { 
            finalAppResponse( response);
        }); 
    }

    function commitTransaction(albumId) {

        // Commit queries
        connection.commit(function(err) {
            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else  {
                console.log('successful commit!');
                
                var response = {};
                response[kActive]  = ActiveValues.Active;
                response[kAlbumId] = albumId;
                response[kSuccess] = true;
                finalAppResponse( response);
            }
        });
    }







    console.log('Received event:', JSON.stringify(event, null, 2));
    console.log('Request body:', JSON.stringify(requestBody, null, 2));
    

    // Parameters

    var userId      = cognitoIdentityId;    
    var acctId      = requestBody[kAcctId];
    


    var guid        = requestBody[kGuid];
    var albumId     = requestBody[kAlbumId];
    var fguid       = requestBody[kFGuid];




    function queryLoggedInUser() {
        
        connection.query({
            sql: 'SELECT `guid`, `active` FROM `users` WHERE `id` = ? AND `acctid` = ?', 
            values: [userId, acctId]
        }, function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results && results.length > 0) {
                console.log('Results:', JSON.stringify(results, null, 2));

                console.log('User exists, returning current info');

                if ( results[0].active != ActiveValues.Active ) {
                    finalAppResponse( activeResponse( results[0].active, activeErrorMessage( results[0].active )));
                    return;
                }
                
                var guid = results[0].guid;

                
                var response = {};
                response[kActive]  = ActiveValues.Active;
                response[kErrorMessage] = errorMessage;
                response[kGuid] = guid;

                finalAppResponse( response ); 
                
            } else {
                finalAppResponse( activeResponse(ActiveValues.DoesNotExist, activeErrorMessage(ActiveValues.DoesNotExist) ));
            }
         });
    }

    queryLoggedInUser();
}