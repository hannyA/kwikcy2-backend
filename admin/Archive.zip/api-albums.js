'use strict';
console.log('Loading function');
console.log('Loading function continue');

/* Import Libraries */
var mysql = require('mysql');
var uuid  = require('uuid');
var randomstring = require("randomstring");
var validator = require('validator');

var stringz = require('stringz');


 console.log('Loaded main functions');

var AWS = require("aws-sdk");

 console.log('Loaded function aws sdk');




var accessKey = process.env.ACCESS_KEY;       
var secretKey = process.env.SECREY_KEY;

 console.log('accessKey: ' + accessKey);
 console.log('secretKey: ' + secretKey);
 console.log('');
console.log('');
console.log('');

var s3 = new AWS.S3({ apiVersion: '2006-03-01',
                     accessKeyId: 'AKIAJHK65DH7FA25B4VA',    
                     secretAccessKey: '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'    
                     });

 console.log('Loaded function AWS S3');

var gm = require('gm')            
    .subClass({ imageMagick: true }); // Enable ImageMagick integration.



 console.log('Loaded function imageMagick');


var APP_NAME  = "Dromo";
var MAX_CHARACTER_LENGTH = 30;
var ALLOW_MORE_THAN_ONE_ACCOUNT = false;

var ALBUM_BUCKET = "dromo-albums";
var ALBUM_BUCKET_PRIVATE = "dromo-albums-private";
var ALBUM_BUCKET_PUBLIC  = "dromo-albums-public";

// var ALBUM_COVER_BUCKET = "dromo-albums-cover";
var PRIVATE_TEMP_BUCKET = "dromo-albums-tmp";


let kOpenPublicAlbum       = "OpenPublicAlbum";
let kOpenPrivateAlbum      = "OpenPrivateAlbum";
let kDidViewMedia          = "DidViewMedia";




let kGuid       = "guid";
let kAcctId     = "acctId";
let kGender     = "gender";
let kUserName   = "userName";
let kFirstName  = "firstName";
let kLastName   = "lastName";
let kFullName   = "fullName";
let kVerified   = "verified";
let kCity       = "city";
let kState      = "state";
let kCountry    = "country";
let kAbout      = "about";
let kDomain     = "domain";
let kUserPhoto  = "userPhoto";

let kAlbumId    = "albumId";
let kType       = "type";

let kTimestamp  = "timestamp";
let kDate       = "date";


let kErrorMessage   = "errorMessage";
let kSuccess        = "success";
let kActive         = "active";

let kTitle           = "title";
let kCreateDate      = "createDate";
let kExpireDate      = "expireDate";


let kThumbnail              = "thumbnail";
let kAlbumCover             = "albumCover";
let kNewestMediaTimestamp   = "newestTimestamp";
// let kNewestMediaUrl         = "newestUrl";

let kCount = "count";




let kIsGroupAlbum               = "isGroupAlbum";
let kGroupSelectedFollowers     = "groupSelectedFollowers";
let kIsAllSelectedForGroupAlbum = "isAllSelectedForGroupAlbum";



console.log('Loading function 3');
//TODO: Get OpenUserAlbums
        // 2) Insert into only open albums

let kLastViewedMediaUrl         = "lastUrl";
let kLastViewedMediaTimestamp   = "lastTimestamp";

let kProfileUrl = "profileUrl";


       

let kLikeCount = "likeCount";
let kDislikeCount = "dislikeCount";
       

let kViews = "views";
let kExplicit = "explicit";

let kExplicitOverride = "explicitOverride"; // Administration overrides the explicit nature of content


let kAllowFollowersView     =  "allowFollowersView";
let kAllowFollowingsView    =  "allowFollowingsView";


let kBookmarked  = "BookmarkAlbum"
let kUnbookmarked = "UnbookmarkAlbum"




var ErrorMessageGeneric = APP_NAME + " is having some problems. Try again shortly.";
//APP_NAME + " is experiencing problems. Try again shortly";



// Helper function used to validate input
function invalidCharacters(username) {
    var regexp = /^[a-zA-Z0-9-_.]+$/;
    if ( regexp.test(username) ) { 
        return false;
    }
    return true;
}
     

function isInvalidUsername(username) {
    if (username === undefined || username === null ||  username.length < 1 || username === "") {
        return "Please enter a username";
    }
    if (username.length > MAX_CHARACTER_LENGTH) {
        return "Username is too long. It can be at most " + MAX_CHARACTER_LENGTH + " characters long.";  
    }
    
    if ( invalidCharacters(username) ){
        return "Username can only have letters, numbers, and ._-";  
    }        
}


 console.log('Loading function 4');


function printError(err) {
    console.log(err);
    console.error('Error Stack is: ' + err.stack);


    // console.log('Error is :', JSON.stringify(err, null, 2));
    // console.log('Error is :', JSON.stringify(err.code, null, 2));
    // console.log('Error Message :', err.errorMessage);
                                    
    // console.error('Error Stack stringify: ' + JSON.stringify(err.stack, null, 2));
}

console.log('creating connection');

var connection = mysql.createConnection({
    host     : 'mysqldromotest.cyoa59avdmjr.us-east-1.rds.amazonaws.com',
    user     : 'hannyalybear',
    password : 'SummerIsNearAndYellow1',
    database : 'dromotestmysqldb',
    charset  : 'utf8mb4_unicode_ci' 
});


var Relationship = {
    Unknown               : 0,
    NoneExist             : 1,
    FollowRequested       : 2,        
    IsFollowing           : 3,   
    // BlockedUser           : 4,
    CanceledFollowRequest : 5
};

// var Relationships = {
//     SentFriendRequest       : "SFR",        //S
//     ReceivedFriendRequest   : "RFR",//  - R 
//     AcceptedFriendRequest   : "AFR",//  - A"
//     FriendAcceptedRequest   : "RFRA", // FAR // - F      
//     CanceledFriendRequest   : "CFR" //  - C
// };

var UpdateAction = {
    Friends  : "Friends",
    Title    : "Title"
};

var MediaType = {
    Video: "video",
    Photo: "photo",
    Gif: "gif"
}


var ActiveValues = {
    Active            : 0,
    Unknown           : 1,   
    DoesNotExist      : 2,   // Company suspended
    Deleted           : 3,   // User deleted 
    Disabled          : 4,   // User disbaled??
    DisabledConfirmed : 5,   // Company suspended
};
 console.log('Loading function 5');


let SECONDS_IN_MINUTE = 60; 
let MINUTES_IN_HOUR = 60;   // 3,600
let HOURS_IN_DAY = 24;      // 86,400
let NUMBER_OF_DAYS = 7;     // 172,800

let S3_EXPIRE_LIMIT =  SECONDS_IN_MINUTE * MINUTES_IN_HOUR * HOURS_IN_DAY * NUMBER_OF_DAYS;
 // 1 day = 86400
 // 172 800 = 48 hours
// let S3_EXPIRE_LIMIT                 = 6*86400;  // 24 hours  1440 minutes, 8640 = 6 days, 10080, 7 days



function generateRandomString() {
    return randomstring.generate({
        length: 12,
        charset: 'alphanumeric'
    });
}

function generateRandomURL() {
    return generateRandomString() ; // + mediaExtension(type);
}

function bytesToMb(bytes) {
    return bytes/ (1024 * 1024);
}

function isImageBelowSizeThreshold(mbSize) {

    if (mbSize < 10) {
        return true;
    }
    return false;
}


function isVideoBelowSizeThreshold(mbSize) {
    // Be on the safe side
    if (mbSize < 200) { // == 30 seconds @ 60 fps 1080 HD ~ 100 MB
        return true;
    }
    return false;
}


function mediaExtension(type) {
    
    switch (type) {
        case MediaType.Photo:
            return ".jpg";
        case MediaType.Video:
            return ".mp4";
        case MediaType.Gif:
            return ".gif";
    }
}

function contentType(type) {
    
    switch (type) {
        case MediaType.Photo:
            return 'image/jpeg';
        case MediaType.Video:
            return "video/mp4";
        case MediaType.Gif:
            return "image/gif";
    }
}



 console.log('Loading function 6');


// Multiple albums may have access to this content
function albumMediaKey(guid, mediaUrl, mediaContentType) {
    return guid + "/media/" + mediaKeyWithExtension(mediaUrl, mediaContentType);
}


// Multiple albums may have access to this content
function albumCoverKey(guid, mediaUrl) {
    return guid + "/cover/" + mediaKeyWithExtension(mediaUrl, MediaType.Photo);
}


// Multiple albums may have access to this content
function albumCoverThumbnailKey(guid, mediaUrl) {
    return guid + "/thumb/" + mediaKeyWithExtension(mediaUrl, MediaType.Photo);
}


// Multiple albums may have access to this content
function albumFirstMediaKey(guid, mediaUrl) {
    return guid + "/media/" + mediaUrl;
}


 function mediaKeyWithExtension(mediaKey, mediaContentType) {
     return mediaKey + mediaExtension(mediaContentType);
 }



var Messages = {
    AlbumGone: "This album seems to have disappeared"
}



let kIsRefreshing       = "isRefreshing";
let kLastAlbumIsNew     = "isNew";
let kIndex              = "index";
let kNewSecion      = "newSection"




let kMedia      = "media";
let kMediaURL   = "mediaUrl";
let kFGuid      = "fguid"
let kTimelimit  = "timelimit";

let kSignedUrl =  "signedUrl";


let kNumberOfItems = "numberOfItems";


// let kFriends = "friends";
 let kInclusive = "isInclusive"


let kAlbumIds   = "albumIds";

let kTmpMediaKey = "tmpMediaKey";
let kTmpCoverKey = "tmpCoverKey"





let MAX_NUM_OF_ALBUMS = 5;
let MAX_NUM_OF_CONTENT = 10;


/***
 * 
 *      App response code
 * 
 */

let kProfile = "profile";
let kAlbum = "album";
let kAlbums = "albums";

console.log('Loading function 7');

function albumsResponse( albums) {
    var response = {};
    response[kActive] = ActiveValues.Active;
    response[kAlbums] = albums; 
    return response
}


function mediaResponse( album) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kAlbum]   = album; 
    return response
}


// dont need error message for this
function updateViewResponse(success) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kSuccess] = success; 
    return response;
}



function bookmarkResponse(bookMarked) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kSuccess] = bookMarked ? 1 : 0; 
    return response;
}



function getAlbumsResponse( albums) {
    var response = {}
    response[kActive]  = ActiveValues.Active;
    response[kAlbums]  = albums;
    return response;
}

function createAlbumResponse( albumId) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kAlbumId] = albumId;
    response[kSuccess] = true; 
    return response;
}


function uploadMediaResponse( mediaKey, signedUrl, timestamp) {
    var response = {};
    response[kTimestamp] = timestamp;
    response[kActive]    = ActiveValues.Active;
    response[kMediaURL]  = mediaKey; 
    response[kSignedUrl] = signedUrl; 
    return response;
}


function activeResponse(activeStatus, errorMessage) {
    var response = {};
    response[kActive]       = activeStatus;
    response[kErrorMessage] = errorMessage;
    return response;
}

function errorResponse(errorMessage) {
    var response = {};
    response[kActive]  = ActiveValues.Active;
    response[kErrorMessage] = errorMessage;
    return response;
}
 console.log('Loading function 8');


function activeErrorMessage(activeValue) {

    var errorMessage;
    switch (activeValue) {
        case ActiveValues.Unknown:
            errorMessage = "You are not logged in";
            break;
        case ActiveValues.DoesNotExist:
            errorMessage = "This account does not exist";
            break;
        case ActiveValues.Deleted:
            errorMessage = "This account does not exist";
            break;
        case ActiveValues.Disabled:
            errorMessage = "This account has been disbaled"
            break;
        case ActiveValues.DisabledConfirmed:
            errorMessage = "This account has been disbaled"
            break;
        default:
            errorMessage = ErrorMessageGeneric
            break;
    }
    return errorMessage;
}


// var GatewayPaths = {
//     // ListMyAlbums: "/albums/private/me",
//     // UserAlbums : "/albums/private/friend/album"
//     // OpenUserAlbums : "/albums/private/friend/album"
//     // FriendsAlbums : "/albums/private/friend/album"
//     // FriendsAlbums : "/albums/private/friend/album"
//     // FriendsAlbums : "/albums/private/friend/album"
// };


let kPrivate = "private";



/*

    Shell Command: 
cd albums; ./compress.sh api-albums Rail-PrivateAlbums-mobilehub-1247959479; cd ..

./compress.sh api-albums Rail-PrivateAlbums-mobilehub-1247959479


*/


/**
 * 
 * 
 *  Under search screen
 * 
 *      Search by:  
*                  Username, 
*                  Album Title, 
*                  events, 
*                  location: (town, city) New Brunswick, NJ or  Rutgers University (New Brunswick)
*                  place: Rutgers University (New Brunswick), Times Square, Tieman Square
 * 
 *      
 *          Disovery
 *              Trending/Popular
 *              Local
 *              Events
 *              
 * 
 * 
 *      Query parameters: popularity as clicked per search term
 * 
 *          Username, location, place : By popularity
 *          Album title and events: By likes 
 * 
 * 
 *          Disovery parameters: : By likes and paid sponsorships
 * 
 *          Local: Local businesses
 *          Events: Global event like star wars premier
 * 
 * 
 * 
 *      How to get random 40 items
 *        
 *          Trending/Popular
 * 
 *      SELECT *
 *      FROM popular_albums
 *      WHERE likes = ?  AND views = ? 
 *      
 * 
 * 
 * 
 * 
 */


let kExpireDays = "expire";
var DEFAULT_DAYS_TO_EXPIRE = 2;

let kStartWithUnseen       = "StartWithNew";
let kPreviousItems          = "PreviousItems"

let kFirstUrl = "firstUrl";
let kSignedFirstUrl = "signedFirstUrl";




    function isStringWithLength(word) {
        return typeof word === 'string' && word.length > 0;
    }

    // function isNumber(number) {
    //     return typeof number === 'number';
    // }
    function isNumber (o) {
        return ! isNaN (o-0) && o !== null && o !== "" && o !== false;
    }

    function isInt(value) {
        if (isNaN(value)) {
            return false;
        }
        var x = parseFloat(value);
        return (x | 0) === x;
    }




let kFollowersListAdd  = "followersToAdd";
let kFollowersListRemove = "followersToRemove";

        /**
         * 
         *  Used when the app is in Low Celluar/ Use less Data Mode
         * 
         *  This function will be called by the user when they click on an album.
         * 
         */

console.log('Loading function 9');

exports.handler = (event, context, callback) => {
    var responseCode = 200;
    var requestBody, pathParams, queryStringParams, headerParams, stage,
    stageVariables, cognitoIdentityId, httpMethod, sourceIp, userAgent,
    requestId, resourcePath;
    console.log("request: " + JSON.stringify(event));

    // Request Body
    requestBody = JSON.parse(event.body);

    // if (requestBody !== undefined && requestBody !== null) {

    //     // Set 'test-status' field in the request to test sending a specific response status code (e.g., 503)
    //     // responseCode = JSON.parse(requestBody)['test-status'];
    //     console.log("responseCode: " + responseCode);
    // }

    // Path Parameters
    pathParams = event.path;
    console.log("pathParams: " + pathParams);

    // Query String Parameters
    queryStringParams = event.queryStringParameters;
    console.log("queryStringParams: " + queryStringParams);

    // Header Parameters
    headerParams = event.headers;
    console.log("headerParams: " + headerParams);

    if (event.requestContext !== null && event.requestContext !== undefined) {

        var requestContext = event.requestContext;
        console.log("requestContext: " + requestContext);

        // API Gateway Stage
        stage = requestContext.stage;
        console.log("API Gateway Stage: " + stage);

        // Unique Request ID
        requestId = requestContext.requestId;
        console.log("Unique Request ID: " + requestId);

        // Resource Path
        resourcePath = requestContext.resourcePath;
        console.log("Resource Path: " + resourcePath);

        var identity = requestContext.identity;
        console.log("identity: " + identity);

        // Amazon Cognito User Identity
        cognitoIdentityId = identity.cognitoIdentityId;
        console.log("Amazon Cognito User Identity: " + cognitoIdentityId);

        // Source IP
        sourceIp = identity.sourceIp;
        console.log("Source IP: " + sourceIp);

        // User-Agent
        userAgent = identity.userAgent;
        console.log("User-Agent: " + userAgent);

    }

    // API Gateway Stage Variables
    stageVariables = event.stageVariables;

    // HTTP Method (e.g., POST, GET, HEAD)
    httpMethod = event.httpMethod;
    console.log("HTTP Method: " + httpMethod);




    // TODO: Put your application logic here...

    context.callbackWaitsForEmptyEventLoop = false;


 console.log('accessKey: ' + accessKey);
 console.log('secretKey: ' + secretKey);


    function finalAppResponse( responseBody) {
        console.log("responseBody: " + JSON.stringify(responseBody));

        var response = {
            statusCode: responseCode,
            headers: {
                "x-custom-header" : "custom header value"
            },
            body: JSON.stringify(responseBody)
        };
        console.log("response: " + JSON.stringify(response));
        callback( null, response);
    } 




 
    let errorMessageDeleteAlbum = APP_NAME + " cannot delete album this album at this time. Try again shortly.";

    function uploadErrorMessage() {

        if (isStringWithLength(mediaContentType) && (mediaContentType === MediaType.Photo || mediaContentType === MediaType.Video)) {
            return APP_NAME + " cannot upload your " + mediaContentType + " at this time. Try again shortly.";
        } else {
            return APP_NAME + " cannot upload your content at this time. Try again shortly.";
        }
    }

    


    // Rollback on failure
    function rollbackAppError(message) {
        var response = {};
        response[kActive]       = ActiveValues.Active;
        response[kErrorMessage] = message;
        
        connection.rollback(function() { 
            finalAppResponse( response);
        }); 
    }

    function commitTransaction(albumId) {

        // Commit queries
        connection.commit(function(err) {
            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else  {
                console.log('successful commit!');
                
                var response = {};
                response[kActive]  = ActiveValues.Active;
                response[kAlbumId] = albumId;
                response[kSuccess] = true;
                finalAppResponse( response);
            }
        });
    }







    console.log('Received event:', JSON.stringify(event, null, 2));
    console.log('Request body:', JSON.stringify(requestBody, null, 2));
    

    // Parameters

    var userId      = cognitoIdentityId;    
    var acctId      = requestBody[kAcctId];
    


    var guid        = requestBody[kGuid];
    var albumId     = requestBody[kAlbumId];
    var fguid       = requestBody[kFGuid];


    // Parameters for gettings album media content
    var lastMediaUrl   = requestBody[kMediaURL];
    var lastMediaTime  = requestBody[kTimestamp];
    var MAX_MEDIA_RESULTS = requestBody[kNumberOfItems];

    // Delete media
    var mediaUrl    = requestBody[kMediaURL];

    var flagType    = requestBody[kType];


    
    var numberOfAlbums = requestBody[kCount];
    var lastAlbumId    = requestBody.lastAlbumId;
    var lastAlbumTitle = requestBody[kTitle];


    // Parameters for listing friends albums
    var isRefreshing    = requestBody[kIsRefreshing]; // Bool
    var lastTimestamp   = requestBody[kLastViewedMediaTimestamp];
    var lastAlbumWasNew = requestBody[kLastAlbumIsNew]; // Bool
    var pageIndex       = requestBody[kIndex]; // number


    var lastUsername    = requestBody[kUserName]; // string
    var MAX_ALBUM_RESULTS     = requestBody[kNumberOfItems];  // int


/**
 * 
    let kFollowersListAdd  = "followersToAdd";
    let kFollowersListRemove = "followersToRemove";

 */
    // For creating albums
    var title                = requestBody[kTitle];
    var followersAddList     = requestBody[kFollowersListAdd];
    var followersDeleteList  = requestBody[kFollowersListRemove];


    // var isSubmittingToAll   = requestBody[kInclusive];

    var isPrivate   = requestBody[kPrivate];

    var action      =  requestBody["action"];




    let kIsNew = "isNew";

    // Upload  Media
    var tmpS3Key      = requestBody[kTmpMediaKey];
    var tmpS3CoverKey = requestBody[kTmpCoverKey];
    
    var mediaContentType        = requestBody[kType]; // photo, video, gif ?

    var timelimit   = requestBody[kTimelimit]; // Video, Image, Gif ?

    // var albumList    = requestBody[kAlbums]; // array of albumId and isNew bit

    var albumIds = requestBody[kAlbums];
    

    // var albumIds    = requestBody[kAlbumIds];
    
    
    var daysTillExpire    = requestBody[kExpireDays];

    var startingWithNewMedia = requestBody[kStartWithUnseen];
    var getPreviousItems     = requestBody[kPreviousItems];









    if ( !isInt(MAX_MEDIA_RESULTS) ||  MAX_MEDIA_RESULTS > 40) {
        MAX_MEDIA_RESULTS = 40;
    }
    
    if ( !isInt(MAX_ALBUM_RESULTS) ||  MAX_ALBUM_RESULTS > 20) {
        MAX_ALBUM_RESULTS = 20;
    }

    console.log('UserId:', JSON.stringify(userId, null, 2));
    console.log("acctId: " + acctId);
    console.log("isRefreshing: " + isRefreshing);
    console.log("lastAlbumWasNew: " + lastAlbumWasNew);
    console.log("pageIndex: " + pageIndex);
    console.log("lastUsername: " + lastUsername);
    // console.log("MAX_MEDIA_RESULTS: " + MAX_MEDIA_RESULTS);
    // console.log("MAX_ALBUM_RESULTS: " + MAX_ALBUM_RESULTS);
    



    console.log("ClientID: " + userId);
    console.log("albumId: "  + albumId);

    console.log("lastMediaUrl: "  + lastMediaUrl);
    console.log("lastMediaTime: " + lastMediaTime);
 
    console.log("lastTimestamp: " + lastTimestamp);

 
    // Error checking user input
    if ( userId === undefined || userId === null || userId.length > 100) {
        console.error("userId is bad: " + userId);
        finalAppResponse( activeResponse( ActiveValues.Unknown, activeErrorMessage( ActiveValues.Unknown )));
        return;
    }
    if ( acctId === undefined || acctId === null || acctId.length > 10 ) {
        console.error("acctId is bad: " + acctId);
        finalAppResponse( activeResponse( ActiveValues.Unknown, activeErrorMessage( ActiveValues.Unknown )));
        return;
    }




        console.log("1");


    var maxDuplicateRetires = 3;
    


    /**
     * ======================================================================================================
     * ======================================================================================================
     * ======================================================================================================
     *  useralbums.js
     * 
     *                                 Listing My albums
     * 
     * ======================================================================================================
     * ======================================================================================================
     * ======================================================================================================
     * 
     * 
     * 
     * 
     * 
     *  SELECT `id`, first_url, `count`, `title`, `views`, `is_private`, UNIX_TIMESTAMP(`create_date`) AS create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp, `cover_album_url` 
     *  FROM `bookmarked_album` 
     *  WHERE `guid` = ? 
     *  ORDER BY `timestamp` DESC 
     *  LIMIT ?';


     
        "SELECT ua.`guid`, ua.first_url, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private  
        FROM `bookmarked_album` AS ba
            INNER JOIN  `user_album` AS ua 
            ON ba.guid = ? AND ba.fguid = ua.guid AND ba.album_id = ua.id 
                LEFT JOIN `friends` 
                ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
                    INNER JOIN album_permissions AS ap 
                    ON ua.`is_private` = 0 OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                        INNER JOIN `profile` 
                        ON ua.guid = profile.guid      
        WHERE ua.expire_date IS NULL OR ua.expire_date > NOW()                                   
        ORDER BY ba.`timestamp` DESC 
        LIMIT ?";

             "SELECT ua.`guid`, ua.first_url, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private FROM `bookmarked_album` AS ba INNER JOIN  `user_album` AS ua ON ba.guid = ? AND ba.fguid = ua.guid AND ba.album_id = ua.id LEFT JOIN `friends` ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? INNER JOIN album_permissions AS ap ON ua.`is_private` = 0 OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid WHERE ua.expire_date IS NULL OR ua.expire_date > NOW() ORDER BY ba.`timestamp` DESC LIMIT ?";



        parameters = [guid, guid, Follling, limit ]

  WHERE (ua.expire_date IS NULL OR ua.expire_date > NOW())                                    
        ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?"; //ORDER BY ua.newest_media_timestamp AND (ua.newest_media_timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?";


        SELECT ua.`guid`, ua.first_url, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private  
        FROM `user_album` AS ua 
            INNER JOIN `friends` 
            ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
                INNER JOIN album_permissions AS ap 
                ON ua.`is_private` = ? OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                    INNER JOIN `profile` 
                    ON ua.guid = profile.guid 
                        LEFT JOIN album_last_viewed_media AS alvm 
                        ON alvm.guid = ap.guid AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
        WHERE (ua.expire_date IS NULL OR ua.expire_date > NOW())                                    
        ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?"; //ORDER BY ua.newest_media_timestamp AND (ua.newest_media_timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?";




        SELECT ua.`guid`, ua.first_url, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private 
        FROM `bookmarked_album` AS ba 
            INNER JOIN  `user_album` AS ua 
            ON ba.guid = ? AND ba.fguid = ua.guid AND ba.album_id = ua.id 
                LEFT JOIN `friends` 
                ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
                    INNER JOIN album_permissions AS ap ON ua.`is_private` = 0 OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                        INNER JOIN `profile` 
                        ON ua.guid = profile.guid 
        WHERE ua.expire_date IS NULL OR ua.expire_date > NOW() 
        ORDER BY ba.`timestamp` DESC 
        LIMIT ?";



     */

    function listMyBookmarkedAlbums(guid) {
        console.log("listMyBookmarkedAlbums");
 
        // var albumSqlQuery = 'SELECT `id`, `count`, `title`, `views`, `is_private`, `create_date`, `newest_media_timestamp`, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND newest_media_timestamp > NOW() - INTERVAL 1 DAY AND count > 0 ORDER BY `title` LIMIT ?';
        var albumSqlQuery = "SELECT ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private FROM `bookmarked_album` AS ba INNER JOIN  `user_album` AS ua ON ba.guid = ? AND ba.fguid = ua.guid AND ba.album_id = ua.id LEFT JOIN `friends` ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? INNER JOIN album_permissions AS ap ON ua.`is_private` = 0 OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid WHERE ua.expire_date IS NULL OR ua.expire_date > NOW() ORDER BY ba.`timestamp` DESC LIMIT ?";
        var parameters = [ guid, guid, Relationship.IsFollowing, numberOfAlbums ];

        if ( isStringWithLength(lastTimestamp )) {
            albumSqlQuery = "SELECT ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private FROM `bookmarked_album` AS ba INNER JOIN  `user_album` AS ua ON ba.guid = ? AND ba.fguid = ua.guid AND ba.album_id = ua.id LEFT JOIN `friends` ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? INNER JOIN album_permissions AS ap ON ua.`is_private` = 0 OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid WHERE ua.expire_date IS NULL OR ua.expire_date > NOW() AND ba.timestamp<= FROM_UNIXTIME(?) ORDER BY ba.`timestamp` DESC LIMIT ?";
            parameters = [ guid , lastTimestamp, numberOfAlbums ];
        }
        
        getNewAlbumResults(guid, albumSqlQuery, parameters);


        // // Refreshing
        // if ( !isStringWithLength(lastTimestamp) ) { //(isRefreshing) {

        //     var parameters = [myGuid, Relationship.IsFollowing, 0, numberOfAlbums ];
        //     getNewAlbumResults(myGuid, refreshAlbumsSql, parameters);

        // // Load more
        // } else {
        //     var parameters = [myGuid, Relationship.IsFollowing, 0, lastTimestamp, numberOfAlbums ];
        //     getNewAlbumResults(myGuid, loadAlbumsSql, parameters);
        // }



        // connection.query({ 
        //     sql: albumSqlQuery,
        //     values: parameters, 
        // },
        // function (error, results, fields) {

        //     if (error) {
        //         printError(error);
        //         finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
        //     } 

        //     if (results) {
        //         console.log('==== Printing out Results for ' + results.length +  ' rows ====');
                
        //         var albums = []; 

        //         results.forEach((result) => {
        //             console.log(result);
                    
                    
                    
        //             var albumInfo = {};

        //             if ( validator.isBase64(result.title) ) {
        //                 albumInfo[kTitle]  = titleToUTF(result.title);
        //             } else {
        //                 albumInfo[kTitle] = result.title;
        //             }

        //             albumInfo[kAlbumId]              = result.id;                    
        //             albumInfo[kCount]                = result.count;
        //             albumInfo[kCreateDate]           = result.create_date.toString();
        //             albumInfo[kNewestMediaTimestamp] = result.newest_media_timestamp.toString();
        //             albumInfo[kAlbumCover]           = result.cover_album_url;

        //             albumInfo[kFirstUrl]             = result.first_url;

        //             albumInfo[kSignedFirstUrl]  = s3.getSignedUrl('getObject', 
        //                                         {   Bucket  : ALBUM_BUCKET,  
        //                                             Key     : albumFirstMediaKey(guid, result.first_url), 
        //                                             Expires : S3_EXPIRE_LIMIT 
        //                                         });

        
        //             albumInfo[kViews]                = result.views;
                     
        //             albumInfo[kPrivate]              = intToBool(result.is_private);

        //             albums.push(albumInfo);     
        //         });
        
        //         console.log("listMyBookmarkedAlbums getAlbumsList: Number of albums: " + albums.length);

        //         finalAppResponse( albumsResponse(albums));
                

        //         console.log("=============== Done ================");
        //     } else {
        //         console.log('listMyBookmarkedAlbums getAlbumsList Error:', JSON.stringify(error, null, 2));
        //         finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
        //     }
        // });

    }

    function listMyOpenAlbums(guid) {
        console.log("listMyOpenAlbums");

        

/**
 * SELECT `id`, `count`, `title`, `views`, `is_private`, `create_date`, `newest_media_timestamp`, `cover_album_url` 
 *  FROM `user_album` WHERE `guid` = ? AND count > 0  AND create_date > NOW() - INTERVAL 1 DAY OR create_date > NOW() - INTERVAL 20 MINUTE )
 *  ORDER BY `newest_media_timestamp` 
 *  LIMIT ?';
 * 
 * 
 * 
 *      SELECT `id`, explicit, explicit_override, first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, `count`, `title`, `views`, `is_private`, UNIX_TIMESTAMP(`create_date`) AS create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp, `cover_album_url` 
        FROM `user_album` 
        WHERE `guid` = ? AND (create_date > NOW() - INTERVAL 1 DAY OR create_date > NOW() - INTERVAL 20 MINUTE )
        ORDER BY `create_date` DESC 
        LIMIT ?';


 */


        // var albumSqlQuery = 'SELECT `id`, `count`, `title`, `views`, `is_private`, `create_date`, `newest_media_timestamp`, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND newest_media_timestamp > NOW() - INTERVAL 1 DAY AND count > 0 ORDER BY `title` LIMIT ?';
        var albumSqlQuery = 'SELECT `id`, explicit, explicit_override, first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, `count`, `title`, `views`, `is_private`, UNIX_TIMESTAMP(`create_date`) AS create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND (create_date > NOW() - INTERVAL 1 DAY AND count > 0) ORDER BY `create_date` DESC LIMIT ?';
        var parameters = [ guid, numberOfAlbums ];
       
        if ( isStringWithLength(lastTimestamp )) {
            albumSqlQuery = 'SELECT `id`, explicit, explicit_override, first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, `count`, `title`, `views`, `is_private`, UNIX_TIMESTAMP(`create_date`) AS create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND (create_date > NOW() - INTERVAL 1 DAY AND count > 0) AND newest_media_timestamp <= FROM_UNIXTIME(?) ORDER BY `create_date` DESC LIMIT ?';
            parameters = [ guid , lastTimestamp, numberOfAlbums ];
        }

        connection.query({ 
            sql: albumSqlQuery,
            values: parameters, 
        },
        function (error, results, fields) {

            if (error) {
                printError(error);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } 

            if (results) {
                console.log('==== Printing out Results for ' + results.length +  ' rows ====');
                
                var albums = []; 

                results.forEach((result) => {
                    console.log(result);
                    
                    // if (result.is_private) {

                    //     var mediaKey = albumMediaKey(guid, mediaUrl);
                        
                    //     var params = {  Bucket  : ALBUM_BUCKET, 
                    //                     Key     : mediaKey,
                    //                     Expires : S3_EXPIRE_LIMIT
                    //                  };
                    //     var signedUrl = s3.getSignedUrl('getObject', params);
                    //     albumInfo[kSignedUrl] = signedUrl;
                    // } 


                    
                    var albumInfo = {};

                    // if ( validator.isBase64(result.title) ) {
                    //     albumInfo[kTitle]  = titleToUTF(result.title);
                    // } else {
                    //     albumInfo[kTitle] = result.title;
                    // }
                    albumInfo[kTitle] = result.title;


                    albumInfo[kAlbumId]              = result.id;                    
                    albumInfo[kCount]                = result.count;
                    albumInfo[kCreateDate]           = result.create_date.toString();
                    if (result.newest_media_timestamp !== null) {
                        albumInfo[kNewestMediaTimestamp] = result.newest_media_timestamp.toString();
                    }
                    albumInfo[kAlbumCover]           = result.cover_album_url;

                    if (result.first_url !== null) {
                        albumInfo[kFirstUrl]             = result.first_url;
                        albumInfo[kTimestamp]            = result.first_timestamp.toString();
                    }
                    
                    albumInfo[kExplicit]             = intToBool(result.explicit);
                    albumInfo[kExplicitOverride]     = intToBool(result.explicit_override);


                    albumInfo[kSignedFirstUrl]  = s3.getSignedUrl('getObject', 
                                                {   Bucket  : ALBUM_BUCKET,  
                                                    Key     : albumFirstMediaKey(guid, result.first_url), 
                                                    Expires : S3_EXPIRE_LIMIT 
                                                });

                                            
                    albumInfo[kViews]                = result.views;
                     
                    albumInfo[kPrivate]              = intToBool(result.is_private);

                    albums.push(albumInfo);     
                });
        
                console.log("listMyOpenAlbums getAlbumsList: Number of albums: " + albums.length);

                finalAppResponse( albumsResponse(albums));
                

                console.log("=============== Done ================");
            } else {
                console.log('listMyOpenAlbums getAlbumsList Error:', JSON.stringify(error, null, 2));
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            }
        });
    }




 
    function listMyAlbums(guid) {
        console.log("listMyAlbums");

//UNIX_TIMESTAMP() FROM_UNIXTIME(?)
// UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp
// explicit explicit_override
        // var albumSqlQuery = 'SELECT `id`, `count`, `title`, `views`, `is_private`, `create_date`, `newest_media_timestamp`, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND newest_media_timestamp > NOW() - INTERVAL 1 DAY AND count > 0 ORDER BY `title` LIMIT ?';
        var albumSqlQuery = 'SELECT `id`, first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, `count`, `title`, `views`, `is_private`, `explicit`, `explicit_override`, UNIX_TIMESTAMP(`create_date`) as create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND count > 0 ORDER BY `create_date` DESC LIMIT ?';
        var parameters = [ guid, numberOfAlbums ];
       
        console.log("listMyAlbums lastTimestamp ok? ");

        if ( isStringWithLength(lastTimestamp )) {
            console.log("listMyAlbums lastTimestamp: " + lastTimestamp);

            albumSqlQuery = 'SELECT `id`, first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, `count`, `title`, `views`, `is_private`, UNIX_TIMESTAMP(`create_date`) as create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp, `cover_album_url` FROM `user_album` WHERE `guid` = ? AND count > 0 AND create_date <= FROM_UNIXTIME(?) ORDER BY `create_date` DESC LIMIT ?';
            parameters = [ guid , lastTimestamp, numberOfAlbums ];
        }

        connection.query({
            sql: albumSqlQuery,
            values: parameters, 
        },
        function (error, results, fields) {

            if (error) {
                printError(error);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } 

            if (results) {
                console.log('==== Printing out Results for ' + results.length +  ' rows ====');
                
                var albums = []; 

                results.forEach((result) => {
                    console.log(result);
                    
                    // if (result.is_private) {

                    //     var mediaKey = albumMediaKey(guid, mediaUrl);
                        
                    //     var params = {  Bucket  : ALBUM_BUCKET, 
                    //                     Key     : mediaKey,
                    //                     Expires : S3_EXPIRE_LIMIT
                    //                  };
                    //     var signedUrl = s3.getSignedUrl('getObject', params);
                    //     albumInfo[kSignedUrl] = signedUrl;
                    // } 
                    
                    var albumInfo = {};


                    // if ( validator.isBase64(result.title) ) {
                    //     albumInfo[kTitle]  = titleToUTF(result.title);
                    // } else {
                    //     albumInfo[kTitle] = result.title;
                    // }
                    albumInfo[kTitle] = result.title;

                    albumInfo[kAlbumId]              = result.id;                    
                    albumInfo[kCount]                = result.count;
                    albumInfo[kCreateDate]           = result.create_date.toString();
                    albumInfo[kNewestMediaTimestamp] = result.newest_media_timestamp.toString();
                    albumInfo[kAlbumCover]           = result.cover_album_url;
                    
                    albumInfo[kExplicit]             = intToBool(result.explicit);
                    albumInfo[kExplicitOverride]     = intToBool(result.explicit_override);


                    albumInfo[kFirstUrl]             = result.first_url;
                    albumInfo[kTimestamp]            = result.first_timestamp.toString();

                    

                    albumInfo[kSignedFirstUrl]      = s3.getSignedUrl('getObject', 
                                                    {   Bucket  : ALBUM_BUCKET,  
                                                        Key     : albumFirstMediaKey(guid, result.first_url), 
                                                        Expires : S3_EXPIRE_LIMIT 
                                                    });

                    albumInfo[kViews]                = result.views;
                     
                    albumInfo[kPrivate]              = intToBool(result.is_private);

                    albums.push(albumInfo);     
                });
        
                console.log("listMyAlbums getAlbumsList: Number of albums: " + albums.length);

                finalAppResponse( albumsResponse(albums));
                

                console.log("=============== Done ================");
            } else {
                console.log('listMyAlbums getAlbumsList Error:', JSON.stringify(error, null, 2));
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            }
        });
    }




    /**
     * ======================================================================================================
     * ======================================================================================================
     * ======================================================================================================
     * 
     * 
     *                          GET FRIENDS ALBUMS
     * 
     * 
     * ======================================================================================================
     * ======================================================================================================
     * ======================================================================================================
     * 
     * 
     */











/**
 * 
 *  Friends Private album permissions
 * 
 *  guid, owner_guid, album_id
 * ================================= =============================== ===============================
 * 
 *  Friends albums view history to see last viewed media content
 * 
 *      album_last_viewed_media
 *  *  guid, owner_guid, album_id, last_viewed_media_url, last_viewed_timestamp

 ================================= =============================== ===============================
 *  public albums
 * 
 *  Just user albums 
 *  ================================= =============================== ===============================
 *      Query Test 1
 *  ================================= =============================== ===============================
 *  SELECT ua.`guid`, ua.`is_private`, ua.`title`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, 
 *          flvm.album_id, flvm.last_viewed_media_url, flvm.last_viewed_timestamp
 *          `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified 
 *  FROM `user_album` AS ua
 *      INNER JOIN `friends` 
 *      ON friends.guid1 = ua.guid AND friends.`status` = ?
            INNER JOIN album_permissions AS ap 
            ON ua.`is_private` = ? OR (ap.guid = ? AND ap.owner_guid = friends.guid1 AND ap.album_id = ua.id)
                INNER JOIN `profile` 
 *              ON ua.guid = profile.guid 
 *                  LEFT JOIN album_last_viewed_media AS flvm 
 *                  ON flvm.guid = ? AND flvm.owner_guid = ua.guid AND flvm.album_id = ua.id
 * 
 *  WHERE friends.guid2 = ? AND (ua.newest_media_timestamp > NOW() - INTERVAL 1 DAY)
 * 
 * //  WHERE fa.guid = ? AND (newest_media_timestamp > NOW() - INTERVAL 1 DAY) AND (newest_media_timestamp > last_viewed_timestamp OR last_viewed_timestamp IS null) 
 *  ORDER BY newest_media_timestamp DESC 
 *  LIMIT ?, ?";
 * 
 * [Relationship.IsFollowing, false, guid, guid, guid  ]
 * 
 *  ================================= =============================== ===============================
 *      Query Test 2
 *  ================================= =============================== ===============================

 *  SELECT ua.`guid`, ua.`title`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, 
 *          flvm.album_id, flvm.last_viewed_media_url, flvm.last_viewed_timestamp
 *          `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified 
 *  FROM `user_album` AS ua
 *      INNER JOIN `friends` 
 *      ON friends.guid1 = ua.guid AND friends.guid2 = ? AND friends.`status` = ?
            INNER JOIN album_permissions AS ap 
            ON ua.`is_private` = ? OR (ap.guid = ? AND ap.owner_guid = friends.guid1 AND ap.album_id = ua.id)
                INNER JOIN `profile` 
 *              ON ua.guid = profile.guid 
 *                  LEFT JOIN album_last_viewed_media AS flvm 
 *                  ON flvm.guid = ? AND flvm.owner_guid = ua.guid AND flvm.album_id = ua.id
 * 
 *  WHERE friends.guid2 = ? AND (ua.newest_media_timestamp > NOW() - INTERVAL 1 DAY)
 * 
 * //  WHERE fa.guid = ? AND (newest_media_timestamp > NOW() - INTERVAL 1 DAY) AND (newest_media_timestamp > last_viewed_timestamp OR last_viewed_timestamp IS null) 
 *  ORDER BY newest_media_timestamp DESC 
 *  LIMIT ?, ?";
 * 
 * 
 * 
 * 
 * 

 */

// change WHERE user_album.`count` > 0


/**
 * 
 * 
 *  Private 
 * 
 * SELECT   ua.`guid`, ua.`id` AS album_id, ua.`is_private`, ua.`title`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, 
 *          flvm.last_viewed_media_url, flvm.last_viewed_timestamp, 
 *          `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified 
 *  FROM `user_album` AS ua 
 *      INNER JOIN `friends` 
 *      ON friends.guid2 = ua.guid AND friends.`status` = ? 
 *          INNER JOIN album_permissions AS ap 
 *          ON ua.`is_private` = ? OR (ap.guid = ? AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
 *              INNER JOIN `profile` 
 *              ON ua.guid = profile.guid 
 *                  LEFT JOIN album_last_viewed_media AS flvm 
 *                  ON flvm.guid = ? AND flvm.fguid = ua.guid AND flvm.album_id = ua.id 
 *  
 *  PUblic 
 * 
 * SELECT   ua.`guid`, ua.`id` AS album_id, ua.`is_private`, ua.`title`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, 
 *          flvm.last_viewed_media_url, flvm.last_viewed_timestamp, 
 *          `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified 
 *  FROM `user_album` AS ua 
 *      INNER JOIN `friends` 
 *      ON friends.guid2 = ua.guid AND friends.`status` = ? 
*              INNER JOIN `profile` 
*              ON ua.guid = profile.guid 
*                  LEFT JOIN album_last_viewed_media AS flvm 
*                  ON flvm.guid = ? AND flvm.fguid = ua.guid AND flvm.album_id = ua.id 
 * 
 * WHERE ua.`is_private` = 0
 *                  
 * 
 * 
 * 
 * 
 * 
 *  
//  * Replace with the statement=
 * 
 * SELECT   ua.`guid`, ua.`id` AS album_id, ua.`is_private`, ua.`views`, ua.`likes`, ua.`dislikes`, ua.create_date, ua.expire, ua.expire_date, ua.`title`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, 
 *          alvm.last_viewed_media_url, alvm.last_viewed_timestamp
 *          `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified , MAX(alvm.last_viewed_timestamp)
 *  FROM `user_album` AS ua 
 *      INNER JOIN `friends` 
 *      ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
 *          INNER JOIN album_permissions AS ap 
 *          ON ua.`is_private` = ? OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
 *              INNER JOIN `profile` 
 *              ON ua.guid = profile.guid 
 *                  LEFT JOIN album_last_viewed_media AS alvm 
 *                  ON alvm.guid = ap.guid AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
 *                  
 * WHERE (ua.expire_date IS NULL OR ua.expire_date > NOW())    // AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) 
 * ORDER BY alvm.last_viewed_media_url IS NULL DESC, newest_media_timestamp DESC LIMIT ?";
 * 
 * 
 * 
 *              Change album_last_viewed_media to (PRIMARY_KEY = guid, fguid, albumId, mediaUrl, timestamp, viewTimestamp)
 * 
 *              And delete album_view_history? 
 * 
 * 
 *   create_date > NOW() - INTERVAL expire DAY
 *  WHERE friends.guid1 = ? AND (ua.newest_media_timestamp > NOW() - INTERVAL 1 DAY) AND ua.newest_media_timestamp > ? 
 *  GROUP BY 
 * ORDER BY flvm.last_viewed_media_url IS NULL DESC,  newest_media_timestamp DESC 
 * 
 * 
 * 
 * 
 * 


    TODO:
    SELECT COUNT(*) as unseenCount
    FROM album_last_viewed_media AS alvm
	    INNER JOIN album_media
	    ON alvm.fguid = album_media.guid AND alvm.album_id = album_media.album_id
    WHERE alvm.guid = ? AND alvm.fguid = ? AND alvm.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR album_media.timestamp > alvm.last_viewed_timestamp)





    SELECT ua.`guid`, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, ua.create_date, ua.expire, ua.expire_date, 
        alvm.last_viewed_media_url, alvm.last_viewed_timestamp, 
        ua.`title`, ua.`is_private`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, 
        `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified
    FROM `user_album` AS ua 
        INNER JOIN `friends` 
        ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
            INNER JOIN album_permissions AS ap 
            ON ua.`is_private` = ? OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                INNER JOIN `profile` 
                ON ua.guid = profile.guid 
                    LEFT JOIN album_last_viewed_media AS alvm 
                    ON alvm.guid = ap.guid AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
    WHERE (ua.expire_date IS NULL OR ua.expire_date > NOW()) 
    ORDER BY ua.newest_media_timestamp AND (ua.newest_media_timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC 
    LIMIT ?";


 * 
 */

/**
 * 
 *  Order by:
 * 
 *  * Popularity = followersCount + Views + Likes

 * 
 * 1) Best posts
 *      - Newest albums by your favorite users
 *          -Those that you have viewed the most and liked
 * 2) Newest albums
 * 
 * 
 *              If we store user history in album_last_viewed_media CHANGE to album_viewed_media
 * 
 *              Change album_last_viewed_media to (PRIMARY_KEY = guid, fguid, albumId, mediaUrl, timestamp, viewTimestamp)
 * 
 *              And delete album_view_history 
 *      
 *              And update function that updates album_last_viewed_media using "IF("

 *  
 * 18 446 744 073 709  551 615
 * 
 */


/**
 * 
 * ORDER BY 1)  newest unseen media, things you would enjoy more
 * 
 * ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp ) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?
 * 
 */

/**
 *  SELECT ua.`guid`, ua.first_url, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) as create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private  
 *  FROM `user_album` AS ua 
 *      INNER JOIN `friends` 
 *      ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
 *          INNER JOIN album_permissions AS ap 
 *          ON ua.`is_private` = ? OR (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
 *              INNER JOIN `profile` 
 *              ON ua.guid = profile.guid 
 *                  LEFT JOIN album_last_viewed_media AS alvm 
 *                  ON alvm.guid = ap.guid AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
 *  WHERE (ua.expire_date IS NULL OR ua.expire_date > NOW())                                    
 *  ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC 
 *  LIMIT ?";
 * 
 * 
 * 
 * Select 
 * FROM user_album
 *      LEFT JOIN shared_albums
 *      ON sha.user_guid = ? AND sha.album_id = user_album.album_id, user_album.is_private = 0  
 * 
 * too compliared
 * 
 * 
 * just do: 
 *  
 * 
 *      LEFT JOIN shared_albums
 *      ON sha.user_guid = ? 
 * 
 * 
 *  And where user clicks on the album: If the album has gone private and/or the user has gone private show. Error message: 
 * 
 *  SELECT... 
 * 
 *  Shared_album
 * 
 *  sharer_guid, owner_guid, album_id
 * 
 * 



 *  ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC 

    Order by: 

    New Albums
    Old albums with new content

        1) Unseen content
        3) Newest media Content
        2) What user is most interested in


    */

    /**
     * 
     * 

     

    
    
    var parameters = [myGuid, numberOfAlbums ];




    Following page: 
    Followers, What You Missed, 

    
    
    WHERE  ua.newest_media_timestamp < FROM_UNIXTIME(?) 
    ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC 
    LIMIT ?"; 




    After user creates album, whenever user uploads new content, 
        1) get if album is public or private
        2) If public, get all followers. If private, get selected users
        3) INSERT INTO timeline SET guid = ?, fguid = ?, album_id = ? ON DUPLICATE KEY UPDATE date=VALUES(date)';
        

        
    ON delete content: update date to last media date,
    On delete album, delete from timeline


    
    insert into timeline 


    If usr is mentioned in album, user gets a notification
       
    
    SELECT ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private 
    FROM album_timeline AS tl 
        INNER JOIN `user_album` AS ua 
        ON tl.fguid = ua.guid AND tl.album_id = ua.id 
            INNER JOIN `profile` 
            ON ua.guid = profile.guid 
                LEFT JOIN album_last_viewed_media AS alvm 
                ON alvm.guid = tl.guid AND alvm.fguid = tl.fguid AND alvm.album_id = tl.album_id
    WHERE tl.guid = ? AND (ua.expire_date IS NULL OR ua.expire_date > NOW()) 
    ORDER BY album_timeline.date DESC 
    LIMIT ?";


    LEFT JOIN user_metrics AS um ON ua.guid = um.guid


    SELECT ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private
    FROM `user_album` AS ua 
        INNER JOIN `friends` 
        ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
            LEFT JOIN album_permissions AS ap 
            ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                INNER JOIN `profile` 
                ON ua.guid = profile.guid 
                    LEFT JOIN album_last_viewed_media AS alvm 
                    ON alvm.guid = friends.guid1 AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
    WHERE (ua.`is_private` = ? OR ap.guid IS NOT NULL) AND (ua.expire_date IS NULL OR ua.expire_date > NOW())                                    
    ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?";


    SELECT um.popularity, ua.`gumid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers, profile.followers, profile.following, `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private 
    FROM album_timeline AS tl 
        INNER JOIN `user_album` AS ua 
        ON tl.fguid = ua.guid AND tl.album_id = ua.id 
            INNER JOIN `profile` 
            ON ua.guid = profile.guid 
                LEFT JOIN album_last_viewed_media AS alvm 
                ON alvm.guid = tl.guid AND alvm.fguid = tl.fguid AND alvm.album_id = tl.album_id 
                    LEFT JOIN user_metrics AS um 
                    ON ua.guid = um.guid 
    WHERE tl.guid = ? AND (ua.expire_date IS NULL OR ua.expire_date > NOW()) 
    ORDER BY tl.date DESC 
    LIMIT ?";


     */

    var timelineQuery         = "SELECT um.popularity, ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers, profile.followers, profile.following, `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private FROM album_timeline AS tl INNER JOIN `user_album` AS ua ON tl.fguid = ua.guid AND tl.album_id = ua.id INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = tl.guid AND alvm.fguid = tl.fguid AND alvm.album_id = tl.album_id LEFT JOIN user_metrics AS um ON ua.guid = um.guid WHERE tl.guid = ? AND (ua.expire_date IS NULL OR ua.expire_date > NOW()) ORDER BY tl.date DESC LIMIT ?";
    var loadMoreTimelineQuery = "SELECT um.popularity, ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers, profile.followers, profile.following, `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private FROM album_timeline AS tl INNER JOIN `user_album` AS ua ON tl.fguid = ua.guid AND tl.album_id = ua.id INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = tl.guid AND alvm.fguid = tl.fguid AND alvm.album_id = tl.album_id LEFT JOIN user_metrics AS um ON ua.guid = um.guid WHERE tl.guid = ? AND tl.date < FROM_UNIXTIME(?) AND (ua.expire_date IS NULL OR ua.expire_date > NOW()) ORDER BY tl.date DESC LIMIT ?";


    
    var refreshAlbumsSql = "SELECT ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private  FROM `user_album` AS ua INNER JOIN `friends` ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? LEFT JOIN album_permissions AS ap ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = friends.guid1 AND alvm.fguid = ua.guid AND alvm.album_id = ua.id WHERE (ua.`is_private` = ? OR ap.guid IS NOT NULL) AND (ua.expire_date IS NULL OR ua.expire_date > NOW())                                    ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?"; //ORDER BY ua.newest_media_timestamp AND (ua.newest_media_timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?";
/// ORDER BY (ua.newest_media_timestamp > alvm.last_viewed_timestamp AND )  alvm.last_viewed_timestamp IS NULL DESC, ua.newest_media_timestamp > alvm.last_viewed_timestamp, newest_media_timestamp LIMIT ?"; // ua.newest_media_timestamp > alvm.last_viewed_timestamp
    var loadAlbumsSql    = "SELECT ua.`guid`, ua.explicit,  ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp,  ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers, `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private FROM `user_album` AS ua INNER JOIN `friends` ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ?  LEFT JOIN album_permissions AS ap ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = friends.guid1 AND alvm.fguid = ua.guid AND alvm.album_id = ua.id WHERE (ua.`is_private` = ? OR ap.guid IS NOT NULL)  AND (ua.expire_date IS NULL OR ua.expire_date > NOW()) AND ua.newest_media_timestamp < FROM_UNIXTIME(?) ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?";  //ORDER BY ua.newest_media_timestamp AND (ua.newest_media_timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?';";
    // ORDER BY alvm.last_viewed_timestamp IS NULL DESC, ua.newest_media_timestamp > alvm.last_viewed_timestamp, newest_media_timestamp DESC LIMIT ?";




// var refreshAlbumsSqlOld = "SELECT ua.`guid`, ua.`id` AS album_id, ua.`is_private`, ua.`views`, ua.`likes`, ua.`dislikes`, ua.`title`, ua.`cover_album_url`, ua.create_date, ua.expire, ua.expire_date, ua.`newest_media_timestamp`, ua.`count`, flvm.last_viewed_media_url, flvm.last_viewed_timestamp, `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified FROM `user_album` AS ua INNER JOIN `friends` ON friends.guid2 = ua.guid AND friends.`status` = ? INNER JOIN album_permissions AS ap ON ua.`is_private` = ? OR (ap.guid = ? AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS flvm ON flvm.guid = ? AND flvm.fguid = ua.guid AND flvm.album_id = ua.id WHERE friends.guid1 = ? AND (ua.expire_date > NOW() OR ua.expire_date IS NULL)                               ORDER BY flvm.last_viewed_media_url IS NULL DESC, newest_media_timestamp DESC LIMIT ?";
            

// var loadAlbumsSqlOld = "SELECT ua.`guid`, ua.`id` AS album_id, ua.`is_private`, ua.`views`, ua.`likes`, ua.`dislikes`, ua.`title`, ua.`cover_album_url`, ua.create_date, ua.expire, ua.expire_date, ua.`newest_media_timestamp`, ua.`count`, flvm.last_viewed_media_url, flvm.last_viewed_timestamp, `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified FROM `user_album` AS ua INNER JOIN `friends` ON friends.guid2 = ua.guid AND friends.`status` = ? INNER JOIN album_permissions AS ap ON ua.`is_private` = ? OR (ap.guid = ? AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS flvm ON flvm.guid = ? AND flvm.fguid = ua.guid AND flvm.album_id = ua.id WHERE friends.guid1 = ? AND (ua.expire_date > NOW() OR ua.expire_date IS NULL) AND ua.newest_media_timestamp < ? ORDER BY flvm.last_viewed_media_url IS NULL DESC, newest_media_timestamp DESC LIMIT ?";
// var newAlbumsSql = "SELECT ua.`guid`, ua.`id` AS album_id, ua.`is_private`, ua.`views`, ua.`likes`, ua.`dislikes`, ua.`title`, ua.`cover_album_url`, ua.`newest_media_timestamp`, ua.`count`, flvm.last_viewed_media_url, flvm.last_viewed_timestamp, `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified FROM `user_album` AS ua INNER JOIN `friends` ON friends.guid2 = ua.guid AND friends.`status` = ? INNER JOIN album_permissions AS ap ON ua.`is_private` = ? OR (ap.guid = ? AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS flvm ON flvm.guid = ? AND flvm.fguid = ua.guid AND flvm.album_id = ua.id WHERE friends.guid1 = ? AND (ua.newest_media_timestamp > NOW() - INTERVAL 1 DAY) ORDER BY flvm.last_viewed_media_url IS NULL DESC, newest_media_timestamp DESC LIMIT ?, ?";


 //  * [Relationship.IsFollowing, false, guid, guid, guid , offest, number_of_items ]



    // var newAlbumsSql2 = "SELECT fa.`fguid`, fa.`album_id`, fa.`last_viewed_media_url`, fa.`last_viewed_timestamp`, user_album.`title`, user_album.`cover_album_url`, user_album.`newest_media_timestamp`, user_album.`count`, `profile`.username, `profile`.fullname, `profile`.image_url, `profile`.verified FROM `album_permissions` AS fa INNER JOIN `user_album` ON fa.fguid = user_album.guid AND fa.album_id = user_album.id INNER JOIN `profile` ON fa.fguid = profile.guid WHERE fa.guid = ? AND (newest_media_timestamp > NOW() - INTERVAL 1 DAY)  AND (newest_media_timestamp > last_viewed_timestamp OR last_viewed_timestamp IS null) ORDER BY newest_media_timestamp DESC LIMIT ?, ?";

    // var oldAlbumsSql = "SELECT fa.`fguid`, fa.`album_id`, fa.`last_viewed_media_url`, fa.`last_viewed_timestamp`, user_album.`title`, user_album.`cover_album_url`, user_album.`newest_media_timestamp`, user_album.`count`, `profile`.username, `profile`.fullname, `profile`.verified FROM `album_permissions` AS fa INNER JOIN `user_album` ON fa.fguid = user_album.guid AND fa.album_id = user_album.id INNER JOIN `profile` ON fa.fguid = profile.guid WHERE fa.guid = ? ORDER BY `profile`.username ASC LIMIT ?";

    // var oldAlbumsNextSql = "SELECT fa.`fguid`, fa.`album_id`, fa.`last_viewed_media_url`, fa.`last_viewed_timestamp`, user_album.`title`, user_album.`cover_album_url`,  user_album.`newest_media_timestamp`, user_album.`count`, `profile`.username, `profile`.fullname, `profile`.verified FROM `album_permissions` AS fa INNER JOIN `user_album` ON fa.fguid = user_album.guid AND fa.album_id = user_album.id INNER JOIN `profile` ON fa.fguid = profile.guid WHERE fa.guid = ? AND `profile`.username > ? ORDER BY `profile`.username ASC LIMIT ?";



    /**
     *  Old albums that do not:    
     * 
     * 
     * timestamp < NOW() - INTERVAL 1 DAY
     */
// UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp
    // var oldAlbumsSql2 = "SELECT fa.`fguid`, fa.`album_id`, fa.`last_viewed_media_url`, fa.`last_viewed_timestamp`, user_album.`title`, user_album.`cover_album_url`, user_album.`newest_media_timestamp`, user_album.`count`, `profile`.username, `profile`.fullname, `profile`.verified, `profile`.image_url FROM `album_permissions` AS fa INNER JOIN `user_album` ON fa.fguid = user_album.guid AND fa.album_id = user_album.id INNER JOIN `profile` ON fa.fguid = profile.guid WHERE fa.guid = ? AND (newest_media_timestamp > NOW() - INTERVAL 1 DAY) AND last_viewed_timestamp IS NOT null ORDER BY `profile`.username ASC LIMIT ?";

    // var oldAlbumsNextSql2 = "SELECT fa.`fguid`, fa.`album_id`, fa.`last_viewed_media_url`, fa.`last_viewed_timestamp`, user_album.`title`, user_album.`cover_album_url`, user_album.`newest_media_timestamp`, user_album.`count`, `profile`.username, `profile`.fullname, `profile`.verified, `profile`.image_url FROM `album_permissions` AS fa INNER JOIN `user_album` ON fa.fguid = user_album.guid AND fa.album_id = user_album.id INNER JOIN `profile` ON fa.fguid = profile.guid WHERE fa.guid = ? AND (newest_media_timestamp > NOW() - INTERVAL 1 DAY) AND `profile`.username > ? AND last_viewed_timestamp IS NOT null ORDER BY `profile`.username ASC LIMIT ?";




/**
 *  Returns: An array
 * 
 * [ {album: x0, profile: y0},
 *   {album: x1, profile: y1}
 * ]
 * 
 * @param {*} myGuid 
 * @param {*} results 
 */

 

    let kFollowersCount = "followersCount";
    let kFollowingCount = "followingCount";
    let kScore          = "score";

    function getAlbumsFromResults(myGuid, results) {
        
        console.log("getAlbumsFromResults called indeed");
        
        var albumsList = [];

        results.forEach((result) => {


            var album = {};

            // Get album cover
            // if (result.is_private) {
            // printTimeForEvent("Start SignedUrl for media url: " + result.cover_album_url);

            var params = {  Bucket  : ALBUM_BUCKET,  
                            Key     : albumCoverThumbnailKey(result.guid, result.cover_album_url), 
                            Expires : S3_EXPIRE_LIMIT 
                        };
            var signedUrl = s3.getSignedUrl('getObject', params);
            // printTimeForEvent("End SignedUrl for media url: " + result.cover_album_url);
            // printTimeForEvent("signedUrl: " + signedUrl);

            album[kSignedUrl]       = signedUrl;

            album[kFirstUrl]        = result.first_url;
            album[kTimestamp]       = result.first_timestamp.toString();

            
            album[kSignedFirstUrl]  = s3.getSignedUrl('getObject', 
                                        {   Bucket  : ALBUM_BUCKET,  
                                            Key     : albumFirstMediaKey(result.guid, result.first_url), 
                                            Expires : S3_EXPIRE_LIMIT 
                                        });

            console.log("getAlbumsFromResults result.album_id: " + result.album_id);

                                        
            album[kAlbumId]              = result.album_id;
            album[kPrivate]              = result.album_is_private;
            album[kTitle]                = result.title;

            album[kExplicit]             = intToBool(result.explicit);

            // if ( validator.isBase64(result.title) ) {
            //     album[kTitle]  = titleToUTF(result.title);
            // } else {
            //     album[kTitle] = result.title; 
            // }
                    
            album[kAlbumCover]           = result.cover_album_url;

            album[kNewestMediaTimestamp] = result.newest_media_timestamp.toString();
            album[kCount]                = result.count; // media count
            
            album[kCreateDate]           = result.create_date.toString();

            album[kExpireDate]           = result.expire_date;
            album[kExpireDays]           = result.expire;



            // if (result.album_is_private === IsPublic) {
                album[kViews]                = result.views;
                album[kLikeCount]            = result.likes;
                album[kDislikeCount]         = result.dislikes;
            // }


            if (result.last_viewed_timestamp !== undefined && result.last_viewed_timestamp !== null ) {
                album[kLastViewedMediaUrl]       = result.last_viewed_media_url;
                album[kLastViewedMediaTimestamp] = result.last_viewed_timestamp.toString();
            }
            var profile = {};

            profile[kGuid]       = result.guid;   
            profile[kUserName]   = result.username;
            profile[kFullName]   = result.fullname;
            profile[kVerified]   = intToBool(result.verified);
            profile[kProfileUrl] = result.image_url;
            profile[kPrivate]    = result.profile_is_private;

            profile[kAllowFollowersView]  = intToBool(result.allow_view_followers);
            profile[kAllowFollowingsView] = intToBool(result.allow_view_followings);

            
            profile[kFollowersCount]  = result.followers;
            profile[kFollowingCount]  = result.following;
            profile[kScore]           = result.popularity === null ? 0 : result.popularity;

            
            var albumInfo = {};
            albumInfo[kAlbum]   = album;
            albumInfo[kProfile] = profile;
            // console.log("result.last_viewed_timestamp mediaContentType of = "  + typeof result.last_viewed_timestamp  );

            albumsList.push(albumInfo);
        });

        return albumsList;
    }

    function titleToBase64(title) {
       return new Buffer(title).toString('base64'); // Buffer.from(originalImage, 'base64');  
    }

    function titleToUTF(base64Title) {
        return new Buffer(base64Title, 'base64').toString('utf8');
    }


    function getNewAlbumResults(myGuid, querySql, parameters) {
        console.log("getNewAlbumResults");
        
        // Get new albums 
        connection.query({
            sql: querySql,
            values: parameters
        }, function (error, results) {
            if (error) {
                printError(error);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results) {
                console.log('New album Results:', JSON.stringify(results, null, 2));

 
                let allAlbums = getAlbumsFromResults(myGuid, results);
                finalAppResponse( getAlbumsResponse( allAlbums)); 

                    // Get more albums from the old albums
                // if ( results.length < MAX_ALBUM_RESULTS ) {

                //     querySql   =  oldAlbumsSql2;
                //     parameters = [guid, MAX_ALBUM_RESULTS ];

                //     getOldAlbum(guid, querySql, parameters, allAlbums );
                // } else {
                //     // Return retults
                //     finalAppResponse( getAlbumsResponse( allAlbums));
                // }
            }
        });
    }



    function getOldAlbum(guid, querySql, parameters, allAlbums) {

        connection.query({
            sql: querySql,
            values: parameters
        },
        function (error, results) {
            if (error) {
                printError(error);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results) {
                console.log('Results:', JSON.stringify(results, null, 2));

                //return results

                allAlbums.oldAlbums = getAlbumsFromResults(guid, results);
                
                finalAppResponse( getAlbumsResponse( allAlbums));
            }
        });
    }


    /**
     * 
     * 
     * 
        INSERT INTO album_timeline (guid, fguid, album_id, date)
        SELECT friends.guid1, ua.`guid`, ua.`id`, UNIX_TIMESTAMP(`newest_media_timestamp`)
        FROM `user_album` AS ua 
            INNER JOIN `friends` 
            ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
                LEFT JOIN album_permissions AS ap 
                ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                INNER JOIN `profile` 
                ON ua.guid = profile.guid 
                    LEFT JOIN album_last_viewed_media AS alvm 
                    ON alvm.guid = friends.guid1 AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
        WHERE (ua.`is_private` = ? OR ap.guid IS NOT NULL) AND (ua.expire_date IS NULL OR ua.expire_date > NOW())    



        INSERT INTO album_timeline (guid, fguid, album_id, date) SELECT friends.guid1, ua.`guid`, ua.`id`, UNIX_TIMESTAMP(`newest_media_timestamp`) FROM `user_album` AS ua INNER JOIN `friends` ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? LEFT JOIN album_permissions AS ap ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) INNER JOIN `profile` ON ua.guid = profile.guid LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = friends.guid1 AND alvm.fguid = ua.guid AND alvm.album_id = ua.id WHERE (ua.`is_private` = ? OR ap.guid IS NOT NULL) AND (ua.expire_date IS NULL OR ua.expire_date > NOW())    



     */


     
    function listFollowingAlbums( myGuid, numberOfAlbums) {
        console.log("listFollowingAlbums");

        // last viewed timestamp 
        
        // Refreshing
        if ( !isStringWithLength(lastTimestamp) ) { //(isRefreshing) {
            console.log("listFollowingAlbums refreshing");

            // console.log("refreshAlbumsSql: " + timelineQuery);

            // var parameters = [myGuid, Relationship.IsFollowing, 0, numberOfAlbums ];
            var parameters = [myGuid, numberOfAlbums ];

            getNewAlbumResults(myGuid, timelineQuery, parameters);

        // Load more
        } else {

            console.log("listFollowingAlbums not refreshing, loading more");
            
            // var parameters = [myGuid, Relationship.IsFollowing, 0, lastTimestamp, numberOfAlbums ];
            var parameters = [myGuid, lastTimestamp, numberOfAlbums ];

            getNewAlbumResults(myGuid, loadMoreTimelineQuery, parameters);
        }

        // var querySql = newAlbumsSql;
        // // var parameters = [Relationship.IsFollowing, 0, guid, guid, guid, pageIndex, MAX_ALBUM_RESULTS ];
        
        
        // // Get new albums
        // getNewAlbumResults(guid, newAlbumsSql, parameters2);
    }
 
 
    // function listFollowingAlbums1(guid) {

    //     var querySql;
    //     var parameters;

    //     // Get only new albums
    //     if ( isRefreshing || lastAlbumWasNew) {

    //         querySql =  newAlbumsSql;
    //         parameters = [guid, pageIndex, MAX_ALBUM_RESULTS ];

    //         // Get new albums
    //         getNewAlbumResults(guid, querySql, parameters);

    //     } else {
                
    //         var allAlbums = {};

    //         querySql =  oldAlbumsNextSql2;
    //         parameters = [guid, lastUsername, MAX_ALBUM_RESULTS ];

    //         getOldAlbum(guid, querySql, parameters, allAlbums);   
    //     }
    // }
 
    // console.log("4");



    /**
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     *  
     * 
     *                     Get media content in Albums
     * 
     * 
     * Since this will be in descending order: earliest to latest, we can use LIMIT offset, count
     * 
     * 
     * 
     * Public Album
     * 
     *  SELECT guid, album_id, `media_url`, `timestamp`, `type`, `timelimit` 
     *  FROM `album_media` 
     *      INNER JOIN user_album
     *      ON user_album.guid = album_media.guid 
     *  WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0
     *  ORDER BY timestamp 
     *  LIMIT ?';
     * 
     * 
     * var parameters = [ fguid, albumId, MAX_ALBUM_RESULTS];
     * 
     * 
     * 
     * 
     *  Private Album
     *
     *      Start from beginning
     * 
     *  SELECT guid, album_id, `media_url`, `timestamp`, `type`, `timelimit` 
     *  FROM `album_media` 
     *      INNER JOIN album_permissions AS ap
     *      ON ap.guid = ? , ap.fguid = album_media.guid ,  ap.album_id =  album_media.album_id
     *  WHERE album_media.guid = ? AND album_id = ?  
     *  ORDER BY timestamp 
     *  LIMIT ?';
     * 
     * 
     *      Continue from newest media in album: by timestamp
     * 
     *  SELECT guid, album_id, `media_url`, `timestamp`, `type`, `timelimit` 
     *  FROM `album_media` 
     *      INNER JOIN album_permissions AS ap
     *      ON ap.guid = ? , ap.fguid = album_media.guid ,  ap.album_id =  album_media.album_id
     *  WHERE album_media.guid = ? AND album_id = ? AND timestamp >= ?
     *  ORDER BY timestamp 
     *  LIMIT ?';
     * 
     * 
     * 
     *     Continue after last seen media in album: by timestamp
     * 
     *  SELECT guid, album_id, `media_url`, `timestamp`, `type`, `timelimit` 
     *  FROM `album_media` 
     *      INNER JOIN album_permissions AS ap
     *      ON ap.guid = ? , ap.fguid = album_media.guid ,  ap.album_id =  album_media.album_id
     *  WHERE album_media.guid = ? AND album_id = ? AND timestamp > ?
     *  ORDER BY timestamp 
     *  LIMIT ?';
     * 
     * 
     * ap.guid = ourGuid,  album_media.guid = friendsGuid, albumId, 



     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     */

    
    

/**
 * 
 */
     function mediaContentResults(sqlStmt, parameters, includeUnseenCount) {
        console.log("mediaContentResults ");

        connection.query({
            sql   : sqlStmt,
            values: parameters, 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results) {

                // console.log('AffectedRows: ' + JSON.stringify(results.affectedRows, null, 2));


                console.log('Results:', JSON.stringify(results, null, 2));
                // console.log('fields:', JSON.stringify(fields, null, 2));

                if (results.length > 0) {

                    // console.log("FOUND_ROWS() is: ");

                    // console.log(rows[0]["FOUND_ROWS()"]);


                    var albums = [];

                    results.forEach((result) => {

                        var album = {};
                        album[kGuid]      = guid;
                        album[kAlbumId]   = albumId; 
                        album[kType]      = result.type; // video, gif, photo
                                    

                        var params = {  Bucket  : ALBUM_BUCKET,  
                                        Key     : albumMediaKey(result.guid, result.media_url, result.type), 
                                        Expires : S3_EXPIRE_LIMIT 
                                    };
                        var signedUrl = s3.getSignedUrl('getObject', params);
                        // printTimeForEvent("End SignedUrl for media url: " + result.media_url);
                        // printTimeForEvent("signedUrl: " + signedUrl);
                        album[kSignedUrl]  = signedUrl;


                        album[kMediaURL]  = result.media_url;
                        
                        album[kTimestamp] = result.timestamp.toString();
                        album[kTimelimit] = result.timelimit

                        console.log("mediaContentResults timestamp: " + result.timestamp);


                        albums.push(album);
                    });


                    if (!includeUnseenCount) {
                        
                        finalAppResponse( mediaResponse( albums));
                    
                    } else {

                        connection.query({
                            sql   : 'SELECT FOUND_ROWS()'                    
                        }, function (err, results) {
                            if (err) {
                                printError(err);
                                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                            } else if (results) {

                                console.log('Results:', JSON.stringify(results, null, 2));



                                if (results.length > 0) {
                                    console.log("FOUND_ROWS() is: " + results[0]["FOUND_ROWS()"]);

                                    var response = {};
                                    response[kActive]  = ActiveValues.Active;
                                    response[kAlbum]   = albums; 
                                    response[kCount]   = results[0]["FOUND_ROWS()"]; 
                                        

                                    finalAppResponse( response );

                                } else {
                                    finalAppResponse( errorResponse( ErrorMessageGeneric));
                                }
                            } else {
                                finalAppResponse( errorResponse( ErrorMessageGeneric));
                            }
                        });
                    }
                } else {
                    // Nothing to downlaod
                    finalAppResponse( errorResponse( "Album does not exist"));
                }
            } else {
                finalAppResponse( errorResponse( ErrorMessageGeneric));
            }
        });         
     }
     

/**
 * 
 * 

 * @param {*} guid 
 * @param {*} fguid 
 * @param {*} albumId 
 * @param {*} lastMediaTime 
 * @param {*} lastMediaUrl 
 * @param {*} numberOfItems = 4
 * 
 * 
 *  SELECT COUNT(*) as unseenCount 
 *  FROM album_last_viewed_media AS flvm 
 *      RIGHT JOIN album_media 
 *      ON flvm.fguid = album_media.guid AND flvm.album_id = album_media.album_id AND flvm.guid = ? 
 *  WHERE album_media.guid = ? AND album_media.album_id = ? AND (flvm.last_viewed_timestamp IS NULL OR album_media.timestamp > flvm.last_viewed_timestamp)'

 * 
 * 
 *  Private unseen photos
 * 
 * 
 *  Also need to get unseenCount 
    SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
    FROM `album_media` AS am 
        INNER JOIN album_permissions AS ap 
        ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id  
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
    WHERE am.guid = ? AND am.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) 
    ORDER BY am.timestamp 
    LIMIT ?';


    var parameters = [guid, fguid, albumId, numberOfItems ];


 */



/**
 * Popularity = followersCount + Views + Likes
 * 
 * 
 * 

Correct:  Add this to query
SELECT COUNT(*) as unseenCount
FROM album_media AS am
	LEFT JOIN album_last_viewed_media AS alvm
	ON alvm.guid = 'us-east-1:614dfefb-191c-4935-8cea-e53af6f320cd#928bc421' AND alvm.fguid = am.guid AND alvm.album_id = am.album_id
WHERE am.guid = 'd9efdfce-1c38-4ae5-89af-5dcca451b18e#f5bbfcdf' AND am.album_id = '3REr3oXBBJ5D' AND (am.timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL )




    SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`, COUNT(*) as unseenCount
    FROM `album_media` AS am 
        INNER JOIN album_permissions AS ap 
        ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id  
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
    WHERE ap.guid = ? AND ap.fguid ? AND ap.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) 
    GROUP BY am.timestamp
    ORDER BY am.timestamp 
    LIMIT ?';
    

        Unchanged
        var sqlStmt = 'SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id  LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE am.guid = ? AND am.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY am.timestamp LIMIT ?';



    

    SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
    FROM `album_media` AS am 
        INNER JOIN album_permissions AS ap 
        ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
    WHERE am.guid = ? AND am.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) 
    ORDER BY am.timestamp 
    LIMIT ?";



 */

    function getPrivateFolloweringUnseenMediaContent( guid, fguid, albumId, numberOfItems ) {
        console.log("getPrivateFolloweringUnseenMediaContent");

        var sqlStmt = "SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE am.guid = ? AND am.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY am.timestamp LIMIT ?";
        // var sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE ap.fguid = ? AND ap.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY am.timestamp LIMIT ?';
 
        // SELECT FOUND_ROWS(); 


        // var sqlStmt = 'SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id  LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE am.guid = ? AND am.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY am.timestamp LIMIT ?';
        var parameters = [guid, fguid, albumId, numberOfItems];

        mediaContentResults(sqlStmt, parameters, true);
    }


/**
 * 
 *  SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
 *  FROM `album_media` 
 *      INNER JOIN album_permissions AS ap 
 *      ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
 *  WHERE am.guid = ? AND am.album_id = ? 
 *  ORDER BY timestamp 
 *  LIMIT ?';
 * 
 * 
 * 
 *  SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
 *  FROM `album_media` 
 *      INNER JOIN album_permissions AS ap 
 *      ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
 *  WHERE am.guid = ? AND am.album_id = ? AND timestamp > ? 
 *  ORDER BY timestamp 
 * LIMIT ?';


 * 
 */
      


    /**
     * This will get items from the start of an album or if lastMedia info is included starts from that item
     * 
     * 
     *  SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
     *  FROM `album_media` AS am 
     *      INNER JOIN album_permissions AS ap 
     *      ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
     *  WHERE am.guid = ? AND am.album_id = ? 
     *  ORDER BY timestamp 
     *  LIMIT ?';

     
     */ 
// UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp
    function getPrivateFolloweringMediaContent( guid, fguid, albumId, lastMediaTime, lastMediaUrl, numberOfItems ) {
        console.log("getPrivateFolloweringMediaContent");

        var sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id WHERE am.guid = ? AND am.album_id = ? ORDER BY timestamp LIMIT ?';
        var parameters = [guid, fguid, albumId, numberOfItems];

        if ( isStringWithLength(lastMediaUrl) && isStringWithLength(lastMediaTime) ) {

            console.log("getPrivateMediaContent lastMediaUrl: " + lastMediaUrl);

            sqlStmt = 'SELECT am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id WHERE am.guid = ? AND am.album_id = ? AND timestamp > FROM_UNIXTIME(?) ORDER BY timestamp LIMIT ?';
            parameters = [guid, fguid, albumId, lastMediaTime, numberOfItems];
           
        }
        mediaContentResults(sqlStmt, parameters, false);
    }


/**
 * 
 *  SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
 *  FROM `album_media` 
 *      INNER JOIN album_permissions AS ap 
 *      ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
 *  WHERE am.guid = ? AND am.album_id = ? 
 *  ORDER BY timestamp DESC
 *  LIMIT ?';
 * 
 * 
 * 
 * SELECT am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
 *  FROM `album_media` 
 *      INNER JOIN album_permissions AS ap
 *      ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
 *  WHERE am.guid = ? AND am.album_id = ? AND timestamp < ? 
 *  ORDER BY timestamp DESC
 * LIMIT ?';
 * 
 * 
 */

    function getPrivateFolloweringPreviousMediaContent( guid, fguid, albumId, lastMediaTime, lastMediaUrl, numberOfItems ) {
        console.log("getPrivateFolloweringPreviousMediaContent");

        var sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` INNER JOIN album_permissions AS ap ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id WHERE am.guid = ? AND am.album_id = ? AND timestamp < FROM_UNIXTIME(?) ORDER BY timestamp DESC LIMIT ?';
        var parameters = [guid, fguid, albumId, lastMediaTime, numberOfItems];

        mediaContentResults(sqlStmt, parameters, false);
    }



/*

     * 
     *  SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, am.`timestamp`, am.`type`, am.`timelimit`
     *  FROM `album_media` AS am 
     *      INNER JOIN album_permissions AS ap 
     *      ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
     *  WHERE am.guid = ? AND am.album_id = ? 
     *  ORDER BY timestamp 
     *  LIMIT ?';



    SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
    FROM `album_media` AS am 
        INNER JOIN album_permissions AS ap 
        ON ap.guid = ? AND ap.fguid = am.guid AND ap.album_id = am.album_id 
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
    WHERE am.guid = ? AND am.album_id = ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) 
    ORDER BY am.timestamp 
    LIMIT ?";

    


        //Start from beginning

    SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, 
            UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit`
    FROM `album_media` AS am 
        INNER JOIN user_album 
        ON user_album.guid = am.guid AND user_album.id = am.album_id 
    WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 
    ORDER BY timestamp 
    LIMIT ?';


    // New Content

    SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, 
        UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
    FROM `album_media` AS am 
        INNER JOIN user_album 
        ON user_album.guid = am.guid AND user_album.id = am.album_id
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = ap.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
   

    WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) 
    ORDER BY timestamp
    LIMIT ?';

            var sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN user_album ON user_album.guid = am.guid AND user_album.id = am.album_id LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = am.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp > FROM_UNIXTIME(?) AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY timestamp LIMIT ?';


    
    SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
    FROM `album_media` AS am 
        INNER JOIN user_album 
        ON user_album.guid = am.guid AND user_album.id = am.album_id 
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = am.guid AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
    WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY timestamp LIMIT ?';

    

    SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
    FROM `album_media` AS am 
        INNER JOIN user_album 
        ON user_album.guid = am.guid AND user_album.id = am.album_id
            LEFT JOIN album_last_viewed_media AS alvm 
            ON alvm.guid = ? AND alvm.fguid = am.guid AND alvm.album_id = am.album_id 
    WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp)
    ORDER BY timestamp LIMIT ?';



*/


    function getPublicMediaContentWithNewContent(guid, fguid, albumId, numberOfItems) {
        console.log("getPublicMediaContentWithNewContent");
        
        var sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN user_album ON user_album.guid = am.guid AND user_album.id = am.album_id LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = ? AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY timestamp LIMIT ?';
        
        var parameters = [ guid, fguid, albumId, numberOfItems];

        if ( isStringWithLength(lastMediaUrl) && isStringWithLength(lastMediaTime) ) {

            console.log("getPublicMediaContentWithNewContent loading more content");
            
            sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN user_album ON user_album.guid = am.guid AND user_album.id = am.album_id LEFT JOIN album_last_viewed_media AS alvm ON alvm.guid = ? AND alvm.fguid = am.guid AND alvm.album_id = am.album_id WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp > ? AND (alvm.last_viewed_timestamp IS NULL OR am.timestamp > alvm.last_viewed_timestamp) ORDER BY timestamp LIMIT ?';
            parameters = [ guid, fguid, albumId, lastMediaTime, numberOfItems];
        }
        //     // This is for when we open an album the existed before and we're starting from where the new media starts
        //    if (typeof(startingWithNewMedia) === "boolean" && startingWithNewMedia) {
        //         sqlStmt = 'SELECT guid, album_id, `media_url`, `timestamp`, `type`, `timelimit` FROM `album_media` INNER JOIN user_album ON user_album.guid = album_media.guid WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp >= ? ORDER BY timestamp LIMIT ?';            
        //         parameters = [ fguid, albumId, lastMediaTime, 4];
        //    }
        // }
        mediaContentResults(sqlStmt, parameters, true);
    }


    /**
     * 
     * 
     
     SELECT am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
     FROM `album_media` AS am 
        INNER JOIN user_album 
        ON user_album.guid = am.guid AND user_album.id = am.album_id 
    WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp > FROM_UNIXTIME(?) 
    ORDER BY timestamp 
    LIMIT ?';            


    SELECT am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` 
    FROM `album_media` AS am 
        INNER JOIN user_album 
        ON user_album.guid = am.guid AND user_album.id = am.album_id 
    WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp > FROM_UNIXTIME(?)
    ORDER BY timestamp LIMIT ?';            



     */
    function getPublicMediaContent(fguid, albumId, numberOfItems) {
        console.log("getPublicMediaContent");
        
        var sqlStmt = 'SELECT SQL_CALC_FOUND_ROWS am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN user_album ON user_album.guid = am.guid AND user_album.id = am.album_id WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 ORDER BY timestamp LIMIT ?';
         
        var parameters = [ fguid, albumId, numberOfItems];

        if ( isStringWithLength(lastMediaUrl) && isStringWithLength(lastMediaTime) ) {
            console.log("getPublicMediaContent loading more content");
            console.log("getPublicMediaContent lastMediaTime: " + lastMediaTime);
            //AND id <> ? 
            sqlStmt = 'SELECT am.guid, am.album_id, am.`media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, am.`type`, am.`timelimit` FROM `album_media` AS am INNER JOIN user_album ON user_album.guid = am.guid AND user_album.id = am.album_id WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp > ? ORDER BY timestamp LIMIT ?';            
            parameters = [ fguid, albumId, lastMediaTime, numberOfItems];
        }

        //     // This is for when we open an album the existed before and we're starting from where the new media starts
        //    if (typeof(startingWithNewMedia) === "boolean" && startingWithNewMedia) {
        //         sqlStmt = 'SELECT guid, album_id, `media_url`, `timestamp`, `type`, `timelimit` FROM `album_media` INNER JOIN user_album ON user_album.guid = album_media.guid WHERE user_album.guid = ? AND user_album.id = ? AND user_album.is_private = 0 AND timestamp >= ? ORDER BY timestamp LIMIT ?';            
        //         parameters = [ fguid, albumId, lastMediaTime, 4];
        //    }
        // }
        mediaContentResults(sqlStmt, parameters, false);
    }


    function getMyMediaContent( guid ) {

        console.log("getMyMediaContent");
        var mediaQuery = 'SELECT `media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, `type`, `timelimit` FROM `album_media` WHERE guid = ? AND album_id = ? ORDER BY timestamp LIMIT ?';

        // var mediaQuery = 'SELECT `media_url`, `timestamp`, `type`, `timelimit` FROM `album_media` WHERE guid = ? AND album_id = ? AND timestamp > NOW() - INTERVAL 1 DAY ORDER BY timestamp LIMIT ?';
        var inputValues = [ guid, albumId, MAX_MEDIA_RESULTS ];

        if (lastMediaUrl !== undefined && lastMediaUrl !== null && lastMediaTime !== undefined && lastMediaTime !== null ) {

            console.log("lastMediaUrl is not null and lastMediaTime is not null");

            mediaQuery = 'SELECT `media_url`, UNIX_TIMESTAMP(`timestamp`) AS timestamp, `type`, `timelimit` FROM `album_media` WHERE guid = ? AND album_id = ? AND timestamp > FROM_UNIXTIME(?) AND media_url <> ? ORDER BY timestamp LIMIT ?';
            // mediaQuery = 'SELECT `media_url`, `timestamp`, `type`, `timelimit` FROM `album_media` WHERE guid = ? AND album_id = ? AND timestamp > NOW() - INTERVAL 1 DAY AND timestamp > ? AND media_url <> ? ORDER BY timestamp LIMIT ?';
            inputValues = [ guid, albumId, lastMediaTime, lastMediaUrl, MAX_MEDIA_RESULTS ];
        }
        
        connection.query({
            sql   : mediaQuery,
            values: inputValues, 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results) {

                console.log('Results:', JSON.stringify(results, null, 2));

                if (results.length > 0) {

                    var objects = [];

                    results.forEach((result) => {

                        var object = {};
                        // object.media = base64Data;
                        object[kGuid]      = guid;
                        object[kAlbumId]   = albumId; 
                        object[kType]      = result.type; // video, gif, photo

                        var params = {  Bucket  : ALBUM_BUCKET,  
                                        Key     : albumMediaKey(guid, result.media_url, result.type), 
                                        Expires : S3_EXPIRE_LIMIT 
                                    };

                                    // albumMediaKey(guid, mediaUrl, mediaType) 
        //                 Key     : albumMediaKey(guid, mediaUrl, mediaContentType), 

                        object[kSignedUrl] = s3.getSignedUrl('getObject', params);

                        object[kMediaURL]  = result.media_url;
                        object[kTimestamp] = result.timestamp.toString();
                        object[kTimelimit] = result.timelimit

                        objects.push(object);
                    });

                    finalAppResponse( mediaResponse( objects));

                } else {
                    // Nothing to downlaod
                    finalAppResponse( errorResponse( "Album does not exist"));
                }
            } else {
                finalAppResponse( errorResponse( ErrorMessageGeneric));
            }
        });
    }




    function getNumberOfUnseenItems() {

        var querySql = 'SELECT COUNT(*) as unseenCount FROM album_last_viewed_media AS flvm RIGHT JOIN album_media ON flvm.fguid = album_media.guid AND flvm.album_id = album_media.album_id AND flvm.guid = ? WHERE album_media.guid = ? AND album_media.album_id = ? AND (flvm.last_viewed_timestamp IS NULL OR album_media.timestamp > flvm.last_viewed_timestamp)'

        var parameters = [guid, fguid, albumId]
        
    }


    
    let NOT_PRIVATE = 0;
    let YES_PRIVATE  = 1;

    // function getPublicAlbum(guid, id) {
    //     /* Confirm Album is in fact public */
    //     connection.query({
    //         sql: 'SELECT is_private FROM `user_album` WHERE guid = ? AND id = ?',
    //         values: [ guid, id ], 
    //     },
    //     function (err, results) {
    //         if (err) {
    //             printError(err);
    //             finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
    //         } else if (results) {
    //             //We do in fact have permission to album
    //             //  Get mediaURls

    //             if (results.length > 0 && results[0].is_private === NOT_PRIVATE) {
            
    //                 getMyMediaContent( guid );

    //             } else {
    //                 // Album doesn't exist
    //                 appResponse(false, null, Messages.AlbumGone);
    //             }
    //         } else {
    //             console.log('Error:', JSON.stringify(err, null, 2));
    //             finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
    //         }
    //     });
    // }




    /**
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     *  
     * 
     *                     Update media content viewed
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     */

     /**
      * If lastMediaUrl is wrong we will get an error return
      */

    //TODO: Shall we place a condition so that  last_viewed_media_url and last_viewed_timestamp are correct and not error
    function didViewFriendMedia( guid, fguid, albumId, lastMediaUrl ) {
        console.log("didViewFriendMedia");

        // var parameters = [guid, fguid, albumId, lastMediaUrl, lastTimestamp];
        // var sqlStmt = "INSERT INTO `album_last_viewed_media` SET guid = ? , fguid = ?, album_id = ?, `last_viewed_media_url` = ?, last_viewed_timestamp = ? ON DUPLICATE KEY UPDATE last_viewed_media_url=VALUES(last_viewed_media_url), last_viewed_timestamp=VALUES(last_viewed_timestamp)",

/**
 * 
 * 
 * 
         *  'INSERT INTO `notifications` (guid, fguid, type) \
            VALUES ? \
            ON DUPLICATE KEY UPDATE type = VALUES(type)'

            INSERT INTO daily_events
            (created_on, last_event_id, last_event_created_at)
            VALUES
            ('2010-01-19', 23, '2010-01-19 10:23:11')
            ON DUPLICATE KEY UPDATE
            last_event_id = IF(last_event_created_at < VALUES(last_event_created_at), VALUES(last_event_id), last_event_id),
            last_event_created_at = IF(last_event_created_at < VALUES(last_event_created_at), VALUES(last_event_created_at), last_event_created_at);

            // Order here matters!!!

            1) last_viewed_media_url = IF(last_viewed_timestamp < VALUES(last_viewed_timestamp), VALUES(last_viewed_media_url), last_viewed_media_url),
            2) last_viewed_timestamp = IF(last_viewed_timestamp < VALUES(last_viewed_timestamp), VALUES(last_viewed_timestamp), last_viewed_timestamp) 
            
            
            

        INSERT INTO `album_last_viewed_media` (guid, fguid, album_id, `last_viewed_media_url`, last_viewed_timestamp) 
        VALUES ? ON DUPLICATE KEY UPDATE last_viewed_media_url = IF(last_viewed_timestamp < VALUES(last_viewed_timestamp), VALUES(last_viewed_media_url), last_viewed_media_url), last_viewed_timestamp = IF(last_viewed_timestamp < VALUES(last_viewed_timestamp), VALUES(last_viewed_timestamp), last_viewed_timestamp) ", //last_viewed_media_url=VALUES(last_viewed_media_url), last_viewed_timestamp=VALUES(last_viewed_timestamp)",


            (SELECT timestamp FROM album_media AS am WHERE am.guid = ? AND am.media_url = ? AND am.album_id = ?)

        


 */
            // Need to get the timestamp from server

        connection.query({
            // sql: "UPDATE `album_last_viewed_media` SET `last_viewed_media_url` = ?, last_viewed_timestamp = ? WHERE `guid` = ? AND `fguid` = ? AND album_id = ?",
            sql: "INSERT INTO `album_last_viewed_media` (guid, fguid, album_id, `last_viewed_media_url`, last_viewed_timestamp) VALUES (?, ?, ?, ?, (SELECT timestamp FROM album_media AS am WHERE am.guid = ? AND am.media_url = ? AND am.album_id = ? LIMIT 1 ) ) ON DUPLICATE KEY UPDATE last_viewed_media_url = IF(last_viewed_timestamp < VALUES(last_viewed_timestamp), VALUES(last_viewed_media_url), last_viewed_media_url), last_viewed_timestamp = IF(last_viewed_timestamp < VALUES(last_viewed_timestamp), VALUES(last_viewed_timestamp), last_viewed_timestamp) ", //last_viewed_media_url=VALUES(last_viewed_media_url), last_viewed_timestamp=VALUES(last_viewed_timestamp)",
            // sql: "INSERT INTO `album_last_viewed_media` SET guid = ? , fguid = ?, album_id = ?, `last_viewed_media_url` = ?, last_viewed_timestamp = ? ON DUPLICATE KEY UPDATE last_viewed_media_url=VALUES(last_viewed_media_url), last_viewed_timestamp=VALUES(last_viewed_timestamp)",
            values: [ guid, fguid, albumId, lastMediaUrl, fguid, lastMediaUrl, albumId ]
        }, function (err, results) {
 
            var didUpdate = false;
            if (err) {
                printError(err);
            } else {
                console.log("didViewFriendMedia ok");
                didUpdate = true;
            }

            // Insert users view history.  (Can be unlimited number of times)
            connection.query({
                sql: 'INSERT INTO media_view_history SET `guid` = ?, `fguid` = ?, `album_id` = ?, media_url = ?',
                values: [guid, fguid, albumId, lastMediaUrl ]
            }, function (err, results) {
                if (err) {
                    printError(err);
                } else {
                    console.log("Insert media_view_history ok");
                }
                finalAppResponse( updateViewResponse(didUpdate));
            });
        });
    } 


    function checkAccessPermissions(guid) {
        console.log("checkAccessPermissions");

        connection.query({
            sql: 'SELECT COUNT(*) as count FROM `album_permissions` WHERE guid = ? AND fguid = ? AND album_id = ?',
            values: [ guid, fguid, albumId ], 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
           
            } else if (results) {
                //We do in fact have permission to album
                //  Get mediaURls

                console.log("checkAccessPermissions results:"  + results);

                if (results.length > 0) {
         
                     if ( action.localeCompare(kDidViewMedia ) === 0) {
                        
                        didViewFriendMedia(guid, fguid, albumId, lastMediaUrl );

                    } else {   

                        finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
                    }

                } else {
                    // Album doesn't exist
                    appResponse(false, null, Messages.AlbumGone);
                }
            } else {
                printError(error);
                finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
            }
        });
    }
    



/**
 * ==========================================================================================
 * ==========================================================================================
 * ==========================================================================================
 *  
 * 
 *                             Create album 
 * 
 * 
 * ==========================================================================================
 * ==========================================================================================
 * ==========================================================================================
 * ==========================================================================================
 */






















 /** 
  * Insert hashtag into `tag` table in background

    This will split the word into substrings for search
  **/

  
    /**
     * 
     *  SOrt hastags either by number of album mentions, or trending
     * 
     *  substring,  word,       count, rank
     *  a ,         apple,      +1,
     *  ap,         apple,      +1,
     *  app,        apple,      +1,
     *  .
     *  .
     *  .
     * apple,       apple,      +1
     *  .
     *  .
     *  .
     *  ppl,        apple,      +1
     * 
     * 
     * 
     *  Search hashtag by trends and most popular
     * 
     *  Table: hashtags
     *  substring,  word,       count, rank
     *  ap,         apple,      2,331,
     *  ap,         apples,       191,
     *  ap,         applegate,    939,
     * 
     * 
        SELECT word, count, 
        FROM hashtags
        WHERE substring = ?
        ORDER BY count LIMIT 100


        how to rank albums when user selects search for 

        Table: tagged_albums
           * PRIMARY KEY =  (tag, guid, album_id)
     *  tag,   guid,    album_id,   rank
     * 
     *  apple, ec#5j,   393f93f,    813
     *  apple, ec#5j,   nf90onf,    329
     *  apple, os#ff,   e90habv,    9,838
     *  apple, 6n#f5,   093h8f3,    1,202
     *  apple, pb#eb,   93nid0w,    790
     *  apple, pb#eb,   nf0ab83,    318
     * tagged_albums
     * 
     * 
     * 
        ====   Insert album  =====

        INSERT INTO tagged_albums
        SET tag = ?, guid = ?, album_id = ?

        [hashtag, guid, albumId ]



        // ONly recent albums? Or best albums with tag?
        ===     Search for  Album for hashtag ========

         SELECT first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, explicit, user_album.`guid`, `id` AS album_id, `count`, `likes`, `dislikes`, `title`, UNIX_TIMESTAMP(`create_date`) AS create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS `newest_media_timestamp`, `cover_album_url`, `views`, user_album.`is_private` AS album_is_private, `profile`.`username` AS username, `profile`.allow_view_followers, `profile`.allow_view_followings, `profile`.`fullname` AS fullname, `profile`.`verified` AS verified, profile.is_private as profile_is_private, profile.about, profile.domain, `profile`.image_url AS image_url 
         FROM `user_album` 
            INNER JOIN tagged_albums ta
            ON `user_album`.`guid` = ta.`guid` AND  user_album.id = ta.album_id
                INNER JOIN `profile` 
                ON `user_album`.`guid` = `profile`.`guid` 
        WHERE profile.`is_private` = 0 AND user_album.`is_private` = 0  AND count > 0  AND tag = ?
        AND newest_media_timestamp > NOW() - INTERVAL ? MINUTE
        ORDER BY 
            LOG10(ABS(likes - dislikes) + 1) * SIGN(likes - dislikes) + (UNIX_TIMESTAMP(create_date) / 300000) DESC
        LIMIT ?, ?';


            LOG10(ABS(likes - dislikes) + 1) * SIGN(likes - dislikes)
            + (UNIX_TIMESTAMP(create_date) / 300000) DESC



        var last23HoursAnd50Minutes = (23*60 + 50) * NUMBER_OF_DAYS_GOOD;
        var maxAlbums = 60;
        var offSet =  currentPage * maxAlbums
       
        [hashtag, interval, offSet, maxAlbums ]

    */



    function searchAlbumsForTag(hashtag) {

        
        var last23HoursAnd50Minutes = (23*60 + 50) * NUMBER_OF_DAYS_GOOD;
        var maxAlbums = 60;
        var offSet =  currentPage * maxAlbums
        // var topTrendingAlbums = 'SELECT `guid`, `id`, `count`, `title`, `create_date`, `newest_media_timestamp`, `cover_album_url` FROM `user_album` WHERE `is_private` = 1 AND score = ? AND views = ? AND newest_media_timestamp > NOW() - INTERVAL ? MINUTE AND count > 0 ORDER BY score DESC LIMIT ?,?';
        var topTrendingAlbums = 'SELECT first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, explicit, user_album.`guid`, `id` AS album_id, `count`, `likes`, `dislikes`, `title`, UNIX_TIMESTAMP(`create_date`) AS create_date, UNIX_TIMESTAMP(`newest_media_timestamp`) AS `newest_media_timestamp`, `cover_album_url`, `views`, user_album.`is_private` AS album_is_private, `profile`.`username` AS username, `profile`.allow_view_followers, `profile`.allow_view_followings, `profile`.`fullname` AS fullname, `profile`.`verified` AS verified, profile.is_private as profile_is_private, profile.about, profile.domain, `profile`.image_url AS image_url FROM `user_album` INNER JOIN tagged_albums ta ON `user_album`.`guid` = ta.`guid` AND  user_album.id = ta.album_id INNER JOIN `profile` ON `user_album`.`guid` = `profile`.`guid` WHERE profile.`is_private` = 0 AND user_album.`is_private` = 0  AND count > 0  AND tag = ? AND newest_media_timestamp > NOW() - INTERVAL ? MINUTE ORDER BY LOG10(ABS(likes - dislikes) + 1) * SIGN(likes - dislikes) + (UNIX_TIMESTAMP(create_date) / 300000) DESC LIMIT ?, ?';
        var parameters = [hashtag, last23HoursAnd50Minutes , offSet, maxAlbums];

        
        connection.query({
            sql: topTrendingAlbums,
            values: parameters
        }, 
        function (error, results, fields) {
            if (error) {
                printError(error);
                finalAppResponse( errorResonse(ErrorMessageGeneric) );
            } else { 
                if (results) {
                    console.log(results.length);
                    console.log("results: " + JSON.stringify(results));


                    let allAlbums = getAlbumsFromResults(results);
                    finalAppResponse( getAlbumsResponse( allAlbums)); 

                }
            }
        });
    }


    /** When to insert this */

    function insertTaggedAlbum(tags, guid, albumId) {
        
        var aclList = [];
        tags.forEach((album) => {
            aclList.push([tag, guid, albumId]);
        });
        

        console.log('insertTaggedAlbum albums:', JSON.stringify(aclList, null, 2));


        connection.query({
            sql: 'INSERT INTO `tagged_albums` (tag, guid, album_id) VALUES ?',
            values: [aclList] , 
        }, 
        function (err, results, fields) {

            console.log("query: " + query);

            if (err) {
                // Rollback on failure
                rollbackErrorResponse(err);
                
            } else {
                // Continue

            }
        });
    }
    
    /** Called when we delete album, maybe change title */
    function deleteTaggedAlbum(guid, albumId) {

        console.log('deleteTaggedAlbum albums:');
        
        connection.query({
            sql: 'DELETE FROM `tagged_albums` guid = ? AND album_id = ?',
            values: [guid, albumId] , 
        }, 
        function (err, results, fields) {

            console.log("query: " + query);

            if (err) {
                // Rollback on failure
                
                 
            } else {

                // Continue

            }
        });
    }
    


    /** Splits tags into substrings */
    function getSubstringsFor(terms) {
        
        var list = [];
        
        for (var index in terms) {
            let term = terms[index];

            for (var startingIndex = 0; startingIndex < term.length; startingIndex++) {
                for (var stringLength = 1; stringLength <= term.length - startingIndex; stringLength++) {
                    let subString = term.substr(startingIndex, stringLength);
                    list.push(subString);
                }
            }
        }
        let filteredKeywords = Array.from(new Set(list));
        return filteredKeywords;
    }

            
    function insertHashTagForBackgroundWork(tag) {
        
    }        

    // On background server
    function updateHashTag(tag) {





 /** 
  * Insert hashtag into `tag` table in background

    This will split the word into substrings for search
  **/

  
    /**
     * 
     *  SOrt hastags either by number of album mentions, or trending
     * 
     * a, apple
     * ap, apple
     * app, apple
     * appl, apple
     * apple, apple
     * 
     *  substring,  word,       count, rank
     *  a ,         apple,      +1,
     *  ap,         apple,      +1,
     *  app,        apple,      +1,
     *  .
     *  .
     *  .
     * apple,       apple,      +1
     *  .
     *  .
     *  .
     *  ppl,        apple,      +1
     * 
     * 
     * 
     *  Search ap: -> Returns list of words
     *  Search hashtag by trends and most popular
     * 
     *  Table: hashtags
     *  substring,  word,       count, rank
     *  ap,         apple,      2,331,
     *  ap,         apples,       191,
     *  ap,         applegate,    939,
     * 
     * 
        SELECT word, count, 
        FROM hashtags
        WHERE substring = ?
        ORDER BY count LIMIT 100

        
     */
        /*
        Nack


        1) After we insert (hashtag, guid, album_id) into tagged_albums

        2) In Background, we insert
            For each substring:
                (substring, word, guid, album_id, date)

        SELECT word, count, 
        FROM hashtags
        WHERE substring = ?
        ORDER BY count LIMIT 100




        INSERT INTO tagged_albums
        SET tag = ?, guid = ?, album_id = ?

        [hashtag, guid, albumId ]

        
            INSERT INTO tags SET word = ?, count = count+1

            var param = [tag];
        */
        
        var sqlQuery = "SELECT word, count, FROM tags WHERE substring = ? ORDER BY count LIMIT 100";
        
    }





    


    /**
     * =========================================================================================
     * 
     *                             Create Public album 
     * 
     * ==========================================================================================
     */
    
     

     /**
      * 

      View my comments:
        SELECT commenter_guid, commenting_to_guid, commenting_on, object_id, comment, date, 
        FROM comments
            INNER JOIN albums
            ON
        WHERE guid = 'commenter_guid'
     

        


      Get Comments for album for viwers and user.
      
        comments_table

        
        commenter_guid, owner_id, album_id, commenting_to_guid, comment, date, 


        SELECT commenter_guid, commenting_to_guid, object_id, comment, date, 
        FROM comments
            INNER JOIN on friends and  permissions 
            
        WHERE owner_id = 'album_owner' AND album_id = 'album_id'



        Select comments with a 4 replies? Show 3 and then show to uesr "View more"


        SELECT commenter_guid, owner_id, album_id, commenting_to_guid, comment, date, 
        FROM comments c1
            LEFT JOIN comments c2
            ON c1.owner_id = c2.owner_id AND c1.album_id = c2.'album_id' AND 

        WHERE owner_id = 'album_owner' AND album_id = 'album_id'



        1) When user changes their username, update all references to username
        
        2) If another user, edits their comment or album title and removes name, remove mention immediately

        after updating username,

        add to cron_background_job, update_username

        SELECT all mentions:

        SELECT each mention replace @username and UPDATE
        m
        mentions table
        
        guid_mentioned,
        mentioned_by_guid,
        mention_type (type: album_title, profile, comment, etc)
        mentioned_in_id, (album_id, comment_id, profile=null)

        

        hashtag table

      */


      
    var MentionType = {
        AlbumTitle               : 0,
        Comment             : 1
    };




    function getNotificationId(results, guid) {
        
        results.forEach((result) => {
            console.log(result);

            if (result.guid.localeCompare( guid ) === 0 ) {
                return result.id;
            } 
        });
        return null;
    }

    function nextMaxNotificationId( id ) {

        if (id === null ) {
            return 0;
        } 
        return id += 1;        
    }

    // Notifications Type
    var NotificationType = {
        SentFollowRequest     : 0,
        ReceivedFollowRequest : 1,
        IsFollowing           : 2,   // You are following JOhn232
        BeingFollowed         : 3,   // JOhn232 is following you
        BlockedUser           : 4,        
        MentionedInAlbum      : 5,
        MentionedInComment    : 6
    };



    function rollbackErrorResponse(err) {
        printError(err);        
        connection.rollback(function() {
           finalAppResponse(errorResponse( ErrorMessageGeneric));
       });
   }

    function rollbackErrorResponseWithMessage(err, message) {
        printError(err);        
        connection.rollback(function() {
           finalAppResponse(errorResponse( message));
       });
   }

   
   

    function createAlbumCommit(albumId) {
        
        connection.commit(function(err) {    
            if (err) {
                rollbackErrorResponse(err);
            } else  {
                console.log('successful commit!');

                console.log('successful commit!');
                finalAppResponse( createAlbumResponse( albumId));
                // finalAppResponse( friendActionResponse( 
                //     true, Relationship.FollowRequested));
            }
        });
    }


    function notificationCommit(albumId) {
        
        connection.commit(function(err) {    
            if (err) {
                rollbackErrorResponse(err);
            } else  {
                console.log('successful commit!');

                console.log('successful commit!');
                finalAppResponse( createAlbumResponse( albumId));
                // finalAppResponse( friendActionResponse( 
                //     true, Relationship.FollowRequested));
            }
        });
    }



    // Send a Follow Request with a private account

    function sendMentionNotifications(guid, albumId, mentionedGuids, callback) {
        
        printTimeForEvent("sendMentionNotifications" );
    
        // See if there is a relationship already
        connection.query({
            sql: "SELECT `guid`, MAX(`id`) as id FROM `notifications` WHERE `guid` in (?)",
            values: [ mentionedGuids ]
        }, 
        function (err, results) {
                
            if (err) { 
                callback(err, results);
            } else if (results && results.length > 0) {
                
                var rows = [];
                results.forEach((result) => {
                    rows.push([ result.guid, nextMaxNotificationId(result.id), guid, NotificationType.MentionedInAlbum]);
                }); 
                
                // See if there is a relationship already
                var query = connection.query({
                    sql: 'INSERT INTO `notifications` (guid, id, fguid, type) VALUES ?',
                    values: [rows]
                },
                function (err, results) {
                    callback(err, results);
                });
            }
        });
    }
        
      
            // get guid of username,
            
            // insert into mentions table
                
            //  Insert into notifications, for each user mentioned, that a user mentioned them

    function insertMentionsForCreatedAlbum(guid, albumId, title ) {

        console.log("insertMentionsForCreatedAlbum");
        
        var possibleMentinos = title.split(" ");

        // find all mentions of any users        
        var allMentions = possibleMentinos.filter(function(word){            
            if (word.startsWith("@")) {
                return word.substring(1);
            }
        });

        // find all hashtags
        var allHashtags = possibleMentinos.filter(function(word){            
            if (word.startsWith("#")) {
                return word.substring(1);
            }
        });


        if ( allMentions.length > 0 ) {
            
            connection.query({
                sql: "SELECT guid FROM profile WHERE username in (?)",
                values: [allMentions] , 
            }, 
            function (err, results, fields) {
    
                console.log("results: " + results);
    
                if (err) {

                    rollbackErrorResponse(err);

                } else if (results && results.length > 0) {
                       
                    var mentionRows = [];
                    var mentionedGuids = [];
                    
                    results.forEach((result) => {
                        mentionedGuids.push([ result.guid ]);
                        mentionRows.push([ result.guid, guid, albumId, MentionType.AlbumTitle]);
                    }); 

                    // INSERT INTO `mentions` ( guid_mentioned, mentioned_by , mentioned_in, mention_type) 
                    //     (SELECT guid, ?, ?, ?
                    //     FROM profile 
                    //     WHERE username in (?)
                    //     )

                    //     param = guid, albumId, MentionType.AlbumTitle
                    

                    connection.query({
                        sql: 'INSERT INTO `mentions` ( guid_mentioned, mentioned_by , mentioned_in, mention_type) VALUES ?',
                        values: [mentionRows] , 
                    }, 
                    function (err, results, fields) {

                        console.log("query: " + query);

                        if (err) {

                            rollbackErrorResponse(err);
                            
                        } else {
                            
                            createAlbumCommit(albumId)            
                            
                            // Insert into notiifications
                            // sendMentionNotifications(guid, albumId, mentionedGuids);
                        }
                    });
                } else {
                    createAlbumCommit(albumId)            
                }
            });
        } else {
            createAlbumCommit(albumId)            
        }

        // if any hashtags, insert into background Worker
        // if any mentions of a username, get guid of username, and insert into mentions table


        // Insert into notifications, for each user mentioned, that a user mentioned them


    }

    

    function insertTaggedAlbum(tags, guid, albumId) {
        
        var aclList = [];
        tags.forEach((album) => {
            aclList.push([tag, guid, albumId]);
        });
        

        console.log('insertTaggedAlbum albums:', JSON.stringify(aclList, null, 2));


        connection.query({
            sql: 'INSERT INTO `tagged_albums` (tag, guid, album_id) VALUES ?',
            values: [aclList] , 
        }, 
        function (err, results, fields) {

            console.log("query: " + query);

            if (err) {
                // Rollback on failure
                rollbackErrorResponse(err);
                
            } else {
                // Continue

            }
        });
    }

     
    var createAlbumErrorMessage = APP_NAME +  " cannot create your album. Try against shortly.";
     
    function insertLikeForUsersCreateAlbum(guid, albumId, title) {
        console.log("insertLikeForUsersCreateAlbum");

        connection.query({
            sql: 'INSERT INTO user_album_likes SET `guid` = ?, `fguid` = ?, `album_id` = ?, `liked` = ?',
            values: [guid, guid, albumId, AlbumLike.liked ], 
        },
        function (err, results, fields) {
            if (err) {
                rollbackErrorResponseWithMessage(err, createAlbumErrorMessage);
                
            } else {

                insertMentionsForCreatedAlbum(guid, albumId, title);

                
                // // addAllFollowersForPublicAlbum(guid, albumId); 
                // connection.commit(function(err) {
                //     if (err) {
                //         // Failed to commit queries. Rollback on failure
                //         rollbackErrorResponseWithMessage(err, createAlbumErrorMessage);
                        
                //     } else  {
                //         insertMentionsForCreatedAlbum(guid, albumId, title);
                //     }
                // });
            }
        });
    }





    
    // TODO: setup groupDictionary
    function createPublicAlbum(guid, daysTillExpire, groupPostersDict) {
        console.log("createAlbum");
        
        var newAlbumId = generateRandomString();
        console.log("guid: " + guid + ", newAlbumId: " +  newAlbumId);

        connection.beginTransaction(function(err) {
            if (err) { 
                rollbackErrorResponse(err);
            } else {

                var sqlStmt = 'INSERT INTO `user_album` SET guid = ' + connection.escape(guid) + ', id = ' + connection.escape(newAlbumId) + ', title = ' + connection.escape(title) + ', is_private = ' + IsPublic + ', likes =' + 1;


                // var sqlStmt = 'INSERT INTO `user_album` SET ?';

            //     var paramsAlbum = {
            //         guid        : guid,
            //         id          : newAlbumId,
            //         title       : title,
            //         is_private  : IsPublic,
            //         likes       : 1
            //    };

                if (daysTillExpire !== null) {
                    sqlStmt = 'INSERT INTO `user_album` SET guid = ' + connection.escape(guid) + ', id = ' + connection.escape(newAlbumId) + ', title = ' + connection.escape(title) + ', is_private = ' + IsPublic + ', likes =' + 1 + ', expire = ' + connection.escape(daysTillExpire) + ', expire_date = DATE_ADD(NOW(), INTERVAL ' + connection.escape(daysTillExpire) + ' DAY)';
                }
 
                connection.query({
                    sql     : sqlStmt
                    // values  : paramsAlbum 
                },
                function (err, results, fields) {

                    if (err) {
                        if (err.code == "ER_DUP_ENTRY" && maxDuplicateRetires > 0) {
                            console.log("Album Id already exists. That's why I'm here to catch it!");
                            
                            maxDuplicateRetires -= 1;

                            createPublicAlbum(guid, daysTillExpire, groupPostersDict);
                            
                        } else {
                            
                            rollbackErrorResponseWithMessage(err, createAlbumErrorMessage);
                                              
                        }   
                    } else {
                        console.log("Results: " + results);
                        insertLikeForUsersCreateAlbum(guid, newAlbumId, title);            
                    }
                });
            }
        });
    }


//  *      How to get random 40 items
//  *        
//  *          Trending/Popular
//  * 
//  *      SELECT *
//  *      FROM popular_albums
//  *      WHERE likes = ?  AND views = ? 
//  *      
//  * 


// 'INSERT INTO `album_permissions` (guid, fguid, album_id) 
// SELECT `guid2` as guid, ? , ?
// FROM `friends` 
// WHERE `guid1` = ? AND (`status` = ? OR `status` = ? )',
            // [ guid, albumId, guid, Relationships.AcceptedFriendRequest, Relationships.FriendAcceptedRequest ]

// INSERT INTO Results ( People, names )
// VALUES
//     (
//      (SELECT d.id
//        FROM Names f
//        JOIN People d ON (d.id  = f.id) limit 1
//      ),
//      ("Henry"),
//     );



    function addAllFollowersForPublicAlbum(guid, albumId) {
        console.log("getAllFriends");
        connection.query({
            sql: 'INSERT INTO `album_permissions` (guid, fguid, album_id) SELECT `guid1` as guid, ? , ? FROM `friends` WHERE `guid2` = ? AND `status` = ?',
            values: [ guid, albumId, guid, Relationship.IsFollowing] 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, createAlbumErrorMessage ));
            } else {
                 connection.commit(function(err) {
                    if (err) {
                        // Failed to commit queries. Rollback on failure
                        rollbackErrorResponseWithMessage(err, createAlbumErrorMessage);
                        
                    } else  {
                        console.log('successful commit!');
                        finalAppResponse( createAlbumResponse( albumId));
                    }
                 });   
            }
        });
    }





    function addUsersToACL(guid, albumId, followersGuids) {

        console.log("addUsersToACL");

        var aclList = [];

        followersGuids.forEach((followerGuid) => {
            aclList.push([ followerGuid, guid, albumId ]);
        });

        console.log('aclList:', JSON.stringify(aclList, null, 2));


        var query = connection.query({
            sql: 'INSERT INTO `album_permissions` (guid, fguid, album_id) VALUES ?',
            values: [aclList] , 
        }, 
        function (err, results, fields) {

            console.log("query: " + query);

            if (err) {
                // Rollback on failure
                rollbackErrorResponse(err);                
                
            } else {
                 // Commit queries
                connection.commit(function(err) {
                    if (err) {
                        // Failed to commit queries. Rollback on failure
                        rollbackErrorResponse(err);                                        
                         
                    } else  {
                        console.log('successful commit!');

                        finalAppResponse( createAlbumResponse( albumId));
                    }
                });
            }
        });
    }




    
    var IsPrivate = 1;
    var IsPublic  = 0;

    /**
     * Change this later: daysTillExpire can be null if it is to never expire. 
     * @param {*} guid 
     * @param {*} followersGuids 
     * @param {*} daysTillExpire 
     */
    function createPrivateAlbum(guid, followersGuids, daysTillExpire) {
    
        console.log("createAlbum");

        var newAlbumId = generateRandomString();

        console.log("guid: " + guid + ", newAlbumId: " +  newAlbumId);

        connection.beginTransaction(function(err) {
            if (err) {
                printError(err);                
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else {


                var sqlStmt = 'INSERT INTO `user_album` SET guid = ' + connection.escape(guid) + ', id = ' + connection.escape(newAlbumId) + ', title = ' + connection.escape(title) + ', is_private = ' + IsPrivate + ', likes =' + 1;
                if (daysTillExpire !== null) {
                    sqlStmt = 'INSERT INTO `user_album` SET guid = ' + connection.escape(guid) + ', id = ' + connection.escape(newAlbumId) + ', title = ' + connection.escape(title) + ', is_private = ' + IsPrivate + ', likes =' + 1 + ', expire = ' + connection.escape(daysTillExpire) + ', expire_date = DATE_ADD(NOW(), INTERVAL ' + connection.escape(daysTillExpire) + ' DAY)';
                }

                connection.query({
                    sql : sqlStmt
                }, 
                function (err, results, fields) {

                    if (err) {
                        if (err.code == "ER_DUP_ENTRY" && maxDuplicateRetires > 0) {
                            maxDuplicateRetires -= 1;

                            console.log("Media url already exists. That's why I'm here to catch it!");
                            createPrivateAlbum(guid, followersGuids, daysTillExpire);
                        
                        } else {
                            rollbackErrorResponseWithMessage(err, createAlbumErrorMessage);
                                        
                        }   
                    } else {
                        console.log("Results: " + results);
                        
                        addUsersToACL(guid, newAlbumId, followersGuids);            
                    }
                });
            }
        });
    }





    // function getFriendsNotIncluded(guid, daysTillExpire) {

    //     console.log("getFriendsNotExcluded");

    //     var queryFriendsSql = 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `guid1` NOT IN (?) AND `status` = ?';
    //     var parameters = [ guid, followersAddList, Relationship.IsFollowing ];
      
    //     if ( followersAddList === undefined || followersAddList === null || followersAddList.length === 0) {
    //         queryFriendsSql = 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `status` = ?';
    //         parameters      = [ guid, Relationship.IsFollowing ];
    //     }

    //     connection.query({
    //         sql: queryFriendsSql,
    //         values: parameters, 
    //     }, 
    //     function (err, results) {
    //         if (err) {
    //             printError(err);
    //             finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
    //         } else {

    //             if (results && results.length > 0) {

    //                 var guids = [];
    //                 results.forEach((result) => {
    //                     guids.push(result.guid);
    //                 });

    //                 createPrivateAlbum(guid, guids, daysTillExpire );
    //             } else {
    //                 console.log('Error:', JSON.stringify(err, null, 2));
    //                 finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
    //             }
    //         }
    //     });
    // }




    /**
     * 
     * guid1 is the person following
     * guid2 is the person being followed
     * 
     * guid1 is following guid2
     * If not SubmittingToAll, so only add people I've seleclted
     */


    function prepareFollowersForCreatePrivateAlbum(guid, daysTillExpire, followersAddList, groupPostersDict) {

        console.log("prepareFollowersForCreatePrivateAlbum");
        
        getConfirmedFollowerGuids(guid, followersAddList, function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else {

                if (results && results.length > 0) {

                    var followerGuids = [];
                    results.forEach((result) => {
                        followerGuids.push(result.guid);
                    }); 

                    createPrivateAlbum(guid, followerGuids, daysTillExpire);
                } else {
                    printError(error);
                    finalAppResponse( activeResponse(ActiveValues.Active, "Couldn't find any of your selected followers" ));
                }
            }
        });
    }

    function getIncludedFriends(guid, daysTillExpire, followersAddList) {

        console.log("getIncludedFriends");

        var queryFriendsSql = 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `guid1` IN (?) AND `status` = ?';

        connection.query({
            sql: queryFriendsSql,
            values: [ guid, followersAddList, Relationship.IsFollowing ], 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else {

                if (results && results.length > 0) {

                    var followerGuids = [];
                    results.forEach((result) => {
                        followerGuids.push(result.guid);
                    }); 

                    createPrivateAlbum(guid, followerGuids , daysTillExpire);
                } else {
                    printError(error);
                    finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                }
            }
        });
    }




    /**
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     *  
     * 
     *                                   Delete album 
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     */



    function deleteAllS3Media(guid, mediaUrlResults, albumId) {

        // Get array of Key: string for delteing

        // Maximum keys we can delete is 1,000
        let third = 333;
        let first500Results = mediaUrlResults.splice(0, third);

        var keys = [];
        
        first500Results.forEach((result) => {
            var mediaUrl = result.media_url;
            var mediaType = result.type;
            keys.push({ Key : albumMediaKey(guid, mediaUrl, mediaType)  });
            keys.push({ Key : albumCoverKey(guid, mediaUrl)  });
            keys.push({ Key : albumCoverThumbnailKey(guid, mediaUrl)  });
        });

        console.log('deleteAllS3Media keys:', JSON.stringify(keys, null, 2));


        var paramsDeleteMedia = {
            Bucket: ALBUM_BUCKET,
            Delete: { 
                Objects: keys,
                Quiet: true
            }
        };
        
        s3.deleteObjects(paramsDeleteMedia, function(err, data) {
            if (err) {
                printError(err);    
                rollbackAppError(errorMessageDeleteAlbum);
            } else {
                console.log(data);           // successful response

                // If anymore results left over, delete more content
                if (mediaUrlResults.length > 0) {
                    deleteAllS3Media(guid, mediaUrlResults, albumId);
                } else {
                    commitTransaction(albumId);
                }
            }
        });
    }

    function updateAlbumCount(guid, deleteResults, albumId) {
        
        console.log("updateAlbumCount - guid: " + guid + "from albumId: " +  albumId);

        connection.query({
            sql: 'UPDATE user_album SET `count` = 0 WHERE `guid` = ? AND `id` = ?',
            values: [guid, albumId], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else if (results && results.affectedRows > 0 && deleteResults != null) {

                console.log('Results:', JSON.stringify(results, null, 2));
                deleteAllS3Media(guid, deleteResults, albumId);

            } else {
                // doesn't exist? So we're good
                commitTransaction(albumId);
            }
        });
    }

    function deleteAllMedia( guid, deleteResults, albumId ) {
        
        console.log("DeleteAllMedia - guid: " + guid + "from albumId: " +  albumId);

        connection.query({
            sql: 'DELETE FROM `album_media` WHERE `guid` = ? AND `album_id` = ?',
            values: [guid, albumId], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else if (results && results.affectedRows > 0) {

                console.log('Results:', JSON.stringify(results, null, 2));
                updateAlbumCount(guid, deleteResults, albumId);

            } else {
                // doesn't exist? So we're good
                updateAlbumCount(albumId);
            }
        });
    }


 
    // THis has to be a transaction, delete all media content then delete album


    // function deleteAlbum(guid, albumId) {
    
    //     console.log("deleteAlbum");
    //     console.log("guid: " + guid + ", Deleteing albumId: " +  albumId);

    //     connection.query({
    //         sql: 'DELETE FROM `user_album` WHERE `guid` = ? AND `id` = ?',
    //         values: [guid, albumId], 
    //     }, 
    //     function (err, results, fields) {

    //         if (err) {
    //             printError(err);
                // finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
    //         } else if (results && results.affectedRows > 0) {

    //             console.log("Results: " + results);                    
    //             callback(null, appResponse(true, albumId));
    //         } else {
                
    //             callback(null, appResponse(true, albumId));
    //         }
    //     });
    // }


    function selectAllMediaToDeleteFromAlbum( guid, albumId ) {
        
        console.log("selectAllMediaToDeleteFromAlbum - guid: " + guid + "from albumId: " +  albumId);

        connection.query({
            sql: 'SELECT media_url, type FROM `album_media` WHERE `guid` = ? AND `album_id` = ?',
            values: [guid, albumId], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else if (results && results.length > 0) {

                console.log('selectAllMediaToDeleteFromAlbum: Results:', JSON.stringify(results, null, 2));

                deleteAllMedia(guid, results, albumId);
            } else {
                // doesn't exist? So we're goo
                console.log('selectAllMediaToDeleteFromAlbum results.length == 0');
                updateAlbumCount(guid, null, albumId);
            }
        });
    }
    


    /**
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * 
     * 
     *                              	    DELETE MEDIA
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * 
     */


     // Call this only after confirming album_medial does not contain links to other albums
     //  image/video exists somewhere else
    // Here do callback for succes after commit
    function deleteFromS3(guid, albumId, mediaUrl, mediaType) {

// commit deletion and ocntinue on to deleteing from S3
        // Commit queries
        connection.commit(function(err) {
            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else  {
                console.log('successful commit!');
                
                var paramsDeleteMedia = {
                    Bucket: ALBUM_BUCKET,
                    Delete: { 
                        Objects: [
                            { Key : albumMediaKey(guid, mediaUrl, mediaType) },
                            { Key : albumCoverKey(guid, mediaUrl) },
                            { Key : albumCoverThumbnailKey(guid, mediaUrl) }
                            
                        ],
                        Quiet: true
                    }
                };

                s3.deleteObjects(paramsDeleteMedia, function(err, data) {
                    if (err) {
                        printError(err);     
                        // rollbackAppError(errorMessageDeleteAlbum);
                    } else {
                        console.log(data);           // successful response
                    }
                    var response = {};
                    response[kActive]  = ActiveValues.Active;
                    response[kAlbumId] = albumId;
                    finalAppResponse( response);
                });
            }
        });
    }


/**
 * 
 * Table: user_album

count
newest_media_timestamp
cover_album_url



1   2   3


If we delete 1,
Then update 2 as the first

If we delete 2, then nothing

If we delete 3, then update 2 as the newest_Media



TODO: Fix cover_album, isn't the first, last, or can it change with user selection

 *  UPDATE user_album ua 
 *      INNER JOIN (
 *          SELECT  guid,  album_id,  media_url as second_url, `timestamp`
 *          FROM album_media 
 *          WHERE guid = ? AND album_id = ? 
 *          ORDER BY timestamp 
 *          LIMIT 1
 *      ) am 
 *      ON ua.guid = am.guid AND ua.id = am.album_id 
     SET ua.`first_url` = am.second_url, 
 *      ua.`newest_media_timestamp` = am.timestamp, 
 *      ua.count = ua.count-1"
 * WHERE ua.guid = ? AND ua.id = ?
 */
 
 

    // If we delete secornd or ler media, then no need to update.
    // Only if we delete first media, do we update second media to first
    function updateUserAlbumForFirstMediaAfterDeletingMedia(guid, albumId, mediaUrl, type, deletedTimestamp) {

        connection.query({
            sql: "SELECT  guid,  album_id, media_url as second_url, `type`, UNIX_TIMESTAMP(`timestamp`) AS timestamp FROM album_media WHERE guid = ? AND album_id = ? ORDER BY timestamp DESC LIMIT 2",
            values: [guid, albumId], 
        },
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } 

            if (results) {

                if (result.length == 0) { // No items left
                
                    // Delete album
                    check_if_any_other_albums_have_a_link_to_media_content();
               
                // Regardless if 1 or two items are returned
                } else if ( deletedTimestamp < results[0].timestamp) {

                    // It is the first and last, update however

                    // There are at least two items
                    // If deleted timestamp is before the current first item, then it's the second and we neeed to update
            

                    let firstResult = results[0];

                    var second_url =  mediaKeyWithExtension(firstResult.second_url, firstResult.type);
                    
                    connection.query({
                        sql: "UPDATE user_album ua SET ua.`first_url` = ?, ua.first_timestamp = ?, ua.count = ua.count-1 WHERE ua.guid = ? AND ua.id = ?",
                        values: [second_url, firstResult.timestamp, guid, albumId], 
                    },
                    function (err, results, fields) {

                        if (err) {
                            printError(err);
                            rollbackAppError(ErrorMessageGeneric);
                        } else {
                            
                            // We're done, wo don't care about hte length, because we know we deleted teh first item
                            commitDeleteMedia(albumId);
                        }
                    });
                } else {
                    updateUserAlbumToLastMedia(guid, albumId, mediaUrl, type);
                }
            } else {

                rollbackAppError(ErrorMessageGeneric);

            }
        });

    }
    
    function commitDeleteMedia(albumId) {
        connection.commit(function(err) {
            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else  {
                console.log('successful commit!');
                var response = {};
                response[kActive]  = ActiveValues.Active;
                response[kAlbumId] = albumId;
                response[kSuccess] = true;
                finalAppResponse( response);
            }
        });
    }


    /**
     * Updates the url is we deleted the last media item
     *  
     *  If not, then at least we update the media count
     * 
     * 
     * 
     *  UPDATE user_album ua 
     *      INNER JOIN (
     *          SELECT guid, album_id, media_url as newest_url, `timestamp` AS newest_ts 
     *          FROM album_media WHERE guid = ? AND album_id = ? 
     *          ORDER BY newest_ts DESC 
     *          LIMIT 1 
     *      ) am 
     *      ON ua.guid = am.guid AND ua.id = am.album_id 
     *  SET ua.`cover_album_url` = am.newest_url, ua.`newest_media_timestamp` = am.newest_ts, ua.count = ua.count-1 
     *  WHERE ua.guid = ? AND ua.id = ?",
     */

    function updateUserAlbumToLastMedia(guid, albumId, mediaUrl, type) {
        
        console.log("updateUserAlbumToLastMedia");
        console.log("guid: " + guid + ", Deleteing mediaUrl: " +  mediaUrl + "from albumId: " +  albumId);

        connection.query({
            sql: "UPDATE user_album ua INNER JOIN (SELECT  guid,  album_id,  media_url as newest_url, `timestamp` AS newest_ts FROM album_media WHERE guid = ? AND album_id = ? ORDER BY newest_ts DESC LIMIT 1 ) am ON ua.guid = am.guid AND ua.id = am.album_id SET ua.`cover_album_url` = am.newest_url, ua.`newest_media_timestamp` = am.newest_ts, ua.count = ua.count-1 WHERE ua.guid = ? AND ua.id = ?",
            values: [guid, albumId, guid, albumId], 
        },
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);

            } else if (results && (result.changedRows > 0 || result.affectedRows > 0)) {

                console.log('changed ' + result.changedRows + ' rows');
                console.log('deleted ' + result.affectedRows + ' rows');


                check_if_any_other_albums_have_a_link_to_media_content( guid, albumId, mediaUrl, type );

                /**
                 * 1) check_if_any_other_albums_have_a_link_to_media_content( guid, albumId );
                 * 2) If done, commit
                 * 3) Else delete album then
                 *      3a) Delete s3 
                 */
            

                // deleteFromS3(guid, albumId, mediaUrl, type);


                // If we were NOT able to update the album, then delete album
                // No reason to keep the album around, if no media exists
                // if (result.changedRows == 0) {
                //     // Check if count = 0 and we should delete album 
                //     //  deleteAlbum(guid, albumId);

                // } else {
                //     //Keep album around
                //     check_if_any_other_albums_have_a_link_to_media_content( guid, albumId );
                // }

            } else {
                
                rollbackAppError(ErrorMessageGeneric);
            }
        });
    }


            // checkIfMediaUrlHasLinksToOtherAlbums
    function check_if_any_other_albums_have_a_link_to_media_content( guid, albumId, mediaUrl, type ) {

//             sql: 'SELECT count FROM `user_album` WHERE `guid` = ? AND `id` = ?',

        connection.query({
            sql: 'SELECT COUNT(*) as count FROM `album_media` WHERE `guid` = ? AND `media_url` = ?',
            values: [ guid, mediaUrl ]
        }, function (err, results) {
            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else if (results) {

                if (results.length > 0) { // Other albums connected

                    console.log('Results:', JSON.stringify(results, null, 2));

                    // Don't delete image/video because it exists somewhere else
                    
                    // commitTransaction(albumId);
                    deleteAlbum(guid, albumId);

                } else { // No other album has connection to media, Delete it
                    
                    deleteAlbumAndS3(guid, albumId, mediaUrl, type);
                }
            } else {
                rollbackAppError(ErrorMessageGeneric);
            }
        });
    }
        

        //             if any other albums contains the mediaUrl:
        //                 DO NOT DELETE FROM S3
        //             ELSE: 
        //                 Delete from S3

        // If other albums have a link to S3 media, return successful callback

        // If no album links to media, then continue to delete from S3  -> deleteFromS3();
    
    
    /**
     * 
     * @param {String} guid 
     * @param {String} albumId 
     * @param {String} mediaUrl 
     * @param {String} type 
     */

    function deleteAlbumAndS3(guid, albumId, mediaUrl, type) {
    
        console.log("deleteAlbum");
        console.log("guid: " + guid + ", Deleteing albumId: " +  albumId);

        connection.query({
            sql: 'DELETE FROM `user_album` WHERE `guid` = ? AND `id` = ?',
            values: [guid, albumId], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else if (results && results.affectedRows > 0) {

                console.log("Results: " + results);       

                deleteFromS3(guid, albumId, mediaUrl, type);
            } else {
                rollbackAppError(ErrorMessageGeneric);
            }
        });
    }

    function deleteAlbum(guid, albumId) {
    
        console.log("deleteAlbum");
        console.log("guid: " + guid + ", Deleteing albumId: " +  albumId);

        connection.query({
            sql: 'DELETE FROM `user_album` WHERE `guid` = ? AND `id` = ?',
            values: [guid, albumId], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else {
                commitDeleteMedia(albumId);
            }
        });
    }



    /**
     * Deletes a media item for given albumId, but other albums will still have access to it.
     * 
     * @param {*} guid 
     * @param {*} albumId 
     * @param {*} mediaUrl 
     * @param {*} type 
     */
    function deleteAlbumMedia(guid, albumId, mediaUrl, type, timestamp) {    
        console.log("DeleteAlbumMedia - guid: " + guid + ", Deleteing mediaUrl: " +  mediaUrl + "from albumId: " +  albumId);

        connection.query({
            sql: 'DELETE FROM `album_media` WHERE `guid` = ? AND `album_id` = ? AND `media_url` = ?',
            values: [guid, albumId, mediaUrl], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(ErrorMessageGeneric);
            } else if (results && results.affectedRows > 0) {

                console.log("Results: " + results);
                updateUserAlbumForFirstMediaAfterDeletingMedia(guid, albumId, mediaUrl, type, timestamp);

            } else {
                // doesn't exist? So we're good
                // commitTransaction(albumId);
                rollbackAppError(ErrorMessageGeneric);

            }
        });
    }




    /**
     * 
     *  Deleting media_url is a bit complicated because we may have one media item in multiple albums 
     * @param {*} guid 
     * @param {*} albumId 
     * @param {*} mediaUrl 
     */

    function startDeleteMediaTransaction(guid, albumId, mediaUrl) {
        
        console.log("startDeleteMediaTransaction");

        connection.query({
            sql: 'SELECT type, timestamp FROM `album_media` WHERE `guid` = ? AND `album_id` = ? AND `media_url` = ?',
            values: [guid, albumId, mediaUrl], 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results && results.length > 0) {

                let type      = results[0].type;
                let timestamp = results[0].timestamp;

                connection.beginTransaction(function(err) {
                    if (err) { 
                        printError(error);
                        rollbackAppError(ErrorMessageGeneric);
                    } else { 
                        deleteAlbumMedia(guid, albumId, mediaUrl, type, timestamp);
                    }
                });
            } else {
                // finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                var response = {};
                response[kActive]  = ActiveValues.Active;
                response[kAlbumId] = albumId;
                finalAppResponse( response);
            }
        });
    }





    /**
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * 
     * 
     *                                  UPDATE  ALBUM
     * 
     *                                   title or ACL
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * 
     */



    console.log("8");

    function updateTitle(guid) {
        
        console.log("updateTitle");

        var updateAlbumSql = "UPDATE `user_album` SET `title` = ? WHERE `guid` = ? AND `id` = ?";
            
        var query = connection.query({
            sql: updateAlbumSql,
            values: [ title , guid, albumId], 
        }, 
        function (error, results, fields) {

            console.log("getting Friends done");

            if (error) {
                printError(error);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            }

            if (results) {
                console.log('==== Printing out Results for ' + results.length +  ' rows ====');

                finalAppResponse( createAlbumResponse( albumId));
            }
        });
    }


    function confirmFollowings(guid, friendsToAdd, friendsToDelete, updateFollowersAddingAndDeleting) {

        console.log("confirmFollowings");

        var queryFriendsSql = 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `guid1` in (?) AND `status` = ?';

        connection.query({
            sql: queryFriendsSql,
            values: [ guid, friendsToAdd, Relationship.IsFollowing ], 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                rollbackAppError(updateFollowersErrorMessage);
            } else {

                var followersGuids = [];

                if (results && results.length > 0) {

                    results.forEach((result) => {
                        followersGuids.push(result.guid);
                    });

                    if ( updateFollowersAddingAndDeleting ) { // Delete first

                        connection.beginTransaction(function(err) {
                            if (err) { 
                                printError(err);
                                rollbackAppError(updateFollowersErrorMessage);
                            } else { 
                                updateDeleteFriendsFromPrivateAlbum(guid, friendsToDelete, followersGuids, updateFollowersAddingAndDeleting);
                            }
                        });
                    } else {
                        
                        updateAddFriendsToPrivateAlbum(guid, followersGuids, updateFollowersAddingAndDeleting);
                    }

                // No friends to add, move on to delteing them
                } else {
                    updateAddFriendsToPrivateAlbum(guid, followersGuids, false);
                }
            }
        });
    }



    
    function updateAddFriendsToPrivateAlbum(guid, followersGuids, updateFollowersAddingAndDeleting) {

        var aclList = [];

        followersGuids.forEach((followerGuid) => {
            aclList.push([ followerGuid, guid, albumId ]);
        });

        var query = connection.query({
            sql: 'INSERT INTO `album_permissions` (guid, fguid, album_id) VALUES ?',
            values: [aclList] , 
        }, 
        function (err, results, fields) {

            if (err) {
                printError(err);
                rollbackAppError(updateFollowersErrorMessage);
            } else {

                if (updateFollowersAddingAndDeleting) {
                    // Commit queries
                    
                    connection.commit(function(err) {
                        if (err) {
                            printError(err);
                            rollbackAppError(updateFollowersErrorMessage);
                        } else  {
                            console.log('successful commit!');

                            finalAppResponse( createAlbumResponse( albumId));
                        }
                    });
                } else {
                    finalAppResponse( createAlbumResponse( albumId));                    
                }
            }
        });
    }


    function updateDeleteFriendsFromPrivateAlbum(guid, followersToDelete, followersGuids, updateFollowersAddingAndDeleting) {           

        connection.query({
            sql: "DELETE FROM `album_permissions` WHERE guid IN (?) AND fguid = ? AND album_id = ?",
            values: [ followersToDelete, guid, albumId ]
        }, function (error, results) {
            if (error) {
                printError(error);
                rollbackAppError(updateFollowersErrorMessage);
            } else {
                // if (results > 0) {
                console.log('Results: Changed ' + results.changedRows + "rows");

                if (updateFollowersAddingAndDeleting) {
                    updateAddFriendsToPrivateAlbum(guid, followersGuids, updateFollowersAddingAndDeleting);
                } else {
                    finalAppResponse( createAlbumResponse( albumId));                    
                }
            }
        });        
    }




    let updateFollowersErrorMessage = APP_NAME + " cannot update followers at this time. Try again soon";

    function updateACL(guid, followersToAdd, followersToDelete) {
        console.log("UpdateAction.Friends");

        if (followersToDelete !== null && followersToAdd !== null) {
            
            confirmFollowings(guid, followersToAdd, followersToDelete, true );
             
        } else if (followersToDelete !== null ) {

            updateDeleteFriendsFromPrivateAlbum(guid, followersToDelete, null, false);

        } else {
            confirmFollowings(guid, followersToAdd, null, false );
        }
    }


    let ChangePrivacyErrorMessage = APP_NAME + " cannot make album private at this time. Try again soon"
    
    function changeAlbumToPrivateWithACL(guid, albumId, followersAddList ) {
        
        connection.query({
            sql: 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `guid1` in (?) AND `status` = ?',
            values: [ guid, followersAddList, Relationship.IsFollowing ], 
        }, 
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ChangePrivacyErrorMessage ));
            } else {

                if (results && results.length > 0) {
                    
                    var aclList = [];

                    results.forEach((result) => {
                        aclList.push([ result.guid, guid, albumId ]);
                    });


                    connection.beginTransaction(function(err) {
                        if (err) { 
                            printError(error);
                            rollbackAppError(ChangePrivacyErrorMessage);
                        } else { 
                            connection.query({
                                sql: 'INSERT INTO `album_permissions` (guid, fguid, album_id) VALUES ?',
                                values: [aclList] , 
                            }, 
                            function (err, results, fields) {

                                if (err) {
                                    printError(err);
                                    rollbackAppError(ChangePrivacyErrorMessage);
                                } else {
                                    connection.query({
                                        sql: 'UPDATE user_album SET `is_private` = 1 WHERE `guid` = ? AND `id` = ?',
                                        values: [guid, albumId]
                                    }, 
                                    function (err, results, fields) {

                                        if (err) {
                                            printError(err);
                                            rollbackAppError(ChangePrivacyErrorMessage);
                                        } else {
                                            commitTransaction(albumId);
                                        }
                                    });
                                }
                            });
                        }
                    });
                } else {
                    finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                }
            }
        });    
    }

    

    function changeAlbumToPublic(guid, albumId ) {

        connection.beginTransaction(function(err) {
            if (err) { 
                printError(error);
                rollbackAppError(ErrorMessageGeneric);
            } else { 
                connection.query({
                    sql: "DELETE FROM `album_permissions` WHERE fguid = ? AND album_id = ?",
                    values: [ guid, albumId ]
                }, function (err, results) {
                    if (err) {
                        printError(err);
                        finalAppResponse( updateViewResponse(false));
                    } else {
                        connection.query({
                            sql: 'UPDATE user_album SET `is_private` = 0 WHERE `guid` = ? AND `id` = ?',
                            values: [guid, albumId]
                        },
                        function (err, results, fields) {

                            if (err) {
                                printError(err);
                                rollbackAppError(ErrorMessageGeneric);
                            } else {
                                commitTransaction(albumId);
                            }
                        });
                    }
                });
            }
        });
    }

    // function updateAlbum(guid) {

    //     console.log("updateAlbum");

    //     if (action === UpdateAction.Title) {
    //         console.log("UpdateAction.Title");
    //         updateTitle(guid);
    //     } else if (action === UpdateAction.Friends) {
    //         console.log("UpdateAction.Friends");

    //         if (friendsToDelete.length > 0 && friendsToAdd.length > 0) {
                
    //             usingTransaction = true;
    //             confirmFollowings(guid);
                
    //         } else if (friendsToDelete.length > 0 ) {
            
    //             updateDeleteFriendsFromPrivateAlbum(guid);
            
    //         } else if (friendsToAdd.length > 0) {
            
    //             confirmFollowings(guid);
            
    //         } else {
    //             console.log("UpdateAction.nothing to change");
    //             finalAppResponse( createAlbumResponse( albumId));                    
    //         }
    //     } else {
    //         finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
    //     }
    // }








    /**
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * 
     * 
     *                                  UPDATE  ALBUM
     *              Add new media content
     * 
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * 
     */




    /**
     * 
     *  Used per user, so that each photo or video will have a unique url. 
     *  2 users can have the same URL, but no 2 albums of the same user can have the same URL.
     *  This will prevent that.
     *
     *  This will never happen
     * AlbumId: 1, mediaURL 39fn0sn3
     * AlbumId: 2, mediaURL 39fn0sn3
     * 
     *  
     * */
    
    /**
     * 
            After user creates album, whenever user uploads new content, 
            1) get if album is public or private
            2) If public, get all followers. If private, get selected users
            3) INSERT INTO timeline SET guid = ?, fguid = ?, album_id = ? ON DUPLICATE KEY UPDATE date=VALUES(date)';           

     */
    function uniqueRandomMediaUrl(guid) {

        console.log("start uniqueRandomMediaUrl");

        var newMediaUrl = generateRandomURL();

        console.log("guid: " + guid + ", newMediaUrl: " +  newMediaUrl);

        connection.query({
            sql: 'INSERT INTO `media_unique_url` SET guid = ?, url = ?',
            values: [ guid, newMediaUrl ]
        }, function (err, results) {
            if (err) {
                printError(err)
                if (err.code == "ER_DUP_ENTRY" && maxDuplicateRetires > 0 ) {
                    maxDuplicateRetires -= 1;
                    console.log("Media url already exists. That's why I'm here to catch it!");
                    uniqueRandomMediaUrl(guid);
                 } else {
                    rollbackAppError(uploadErrorMessage());
                }      
            } else {
                insertMediaIntoS3(guid, newMediaUrl);
            }
        });
    }



        // 1) We upload data from phone to temp s3 file location
        // 2) We Get it here, check it for ValidityState
        // 3) Then move it to permanant location




    function insertNewCoverAlbum(guid, mediaUrl) {

        printTimeForEvent("insertNewCoverAlbum");


        // var thumbnailData = [kThumbnail]
        let thumbnailData = requestBody[kThumbnail];
        printTimeForEvent("insertNewCoverAlbum: thumbnailData length: " + thumbnailData.length);

        var thumbnailImage = new Buffer(thumbnailData, 'base64');
  
        let coverlData = requestBody[kAlbumCover];
        printTimeForEvent("insertNewCoverAlbum: coverlData length: " + coverlData.length);

        var coverImage = new Buffer(coverlData, 'base64');


        if (thumbnailImage === undefined || thumbnailImage === null || coverImage === undefined || coverImage === null) {
            rollbackAppError(uploadErrorMessage());
            return;
        }

        var mediaSize = bytesToMb(thumbnailImage.length);
        
        console.log("insertNewCoverAlbum imageSize: " +  mediaSize  + "MB");

        if ( mediaContentType == MediaType.Photo && !isImageBelowSizeThreshold(mediaSize) ) {
            console.log("Error: Image is too large. Size:" + mediaSize + "Mb");
            rollbackAppError("Photo seems to be too large to upload");
            return;
        } else {
            console.log("insertNewCoverAlbum: will try to upload" );
        }


        s3.putObject({
            Bucket          : ALBUM_BUCKET,
            Key             : albumCoverThumbnailKey(guid, mediaUrl),
            Body            : thumbnailImage,
            ContentEncoding : 'base64',
            ContentType     : 'image/jpeg'
        }, function(err, data) {
            
            if (err) {
                printError(err);
                rollbackAppError(uploadErrorMessage());
            } else {

                s3.putObject({
                    Bucket          : ALBUM_BUCKET,
                    Key             : albumCoverKey(guid, mediaUrl),
                    Body            : coverImage,
                    ContentEncoding : 'base64',
                    ContentType     : 'image/jpeg'
                }, function(err, data) {
                    
                    if (err) {
                        printError(err);
                        rollbackAppError(uploadErrorMessage());
                    } else {
                        console.log("insertNewCoverAlbum: Successfully Put users photo");
                        console.log("insertNewCoverAlbum: data: " + JSON.stringify(data, null, 2));   
                        

                        // Deletes the temporary files after we commit.
                        var paramsDeleteTmp = {
                            Bucket: PRIVATE_TEMP_BUCKET,
                            Delete: { 
                                Objects: [
                                    { Key: tmpS3Key }
                                ],
                                Quiet: true
                            }
                        };

                        insertDataIntoMediaContentTable(guid, mediaUrl, paramsDeleteTmp);
                    }
                });
            }
        });







        // s3.getObject({
        //     Bucket: PRIVATE_TEMP_BUCKET, 
        //     Key: tmpS3CoverKey
        // }, function(err, data) {


        //     printTimeForEvent("insertNewCoverAlbum done");

        //     if (err) {
        //         printError(err);

        //         finalAppResponse( activeResponse( ActiveValues.Active, "Cannot not upload media"));

        //     } else {
        //         console.log(data);           // successful response
          
        //         var dataBody = data.Body;  // already base64  encoded

        //         var mediaSize = bytesToMb(dataBody.length);
                
        //         console.log("insertNewCoverAlbum imageSize: " +  mediaSize );

        //         if ( mediaContentType == MediaType.Photo && !isImageBelowSizeThreshold(mediaSize) ) {
        //             console.log("Error: Image is too large. Size:" + mediaSize + "Mb");
        //             rollbackAppError("Photo seems to be too large to upload");
        //             return;
        //         } else {
        //             console.log("insertNewCoverAlbum: will try to upload" );
        //         }


        //         var paramsUpload = {
        //             Bucket  : ALBUM_BUCKET,
        //             Key     : albumCoverKey(guid, mediaUrl),
        //             Body    : dataBody,
        //             ContentEncoding : 'base64',
        //             ContentType     : 'image/jpeg'
        //         }; 

        //         s3.putObject(paramsUpload, function(err, data) {
                    
        //             if (err) {
        //                 printError(err);
        //                 rollbackAppError(uploadErrorMessage());
        //             } else {
        //                 console.log("insertNewCoverAlbum: Successfully Put users photo");
        //                 console.log("insertNewCoverAlbum: data: " + JSON.stringify(data, null, 2));   
                        
        //                 insertDataIntoMediaContentTable(guid, mediaUrl);



        //                 // Deletes the temporary files.
        //                 var paramsDeleteTmp = {
        //                     Bucket: PRIVATE_TEMP_BUCKET,
        //                     Delete: { 
        //                         Objects: [
        //                             // { Key: tmpS3CoverKey },
        //                             { Key: tmpS3Key }
        //                         ],
        //                         Quiet: true
        //                     }
        //                 };
                        
        //                 s3.deleteObjects(paramsDeleteTmp, function(err, data) {
        //                     if (err) {
        //                         printError(err);
        //                     } else {
        //                         console.log(data);           // successful response
        //                     }
        //                 });
        //             }
        //         });
        //     }
        // });
    }

    // yes 

    function insertMediaIntoS3(guid, mediaUrl) {

        printTimeForEvent("insertMediaIntoS3 getObject");

        // Get data from temp s3 bucket

        s3.getObject({
            Bucket: PRIVATE_TEMP_BUCKET, 
            Key: tmpS3Key 
        }, function(err, data) {
                   
             printTimeForEvent("insertMediaIntoS3 getObject complete");

            if (err) {
                printError(err);
                // finalAppResponse(responseCode, createAlbumResponse(true, albumId));

                finalAppResponse( activeResponse( ActiveValues.Active, APP_NAME + " cannot upload media at this time. Try again soon."));
            } else {
                printTimeForEvent("insertMediaIntoS3 getObject okay");
                // console.log(data);           // successful response

                // Validate media content

                // console.log("mediaUrl: " + mediaUrl);
                // if ( !validator.isBase64(media) ) { 
                //     console.log("!validator.isBase64(media)");
                //     // rollbackAppError("Media content corrupted. Try resending the " + mediaContentType + ".");
                //     // return;
                // } else {

                //     console.log("validator.isBase64(media) - true");
                // }

                var dataBody = data.Body;  // already base64  encoded


                gm(dataBody).format(function(err, value){
                // note : value may be undefined
                    console.log("1 What is this value:" + value );

                    var imageBuffer = new Buffer(dataBody, 'base64'); // Buffer.from(originalImage, 'base64');  


                    gm(imageBuffer).format(function(err, value){
                    // note : value may be undefined
                        console.log("2 What is this value:" + value );


                        var mediaSize = bytesToMb(dataBody.length);
                        
                        console.log("insertMediaIntoS3: imageSize: " +  mediaSize );

                        if ( mediaContentType == MediaType.Photo && !isImageBelowSizeThreshold(mediaSize) ) {
                            console.log("insertMediaIntoS3 Error: Image is too large. Size:" + mediaSize + "Mb");
                            rollbackAppError("Photo seems to be too large to upload");
                            return;
                        }

                        if ( mediaContentType == MediaType.Video && !isVideoBelowSizeThreshold(mediaSize) ) {
                            console.log("Error: Video is too large. Size:" + mediaSize + "Mb");
                            rollbackAppError("Video seems to be too large to upload");
                            return;
                        } else {
                            printTimeForEvent("insertMediaIntoS3: will try to upload");
                        }

                        s3.putObject({ 
                            Bucket          : ALBUM_BUCKET,
                            Key             : albumMediaKey(guid, mediaUrl, mediaContentType),
                            Body            : dataBody,
                            ContentEncoding : 'base64',
                            ContentType     : contentType(mediaContentType)
                        }, function(err, data) {
                            printTimeForEvent("insertMediaIntoS3: putObject complete");

                            if (err) {
                                printError(err);
                                rollbackAppError(uploadErrorMessage());
                            } else {
                                console.log("insertMediaIntoS3: Successfully Put users photo");
                                console.log("insertMediaIntoS3 data: " + JSON.stringify(data, null, 2));   

                                insertNewCoverAlbum(guid, mediaUrl);
                            }
                        });
                    });
                });
            }
        });
    }






    function printTimeForEvent(event) {
        console.log("Event: " + event + ", Time left: " + context.getRemainingTimeInMillis());
    }



    function millisToMinutesAndSeconds(millis) {
    var minutes = Math.floor(millis / 60000);
    var seconds = ((millis % 60000) / 1000).toFixed(0);
    return minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
    }

    function toSeconds(milliseconds) {
        return  Math.round(milliseconds / 1000.0);
    }

    function inHours(seconds) {

        let minutes = seconds / 60
        let hours = minutes / 60
        return hours
    }
        

    /**
     * This function inserts media data into the database for each album 
     * the user uploads to. 
     * 
     * @param {*} guid 
     * @param {*} mediaUrl 
     * @param {*} tmpDeleteParam 
     */

    function insertDataIntoMediaContentTable(guid, mediaUrl, tmpDeleteParam ) {

        console.log("insertDataIntoMediaContentTable guid: " + guid);
        console.log("insertDataIntoMediaContentTable mediaUrl: " + mediaUrl);


        // Sign the url and store it in server
        // 24 hours + 2 minute
        // var params = {  Bucket  : ALBUM_BUCKET, 
        //                 Key     : albumMediaKey(guid, mediaUrl, mediaContentType), 
        //                 Expires : S3_EXPIRE_LIMIT };
        // var signedUrl = s3.getSignedUrl('getObject', params);

        // console.log('The URL expires in ' + S3_EXPIRE_LIMIT + " seconds");

        // var date = new Date();  // Return string formatted date
        // console.log('This date is: ' + date);

        // var time = date.getTime(); // Return milliseconds
        // console.log('This date in time: ' + time);

        // var nowDate = Date.now(); // Return milliseconds
        // console.log('This current date in millisconds: ' + nowDate);

        // var seconds = toSeconds(nowDate);
        // console.log('This Seconds is: ' + seconds);

        // var expirationDateInSeconds = seconds + S3_EXPIRE_LIMIT;
        // console.log('Seconds to add to new expiration: ' + expirationDateInSeconds);


        // let newExpireMilliseconds = expirationDateInSeconds * 1000;
        // console.log('New Epiration date in milliseconds: ' + newExpireMilliseconds);

        // var newDate = new Date(newExpireMilliseconds);
        // console.log('New Epiration date: ' + newDate);


        // var mediaRows = [];
        
        // for (var index in albumList) {
        //     let albumDict   = albumList[index];
        //     let albumId     = albumDict[kAlbumId];
        //     // let isNew       = albumDict[kIsNew];

        //     mediaRows.push([ guid, albumId, mediaUrl, mediaContentType, timelimit ]);  
        // }



        var mediaRows = [];
        
        for (var index in albumIds) {
            let albumId = albumIds[index];
            mediaRows.push([ guid, albumId, mediaUrl, mediaContentType, timelimit ]);  
        }

        connection.query({
            sql: 'INSERT INTO `album_media` (guid, album_id, media_url, type, timelimit ) VALUES ?',
            values: [ mediaRows ]
        }, function (err, results) {
            if (err) {

                printError(err);
                rollbackAppError(uploadErrorMessage());

            } else {

                connection.query({
                    sql: 'SELECT timestamp, UNIX_TIMESTAMP(`timestamp`) AS unix_timestamp FROM album_media WHERE guid = ? AND media_url = ? ORDER BY timestamp DESC LIMIT 1 ',
                    values: [ guid, mediaUrl ] 
                }, function (err, results) {
                    if (err) {
                        printError(err);
                        rollbackAppError(uploadErrorMessage());
                    } else {
                        if (results && results.length > 0) {
                            let ts = results[0].timestamp;
                            let response_ts = results[0].unix_timestamp;

                            updateMyAlbumTable(guid, albumIds, mediaUrl, ts, response_ts, mediaContentType, tmpDeleteParam);
                        } else {
                            rollbackAppError(uploadErrorMessage());
                        }               
                    }
                });
            }
        });
    }




    
    

    /**
    * 
        After user creates album, whenever user uploads new content, 
        1) get if album is public or private
        2) If public, get all followers. If private, get selected users
        3) INSERT INTO timeline SET guid = ?, fguid = ?, album_id = ? ON DUPLICATE KEY UPDATE date=VALUES(date)';



        SELECT ua.`guid`, ua.explicit, ua.first_url, UNIX_TIMESTAMP(`first_timestamp`) AS first_timestamp, ua.`id` AS album_id, ua.`views`, ua.`likes`, ua.`dislikes`, UNIX_TIMESTAMP(`create_date`) AS create_date, ua.expire, ua.expire_date, alvm.last_viewed_media_url, UNIX_TIMESTAMP(last_viewed_timestamp) AS last_viewed_timestamp, UNIX_TIMESTAMP(`newest_media_timestamp`) AS newest_media_timestamp , ua.`title`, ua.`is_private` AS album_is_private, ua.`cover_album_url`, ua.`count`, `profile`.username,  `profile`.allow_view_followings, profile.allow_view_followers,  `profile`.fullname, `profile`.image_url, `profile`.verified, `profile`.is_private AS profile_is_private 
        FROM `user_album` AS ua 
            INNER JOIN `friends` 
            ON friends.guid1 = ? AND friends.guid2 = ua.guid AND friends.`status` = ? 
                LEFT JOIN album_permissions AS ap 
                ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
                    INNER JOIN `profile` 
                    ON ua.guid = profile.guid
                        LEFT JOIN album_last_viewed_media AS alvm 
                        ON alvm.guid = friends.guid1 AND alvm.fguid = ua.guid AND alvm.album_id = ua.id 
        WHERE (ua.`is_private` = ? OR ap.guid IS NOT NULL) AND (ua.expire_date IS NULL OR ua.expire_date > NOW())                                    ORDER BY ((alvm.last_viewed_timestamp IS NOT NULL AND newest_media_timestamp > alvm.last_viewed_timestamp) OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?"; //ORDER BY ua.newest_media_timestamp AND (ua.newest_media_timestamp > alvm.last_viewed_timestamp OR alvm.last_viewed_timestamp IS NULL) DESC, newest_media_timestamp DESC LIMIT ?";


     */

    function updateTimelineForAllUsers(guid, albumIds, lastMediaDate, mediaKey, signedUrl, response_timestamp, paramsDeleteTmp) {
        // var sqlQurey = "INSERT INTO cron_timeline (guid, album_id) VALUES ?";  
        // var parameters = [guid, albumId ];
        
        var mediaRows = [];
        for (var index in albumIds) {
            let albumId = albumIds[index];            
            mediaRows.push([ guid, albumId ]);  
        }
    
        connection.query({
            sql: "INSERT INTO cron_timeline (guid, album_id) VALUES ?",
            values: [ mediaRows ]
        }, function (err, results) {
            if (err) {
                printError(err);
                rollbackAppError(uploadErrorMessage());

            } else {

                connection.query({  
                    sql: "SELECT guid_mentioned AS guid FROM user_album AS ua INNER JOIN mentions AS m ON ua.guid = m.mentioned_by AND  ua.`id` = m.mentioned_in AND mention_type = ? WHERE ua.guid = ? AND ua.id IN (?) AND ua.count = 1",
                    values: [ MentionType.AlbumTitle, guid, albumIds  ]
                }, function (err, results) {
                    if (err) {
                        printError(err);
                        rollbackAppError(uploadErrorMessage());
                    } else {

                        var mentionedGuids = [];
                        results.forEach((result) => {
                            mentionedGuids.push(result.guid);
                        });

                        if (mentionedGuids.length > 0) {
                            
                            sendMentionNotifications(guid, albumId, mentionedGuids, function (err, results) {
                                    
                                if (err && err.code !== "ER_DUP_ENTRY") {                        
                                    
                                    rollbackErrorResponseWithMessage(err, uploadErrorMessage());
                                    
                                } else {
                                    
                                    connection.commit(function(err) {
                                        if (err) {
                                            rollbackErrorResponseWithMessage(err, uploadErrorMessage());                                            

                                        } else  {
                                            console.log('successful commit!: obj'); 

                                            s3.deleteObjects(paramsDeleteTmp, function(err, data) {
                                                if (err) {
                                                    printError(err);
                                                } else {
                                                    console.log(data);           // successful response
                                                }
                                            });

                                            finalAppResponse( uploadMediaResponse( mediaKey, signedUrl, response_timestamp ) );
                                            // finalAppResponse( uploadMediaResponse( mediaKeyWithExtension( mediaKey, mediaContentType), signedUrl, reponse_timestamp.toString() ) );
                                        }
                                    });
                                }
                            });
                        } else {

                            connection.commit(function(err) {
                                if (err) {
                                    rollbackErrorResponseWithMessage(err, uploadErrorMessage());
                                    
                                } else  {
                                    console.log('successful commit!: obj'); 

                                    s3.deleteObjects(paramsDeleteTmp, function(err, data) {
                                        if (err) {
                                            printError(err);
                                        } else {
                                            console.log(data);           // successful response
                                        }
                                    });

                                    finalAppResponse( uploadMediaResponse( mediaKey, signedUrl, response_timestamp ) );
                                    // finalAppResponse( uploadMediaResponse( mediaKeyWithExtension( mediaKey, mediaContentType), signedUrl, reponse_timestamp.toString() ) );
                                }
                            });
                        }
                    }
                });
            }
        });
        
        
        
/*
        In background file

        1) 

        SELECT primarykey_id, guid, album_id, date
        FROM cron_timeline

        

        2) 

        SELECT ua.is_private, friends.guid1
        FROM `user_album` AS ua 
        INNER JOIN `friends` 
        ON ua.guid = friends.guid2 AND friends.`status` = ? 
            LEFT JOIN album_permissions AS ap 
            ON (ap.guid = friends.guid1 AND ap.fguid = friends.guid2 AND ap.album_id = ua.id) 
               
        WHERE ua.guid = ? AND album_id = ?

        3) 


        if ua.is_private {

            upload to people with album permission
        } else {

            upload to all followers

            INSERT INTO album_timeline (guid, fguid, album_id, date) VALUES ?
            
        }

        */

    
        

        // guid, fguid, album_id, date

        // timeline

        // sql = 'INSERT INTO user_album_likes SET `guid` = ?, `fguid` = ?, `album_id` = ?, `liked` = ? ON DUPLICATE KEY UPDATE liked=VALUES(liked)';
        
        // insert cron_timeline

        
        // 'SELECT timestamp, UNIX_TIMESTAMP(`timestamp`) AS unix_timestamp FROM album_media WHERE guid = ? AND media_url = ? ORDER BY timestamp DESC LIMIT 1 ',
        
        //     sql: 'INSERT INTO `album_media` (guid, album_id, media_url, type, timelimit ) VALUES ?',
        //     values: [ mediaRows ]
            
            


    }


    
    function getTitleAndCountOfAlbums(guid, albumIds, callback) {
    
    //  function getTitleAndCountOfAlbums(guid, albumIds) {

        connection.query({  
            sql: "SELECT id, title, count FROM user_album  AS ua INNER JOIN mentions AS m ON ua.guid = m.mentioned_by AND  ua.`id` = m.mentioned_in AND mention_type = ? WHERE ua.guid = ? AND ua.id IN (?) AND ua.count = 1",
            values: [ MentionType.AlbumTitle, guid, albumIds  ]
        }, function (err, results) {
            if (err) {
                printError(err);
                rollbackAppError(uploadErrorMessage());
            } else {

                callback();

            /**
             * 
             * Insert mentions here
             * 
             * Then send notifications
             * 
             * then continue as usual
             * 
             */

                
            }
        });

     }

    
    /**
     * 
     * Update all user albums that have new content
     * @param {*} guid 
     * @param {*} mediaKey 
     * @param {*} timestamp 
     * @param {*} response_timestamp 
     * @param {*} mediaContentType 
     * @param {*} paramsDeleteTmp 
     
     */
    function updateMyAlbumTable(guid, albumIds, mediaKey, timestamp, response_timestamp, mediaContentType, paramsDeleteTmp) {

        // Update cover album
        // // 24 hours
        // var params = {  Bucket  : ALBUM_BUCKET, 
        //                 Key     : albumCoverKey(guid, mediaUrl), 
        //                 Expires : S3_EXPIRE_LIMIT 
        //              };
        // var signedUrl = s3.getSignedUrl('getObject', params);
        
        // console.log('The URL expires in ' + S3_EXPIRE_LIMIT + " seconds");
        // console.log('The URL expires in ' + inHours(S3_EXPIRE_LIMIT) + " hours");


        // console.log('signedUrl', signedUrl);
        // console.log('mediaUrl', mediaUrl);
        // console.log('guid', guid);
        // console.log('albumIds', albumIds);


    /**
     * UPDATE `user_album` 
     * SET `newest_media_timestamp` = ?, `cover_album_url` = ?, count = count + 1 
     *     field3 = IF(field3 < '2011-00-00 00:00:00' OR field3 IS NULL, NOW(), field3)

    first_url =  IF( first_url IS NOT NULL, ? , ?)

    * WHERE `guid` = ? AND create_date > NOW() - INTERVAL 1 DAY AND `id` IN (?)",
    */


        
        // var albumIds = [];

        // for (var index in albumList) {
        //     let albumDict   = albumList[index];
        //     let albumId     = albumDict[kAlbumId];
        //     // let isNew       = albumDict[kIsNew];
        //     albumIds.push(albumId);
        //     // mediaRows.push([ guid, albumId, mediaUrl, mediaContentType, timelimit ]);  
        // }
        
        connection.query({  
            sql: "UPDATE `user_album` SET `newest_media_timestamp` = ?, `cover_album_url` = ?, first_timestamp = IF(first_timestamp IS NULL, ? , first_timestamp), first_url = IF( first_url IS NULL, ? , first_url), count = count + 1 WHERE `guid` = ? AND create_date > NOW() - INTERVAL 1 DAY AND `id` IN (?)",
            values: [ timestamp, mediaKey, timestamp, mediaKeyWithExtension(mediaKey, mediaContentType), guid, albumIds ]
        }, function (err, results) {
            if (err) {
                printError(err);
                rollbackAppError(uploadErrorMessage());
            } else {


                var params = {  Bucket  : ALBUM_BUCKET, 
                    Key     : albumMediaKey(guid, mediaKey, mediaContentType), 
                    Expires : S3_EXPIRE_LIMIT };
                var signedUrl = s3.getSignedUrl('getObject', params);

                updateTimelineForAllUsers(guid, albumIds, timestamp, mediaKey, signedUrl, response_timestamp.toString(), paramsDeleteTmp);

                // // Commit both queries
                // connection.commit(function(err) {
                //     if (err) {
                //         // Failed to commit queries. Rollback on failure
                //         printError(err);
                //         rollbackAppError(uploadErrorMessage());

                //     } else  {
                //         console.log('successful commit!: obj'); 

                //         s3.deleteObjects(paramsDeleteTmp, function(err, data) {
                //             if (err) {
                //                 printError(err);
                //             } else {
                //                 console.log(data);           // successful response
                //             }
                //         });

                //         console.log('timestamp: ' + timestamp); 
                //         console.log('response_timestamp: ' + response_timestamp); 


                        
                //         var params = {  Bucket  : ALBUM_BUCKET, 
                //                         Key     : albumMediaKey(guid, mediaKey, mediaContentType), 
                //                         Expires : S3_EXPIRE_LIMIT };
                //         var signedUrl = s3.getSignedUrl('getObject', params);
 
                //         finalAppResponse( uploadMediaResponse( mediaKey, signedUrl, response_timestamp.toString() ) );
                //         // finalAppResponse( uploadMediaResponse( mediaKeyWithExtension( mediaKey, mediaContentType), signedUrl, reponse_timestamp.toString() ) );
                //     }
                // });
            }
        });
    }



    /**
     * Returns the content from opening a single album
     */

  

    /**
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     *  
     *                      Album Utility functions
     *                           - getAlbumOpinion
     *                           - updateAlbumLikes
     *                           - flagMediaInAlbum
     *                                   Flag album 
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     */



    var AlbumLike = {
        none           : 0,
        liked          : 1,
        disliked       : 2
    };

    function getAlbumOpinion(guid, fguid, albumId, newOpinion) {
        console.log("getAlbumOpinion");

        // var sqlStmt;
        // if (newOpinion === AlbumLike.liked ) {
            
        //     sqlStmt = "UPDATE `user_album` AS ua LEFT JOIN user_album_likes AS ual ON ual.guid = ? AND ual.fguid = ? AND ual.album_id = ? AND ual.fguid = ua.guid AND ual.album_id = ua.id SET `likes` = if(liked is NULL OR liked = 2, `likes` + 1, `likes` ), `dislikes` = if(liked = 2, `dislikes` - 1, `dislikes` )";
            
        // } else if (newOpinion === AlbumLike.disliked ) {
            
        //     sqlStmt = "UPDATE `user_album` AS ua LEFT JOIN user_album_likes AS ual ON ual.guid = ? AND ual.fguid = ? AND ual.album_id = ? AND ual.fguid = ua.guid AND ual.album_id = ua.id SET `dislikes` = if(liked is NULL OR liked = 1, `dislikes` + 1, `dislikes` ), `likes` = if(liked = 1, `likes` - 1, `likes` )";
        
        // } else if (newOpinion === AlbumLike.none ) {
            
        //     sqlStmt = "UPDATE `user_album` AS ua LEFT JOIN user_album_likes AS ual ON ual.guid = ? AND ual.fguid = ? AND ual.album_id = ? AND ual.fguid = ua.guid AND ual.album_id = ua.id SET `dislikes` = if(liked = 2, `dislikes` - 1, `dislikes` ), `likes` = if(liked = 1, `likes` - 1, `likes` )";
        // } else {
        //     finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
        //     return;
        // }

        // updateAlbumLikes(guid, fguid, albumId, newOpinion, sqlStmt);
        // return;


        // Get any previous opinion I have of this album
        connection.query({
            sql: 'SELECT `liked` FROM `user_album_likes` WHERE guid = ? AND fguid = ? AND album_id = ?',
            values: [ guid, fguid, albumId ], 
        },
        function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
            } else if (results) {
                
                
                // If I have an opinion
                if (results.length > 0) {
                    console.log("getAlbumOpinion results.length > 0");

                    let previousOpinion = results[0].liked;
                    
                    console.log("getAlbumOpinion previousOpinion: " + previousOpinion);
                    

                    // If we liked before
                    if ( previousOpinion === AlbumLike.liked ) {
                        
                        // If we before liked, but now don't
                        if (newOpinion === AlbumLike.none ){

                            var sqlStmt = "UPDATE `user_album` SET `likes` = `likes` - 1 WHERE `guid` = ? AND id = ?";
                            updateAlbumLikes(guid, fguid, albumId, previousOpinion, newOpinion, sqlStmt);

                        // If we before liked, but now dislike
                        } else if (newOpinion === AlbumLike.disliked ) {

                            var sqlStmt = "UPDATE `user_album` SET `likes` = `likes` - 1, `dislikes` = `dislikes` + 1 WHERE `guid` = ? AND id = ?";
                            updateAlbumLikes(guid, fguid, albumId, previousOpinion, newOpinion, sqlStmt);

                        // Do nothing
                        } else if (newOpinion === AlbumLike.liked ) { 
                            finalAppResponse( updateViewResponse(true));
                        } else {
                            finalAppResponse( updateViewResponse(true));
                        }

                        // If we before disliked
                    } else if ( previousOpinion === AlbumLike.disliked ) {

                        // If we before disliked, but now don't
                        if (newOpinion === AlbumLike.none ){

                            var sqlStmt = "UPDATE `user_album` SET `dislikes` = `dislikes` - 1 WHERE `guid` = ? AND id = ?";
                            updateAlbumLikes(guid, fguid, albumId, previousOpinion, newOpinion, sqlStmt);

                            // If we before disliked, but now like
                        } else if (newOpinion === AlbumLike.liked ) {
                            
                            var sqlStmt = "UPDATE `user_album` SET `likes` = `likes` + 1, `dislikes` = `dislikes` - 1 WHERE `guid` = ? AND id = ?";
                            updateAlbumLikes(guid, fguid, albumId, previousOpinion, newOpinion, sqlStmt);

                        } else if (newOpinion === AlbumLike.disliked ) {
                            finalAppResponse( updateViewResponse(true));
                        // Do nothing
                        } else {
                            finalAppResponse( updateViewResponse(true));
                        }

                    } else {
                        finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
                    }
                } else {
                    console.log("getAlbumOpinion no results");

                    // Previous opinion doesn't exist
                    // We like                        
                    if (newOpinion === AlbumLike.liked ) {
                        var sqlStmt = "UPDATE `user_album` SET `likes` = `likes` + 1 WHERE `guid` = ? AND id = ?";
                        updateAlbumLikes(guid, fguid, albumId, null, newOpinion, sqlStmt);

                    // We dislike
                    } else if (newOpinion === AlbumLike.disliked ) {
                        var sqlStmt = "UPDATE `user_album` SET `dislikes` = `dislikes` + 1 WHERE `guid` = ? AND id = ?";
                        updateAlbumLikes(guid, fguid, albumId, null, newOpinion, sqlStmt);

                    } else {
                        //Do nothing
                        finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
                    }
                }
            } else {
                printError(error);
                finalAppResponse( activeResponse( ActiveValues.Active, ErrorMessageGeneric));
            }
        });
    }



    /**
     * 
     * 
     * @param {*} guid 
     * @param {*} fguid 
     * @param {*} albumId 
     * @param {AlbumLike} newOpinion 
     * @param {*} sqlStmt 
     * 
     * 
     *  1) Update user_album.likes/dislikes. sqlStmt from getAlbumOpinion()
     *  2) Update user_album_likes
     *  3) Update user_metrics.total_likes
     * 
     */
    
    function updateAlbumLikes(guid, fguid, albumId, previousOpinion, newOpinion, sqlStmt) {
        console.log("updateAlbumLikes");
        connection.beginTransaction(function(err) {
            if (err) { 
                printError(error);
                rollbackAppError(ErrorMessageGeneric);
            } else { 
                connection.query({
                    sql   : sqlStmt,
                    values: [ fguid, albumId ]
                }, function (err, results) {
                    if (err) {
                        printError(err);
                        finalAppResponse( updateViewResponse(false));
                    } else {

                        console.log("updateAlbumLikes next");

                        var sql;
                        var parameters;

                        // User save their like/dislike of an album
                        if ( newOpinion === AlbumLike.liked || newOpinion === AlbumLike.disliked ) {
                            sql = 'INSERT INTO user_album_likes SET `guid` = ?, `fguid` = ?, `album_id` = ?, `liked` = ? ON DUPLICATE KEY UPDATE liked=VALUES(liked)';
                            parameters = [guid, fguid, albumId, newOpinion ];
                        } else {
                            sql = 'DELETE FROM user_album_likes WHERE `guid` = ? AND `fguid` = ? AND `album_id` = ?';
                            parameters = [guid, fguid, albumId ];
                        }

                        connection.query({
                            sql   : sql,
                            values: parameters, 
                        }, function (err, results) {
                            if (err) {
                                printError(err);
                                rollbackAppError(ErrorMessageGeneric);
                            } else {
                                // Commit queries
                                console.log("updateAlbumLikes commit");
                                connection.commit(function(err) {
                                    var didUpdate = false;
                                    if (err) {
                                        printError(err);
                                        rollbackAppError(ErrorMessageGeneric);
                                    } else  {
                                        console.log('successful commit!');
                                        didUpdate = true;
                                    }
                                    // update user_metrics likes or dislikes


                                    var sql;
                                    
                                    if (previousOpinion === AlbumLike.none) {
                                        if (newOpinion === AlbumLike.liked) {
                                            sql = 'INSERT INTO `user_metrics` (guid, total_likes) VALUES (?, 1) ON DUPLICATE KEY UPDATE total_likes=total_likes + 1';
                                        // newOpinion = disliked
                                        } else {
                                            sql = 'INSERT INTO `user_metrics` (guid, total_dislikes) VALUES (?, 1) ON DUPLICATE KEY UPDATE total_dislikes=total_dislikes + 1';
                                        }

                                    } else if (previousOpinion === AlbumLike.liked) {
                                    
                                        if (newOpinion === AlbumLike.none) {
                                        
                                            sql = 'INSERT INTO `user_metrics` (guid, total_likes) VALUES (?, -1) ON DUPLICATE KEY UPDATE total_likes=total_likes - 1';

                                        // inc disliked, dec liked
                                        } else {
                                            sql = 'INSERT INTO `user_metrics` (guid, total_likes, total_dislikes) VALUES (?, -1, 1) ON DUPLICATE KEY UPDATE total_likes=total_likes - 1, total_dislikes=total_dislikes + 1';
                                        }
                                    // previousOpinion === disliked
                                    } else {
                                        if (newOpinion === AlbumLike.none) {
                                            sql = 'INSERT INTO `user_metrics` (guid, total_dislikes) VALUES (?, -1) ON DUPLICATE KEY UPDATE total_dislikes=total_dislikes - 1';
                                        // inc liked, dec disliked
                                        } else {
                                            sql = 'INSERT INTO `user_metrics` (guid, total_likes, total_dislikes) VALUES (?, 1, -1) ON DUPLICATE KEY UPDATE total_likes=total_likes + 1, total_dislikes=total_dislikes - 1';
                                        }
                                    }
    
                                    connection.query({
                                        sql: sql,
                                        values: [ fguid ]
                                    }, function (err, results) {
                                        if (err) {
                                            printError(err);
                                        } else {
                                            console.log('successful insert user_metrics');
                                        }

                                        finalAppResponse( updateViewResponse(didUpdate));
                                    });
                                });
                            }
                        });
                    }
                });
            }
        });
    }



/**
 * 
 * 
 * album_view_history - Records every time a user opens an album
 * guid, fguid, albumId, dateViewed
 * 
 * Idx: (fguid, albumId, dateViewed) -> Creater gets total number of views for album, or breaks down views by albumId
//  *      - This is equivalent to user_album.views
//  * Idx: (fguid, dateViewed, albumId) -> Creater gets total number of views for album
 * 
 *  1) album_view_history
 *  2) user_album.views
 *  3) user_metrics.total_album_views
 * 
 * 
 * 
 * 
 * // Update this for every last_album_viewed inserted
 * media_view_history - Records all media content watched, 
 * guid, fguid, albumId, mediaUrl dateViewed
 * 
 * 
 * 
 *  user_album - Stores the number of views and likes of this album
 *  views, likes, dislikes
 * 
 *  1) user_album_likes
 *  1) user_album.likes
 *  2) user_metrics.total_likes
 * 
 * 
 * 
 *  user_album_likes         -  Stores albums the user likes 
 *  guid, fguid, album_id, liked  -> liked or disliked
 * 
 * 
 *  IDX: user_album.likes ==  COUNT(user_album_likes.fguid, user_album_likes.album_id, user_album_likes.liked = liked)
 * 
 * 
 *  //TODO did not do yet
 *  user_media_loves         -  Stores media the user likes 
 *  guid, fguid, album_id, media_url  -> Can only be hearted or not
 * 
 * 
 * 
 * profile -
 * 
 * popularity refers  ->  user_metrics.popularity
 * followers refers  ->  user_metrics.followers_count
 * followings refers ->  user_metrics.followings_count
 * 
 * 
 * 
 * At some point we need to: 
 *                                     
 * SELECT popularity, total_album_views
 * FROM `user_metrics` 
 * WHERE guid = ?
 * 
 * var threshold = 100;
 * 
 * if total_album_views === threshold {
 *   insert into cron_job
 * }
 * IF POPularity = 1000  {
 * insert into cron_job
 * }
 *  total_album_views=total_album_views + 1",

 * 
 * 
 * 
 * 
 *  user_metrics
 *                              popularity (sum of all),  
 *                              followers_count -> , 
 *                              followings_count -> , 
  
 *                              total_profile_views -> , 
 *                              total_album_views   -> (sum of user_album.views) or (sum of COUNT(album_view_history(fguid, albumId))
 *                              total_likes         -> (sum of user_album.likes + sum of user_album.dislikes), 
 *                              total_dislikes         -> (sum of user_album.likes + sum of user_album.dislikes), 
 *                              total_loves         -> (sum of user_media_loves)
 * 
 * 
 * usersearch - 
 * popularity -> refers to  user_metrics.popularity
 * 
 * 
 * 
 * 

    INSERT INTO `user_metrics` (guid, total_album_views) VALUES (?, ?) 
    ON DUPLICATE KEY 
    UPDATE total_album_views=total_album_views + 1",
    
    values: [[ guid, 1 ]]

 */


    
    let INTERVAL_USER_HISTORY_LIMIT = 1;

    /**
     *  Insert what album the user has viewed into their history
     * 
     *  1) Insert info into album view history
     *  2) Increase album view count
     *  3) Increase user's total view count
     * 
     *  Transaction not rally needed
     * 
     */
    function updateAlbumViewCount(guid, fguid, albumId) {
        
        console.log("updateAlbumViewCount");
        
        // Insert users view history.  (Can be unlimited number of times)
        connection.query({
            sql: 'INSERT INTO album_view_history SET `guid` = ?, `fguid` = ?, `album_id` = ?',
            values: [guid, fguid, albumId ]
        }, function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( updateViewResponse(false));
            } else {
                // Get total uesr views in past 24 hours
                connection.query({
                    sql: 'SELECT COUNT(*) AS user_views FROM `album_view_history` WHERE `guid` = ? AND `fguid` = ? AND `album_id` = ? AND date > NOW() - INTERVAL 1 HOUR', 
                    values: [guid, fguid, albumId ],
                    timeout: 200 // 0.2s
                }, function (err, results) {
                    if (err) {
                        printError(err);
                        finalAppResponse( updateViewResponse(false));
                    } else if (results && results.length > 0) {

                        console.log("updateAlbumViewCount count = " + results[0].user_views);
                        if (results[0].user_views > 5) {

                            console.log("updateAlbumViewCount: View count not updated");

                            //TODO: Notify engineers about potential view manipulater
                            finalAppResponse( updateViewResponse(false));

                        }  else {
                            console.log("updateAlbumViewCount: View count will be updated");

                            var didUpdate = false;

                            connection.query({
                                sql: "UPDATE `user_album` SET `views` = `views` + 1 WHERE `guid` = ? AND id = ?",
                                values: [ fguid, albumId ],
                                timeout: 200 // 0.2s
                            }, function (err, results) {
                                if (err) {
                                    printError(err);
                                    didUpdate = false;
                                    // finalAppResponse( updateViewResponse(false));
                                } else {
                                    console.log("updateAlbumViewCount updating user view count");
                                    didUpdate = true;
                                    // finalAppResponse( updateViewResponse(true));
                                }

                                connection.query({
                                    // sql = 'INSERT INTO user_album_likes SET `guid` = ?, `fguid` = ?, `album_id` = ?, `liked` = ? ON DUPLICATE KEY UPDATE liked=VALUES(liked)';
                                    sql: "INSERT INTO `user_metrics` SET guid = ?, total_album_views = ? ON DUPLICATE KEY UPDATE total_album_views=total_album_views + 1",
                                    values: [guid, 1 ], 
                                    timeout: 200 // 0.2s
                                }, function (err, results) {
                                    if (err) {
                                        printError(err);
                                    } else {
                                        console.log("updateAlbumViewCount updating user view count");
                                    }
                                    finalAppResponse( updateViewResponse(didUpdate));
                                }); 
                            });
                            
                        }
                    } else {
                        // Something went wrong
                        console.log("updateAlbumViewCount: Something went wrong");
                        finalAppResponse( updateViewResponse(false));
                    }
                });
            }
        });
    }


    /**
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     *  
     * 
     *                              Album Utility functions
     * 
     * 
     *                                   Flag media/album 
     * 
     * 
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     * ==========================================================================================
     */



    var MediaFlag = {
        Spam        : 0,
        Abuse       : 1,
        Other       : 2    
    };

// Do we want to unflag? 
    // type:  0
    function flagMediaInAlbum(guid, fGuid, albumId, mediaId, type) {
         connection.query({
            sql: "INSERT INTO `flagged_media` SET guid=?, flagger_guid=?, album_id=?, media_id=?, type=?",
            values: [ guid, fguid, albumId, mediaId, type ]
        }, function (err, results) {
            if (err) {
                printError(err);

                if (err.code == "ER_DUP_ENTRY" ) {
                    finalAppResponse( bookmarkResponse(true));
                } else {
                    finalAppResponse( errorResponse( ErrorMessageGeneric));
                }
            } else {
                console.log("updateAlbumViewCount updating user view count");
                finalAppResponse( bookmarkResponse(true));
            }
        }); 
    }



    function bookmarkAlbum(guid, fguid, albumId) {
        console.log("bookmarkAlbum");

        connection.query({
            sql: "INSERT INTO `bookmarked_album` SET guid=?, fguid=?, album_id=? ",
            values: [ guid, fguid, albumId ]
        }, function (err, results) {
            if (err) {
                printError(err);

                if (err.code == "ER_DUP_ENTRY" ) {
                    finalAppResponse( bookmarkResponse(true));
                } else {
                    finalAppResponse( errorResponse( ErrorMessageGeneric));
                }
            } else {
                console.log("updateAlbumViewCount updating user view count");
                finalAppResponse( bookmarkResponse(true));
            }
        }); 
    }



    function unbookmarkAlbum(guid, fguid, albumId) {
        console.log("unbookmarkAlbum");
        connection.query({
            sql: "DELETE FROM `bookmarked_album` WHERE guid=? AND fguid=? AND album_id=? ",
            values: [ guid, fguid, albumId ]
        }, function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( errorResponse( ErrorMessageGeneric));
            } else {
                console.log("updateAlbumViewCount updating user view count");
                finalAppResponse( bookmarkResponse(false));
            }
        }); 
    }












    function intToBool(val) {
        if (!isInt(val) ) return false;
        return val === 0 ? false : true;
    }
         
    function isBoolean(val) {
        return typeof(val) === "boolean";
    }


    function isArrayWithObjects(val) {
                                        // if ( followersAddList === undefined || followersAddList === null || followersAddList.length === 0) {
        return  Object.prototype.toString.call( val ) === '[object Array]' && val.length > 0
    }

    function isArray(val) {
                                        // if ( followersAddList === undefined || followersAddList === null || followersAddList.length === 0) {
        return  Object.prototype.toString.call( val ) === '[object Array]'
    }


    function sanitizeStringArray(list) {

        if ( isArrayWithObjects(list) ) {
            
            var sanitizedList = [];
        
            list.forEach((item) => {
                if (isStringWithLength(item)) {
                    sanitizedList.push(item);
                }
            });

            if (sanitizedList.length > 0) {
                return sanitizedList;
            } else {
                return null;
            }
        }
        
        return null;
    }


    function getConfirmedFollowerGuids(guid, followersAddList, callback) {
    
        console.log("getConfirmedFollowerGuids");

        var queryFriendsSql = 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `guid1` IN (?) AND `status` = ?';

        connection.query({
            sql: queryFriendsSql,
            values: [ guid, followersAddList, Relationship.IsFollowing ], 
        }, 
        function (err, results) {
            callback(err, results);
        });
    }

    function getQualifiedFollowerGuids(guid, followersAddList, callback) {
        
            console.log("getQualifiedFollowerGuids");
    
            var queryFriendsSql = 'SELECT `guid1` as guid FROM `friends` WHERE `guid2` = ? AND `guid1` IN (?) AND `status` = ?';
    
            connection.query({
                sql: queryFriendsSql,
                values: [ guid, followersAddList, Relationship.IsFollowing ], 
            }, 
            function (err, results) {
                callback(err, results);
            });
        }



    function queryLoggedInUser() {
        
        connection.query({
            sql: 'SELECT `guid`, `active` FROM `users` WHERE `id` = ? AND `acctid` = ?', 
            values: [userId, acctId]
        }, function (err, results) {
            if (err) {
                printError(err);
                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
            } else if (results && results.length > 0) {
                console.log('Results:', JSON.stringify(results, null, 2));

                console.log('User exists, returning current info');

                if ( results[0].active != ActiveValues.Active ) {
                    finalAppResponse( activeResponse( results[0].active, activeErrorMessage( results[0].active )));
                    return;
                }
                
                var guid = results[0].guid;

                // list my albums // AWSLambdaOpenAlbum
                if ( pathParams.localeCompare("/albums/private/me" ) == 0 ) {
                    

                    if ( isInt(numberOfAlbums) ) {
                        if (numberOfAlbums < 0 || numberOfAlbums > MAX_NUM_OF_ALBUMS ) {
                            numberOfAlbums = MAX_NUM_OF_ALBUMS;
                        }
                    } else {
                        numberOfAlbums = MAX_NUM_OF_ALBUMS;
                    }

                    if ( action.localeCompare("ListMyAlbum" ) == 0 ) {

                        listMyAlbums( guid );
                    }

                    else if ( action.localeCompare("ListMyOpenAlbum" ) == 0 ) {

                        listMyOpenAlbums( guid );
                    }

                    else if ( action.localeCompare("ListMyBookmarkedAlbum" ) == 0 ) {

                        listMyBookmarkedAlbums( guid );
                    }


                // open my album/ Get media content
                // } else if ( pathParams.localeCompare("/albums/private/me/album" ) == 0 ) {

                    else if ( action.localeCompare("OpenMyAlbum" ) == 0 ) {
                        getMyMediaContent(guid);
                    }     


                    // create new album
                    else if ( action.localeCompare("CreateNewAlbum" ) == 0) {




                        if ( !isStringWithLength(title)) {
                            finalAppResponse( activeResponse( ActiveValues.Active, "Need a title for this album"));
                            return;
                        }
                        

                        console.log("title: " + title  );
                        console.log("Titke length: " +  stringz.length(title)  ); 

                        if ( stringz.length(title) > 100) {
                        // if ( title.length > 100) {
                            finalAppResponse( activeResponse( ActiveValues.Active, "Title needs to be less than 100 characters"));
                            return;
                        }


                        // if ( !validator.isBase64(title) ) { 
                        //     console.log("Title is not base64: " + title);
                            
                        
                        //     title = newTitle;
                        //     // finalAppResponse( activeResponse( ActiveValues.Active, "Title is not base64 encoded"));
                        //     // return;
                        // }


                        // Requestbody parameters
                        var isGroupAlbumParam                = requestBody[kIsGroupAlbum];
                        var isAllSelectedForGroupAlbumParam  = requestBody[kIsAllSelectedForGroupAlbum];
                        
                        // Either empty or array of guids
                        var groupSelectedFollowersParam      = requestBody[kGroupSelectedFollowers];
                        

                        
                        var isGroupAlbum                = false;
                        var isAllSelectedForGroupAlbum  = false;
                        var sanitizedGroupPosters       = null;


                        if ( isBoolean(isGroupAlbumParam) && isGroupAlbumParam) {
                            
                            isGroupAlbum = true;
                            if ( isBoolean(isAllSelectedForGroupAlbumParam) && isAllSelectedForGroupAlbumParam) {
                                isAllSelectedForGroupAlbum = true;

                            } else {

                                sanitizedGroupPosters = sanitizeStringArray(groupSelectedFollowersParam);

                                if (sanitizedGroupPosters === null ) {
                                    isGroupAlbum = false;

                                //   finalAppResponse( activeResponse(ActiveValues.Active, "Select followers to view album" ));
                                }
                            }
                        }


                        var groupPostersDict = {};
                        groupPostersDict[kIsGroupAlbum]               = isGroupAlbum;
                        groupPostersDict[kIsAllSelectedForGroupAlbum] = isAllSelectedForGroupAlbum;
                        groupPostersDict[kGroupSelectedFollowers]     = sanitizedGroupPosters;

                        // TODO: Finish setting up groupPostersDict

                        /**
                         *  1) Add the values to tables
                         *  2) Add all group posters to group_poster table
                         * 
                         * For all other posters
                         *  3) Add new query for user to get all albums he can post to for group
                         *  4) When a user posts to album, we need to check he has permission and then  
                         */


                        if (isPrivate) { 

                            if ( !isInt(daysTillExpire) ) {
                                daysTillExpire = null;
                                // finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                            } else if (daysTillExpire < 2 || daysTillExpire > 7) {
                                daysTillExpire = 7 ; // finalAppResponse( activeResponse(ActiveValues.Active, "Days to" ));
                            }


                            var sanitizedFollowersAddList    = sanitizeStringArray(followersAddList);

                            if (sanitizedFollowersAddList === null ) {
                                finalAppResponse( activeResponse(ActiveValues.Active, "Select followers to view album" ));
                            } else {
                                prepareFollowersForCreatePrivateAlbum(guid, daysTillExpire, sanitizedFollowersAddList, groupPostersDict );
                                // getIncludedFriends(guid, daysTillExpire, sanitizedFollowersAddList);
                            }


                            // if ( isSubmittingToAll ) {
                            //     getFriendsNotIncluded(guid);
                            // } else {
                            //     getIncludedFriends(guid);
                            // }     

                        // Public album
                        } else {

                            if ( !isInt(daysTillExpire) ) {
                                daysTillExpire = null;
                                // finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                            } else if (daysTillExpire < 2 || daysTillExpire > 7) {
                                daysTillExpire = 7 ; // finalAppResponse( activeResponse(ActiveValues.Active, "Days to" ));
                            }
                            
                            createPublicAlbum(guid, daysTillExpire, groupPostersDict);
                        }              
                    }
                    // delete album
                    else if ( action.localeCompare("DeleteAlbum" )  == 0) {
                        
                        console.log("will Delete album");
                        connection.beginTransaction(function(err) {
                            if (err) { 
                                printError(error);
                                rollbackAppError(ErrorMessageGeneric);
                            } else { 
                                selectAllMediaToDeleteFromAlbum(guid, albumId);
                            }
                        });
                    }
                    // update album
                    else if ( action.localeCompare("UpdateTitle" ) == 0) {
                        console.log("UpdateAction.Title");
                        updateTitle(guid);        
                    }  
                    else if ( action.localeCompare("UpdateACL" ) == 0) {
                        console.log("UpdateAction.UpdateACL");
                         
                        if ( isBoolean(isPrivate) && isPrivate && isStringWithLength(albumId) ) {

                            var sanitizedFollowersAddList    = sanitizeStringArray(followersAddList);

                            var sanitizedfollowersDeleteList = sanitizeStringArray(followersDeleteList);


                            if (sanitizedFollowersAddList === null && sanitizedfollowersDeleteList === null) {
                                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                            } else {
                                updateACL(guid, sanitizedFollowersAddList, sanitizedfollowersDeleteList);        
                            }
                        } else {
                            finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                        }
                    } 

                    else if ( action.localeCompare("ChangeAlbumPrivacy" ) == 0) {
                        console.log("UpdateAction.UpdatePrivacy");
                        
                        if ( isBoolean(isPrivate) && isStringWithLength(albumId) ) {
                         
                            if (isPrivate) {
                                         
                                var sanitizedFollowersAddList = sanitizeStringArray(followersAddList);
                                
                                if (sanitizedFollowersAddList === null) {
                                    finalAppResponse( activeResponse(ActiveValues.Active, "Select followers to add" ));
                                } else {
                                    changeAlbumToPrivateWithACL(guid, albumId, followersAddList );
                                }
                                

                            } else {

                                changeAlbumToPublic(guid, albumId );
                            }
                        } else {
                            finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                        }
                    } 

                    // list my album ACL
                    else if ( action.localeCompare("ListACL" ) == 0) {
                        
                        getACLList(guid);
                    } 

 
                    // Upload media to my album
                    else if ( action.localeCompare("UploadMedia") == 0) {

/*
                        After user creates album, whenever user uploads new content, 
                        1) get if album is public or private
                        2) If public, get all followers. If private, get selected users
                        3) INSERT INTO timeline SET guid = ?, fguid = ?, album_id = ? ON DUPLICATE KEY UPDATE date=VALUES(date)';
                        
                
                        
                    ON delete content: update date to last media date,
                    On delete album, delete from timeline
                
    */
                    

                        // beginTransaction(guid);
                        connection.beginTransaction(function(err) {
                            if (err) { 
                                printError(error);
                                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                            } else {
                                uniqueRandomMediaUrl(guid);
                            }
                        });
                    } 

                    // Delete Media from my album
                    else if ( action.localeCompare("DeleteMedia" ) == 0) {
                        
                        startDeleteMediaTransaction(guid, albumId, mediaUrl);

                    } else {
                        finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                    } 

                // Friends functions

                } else if ( pathParams.localeCompare("/albums/private/friends" ) == 0 ) {

                    console.log('User exists, in /albums/private/friends');


                  // list friends albums
                    if ( action.localeCompare("ListFriendsAlbums" ) == 0) {
                        if ( isInt(numberOfAlbums) ) {
                            if (numberOfAlbums < 0 || numberOfAlbums > MAX_NUM_OF_ALBUMS ) {
                                numberOfAlbums = MAX_NUM_OF_ALBUMS;
                            }
                        } else {
                            numberOfAlbums = MAX_NUM_OF_ALBUMS;
                        }
                        listFollowingAlbums( guid , numberOfAlbums);
                    
                    // Get media content for public album
                    } else if ( action.localeCompare(kOpenPublicAlbum ) == 0) {

                        console.log("kOpenPublicAlbum");


                        if ( isInt(numberOfAlbums) ) {
                            if (numberOfAlbums < 0 || numberOfAlbums > MAX_NUM_OF_CONTENT ) {
                                numberOfAlbums = MAX_NUM_OF_CONTENT;
                            }
                        } else {
                            numberOfAlbums = MAX_NUM_OF_CONTENT;
                        }

                        if (typeof(startingWithNewMedia) === "boolean" && startingWithNewMedia === true) { 
                            getPublicMediaContentWithNewContent(guid, fguid, albumId, numberOfAlbums);
                            
                        } else {
                            getPublicMediaContent(fguid, albumId, numberOfAlbums);                            
                        }
                    
                    // Updates the last content viewed of friend's album
                    } else if ( action.localeCompare(kOpenPrivateAlbum) == 0) {

                        if ( isInt(numberOfAlbums) ) {
                            if (numberOfAlbums < 0 || numberOfAlbums > MAX_NUM_OF_ALBUMS ) {
                                numberOfAlbums = MAX_NUM_OF_ALBUMS;
                            }
                        } else {
                            numberOfAlbums = MAX_NUM_OF_ALBUMS;
                        }
                            // Get private album start from newestItems

                        if (typeof(startingWithNewMedia) === "boolean" && startingWithNewMedia === true) { 
                                      
                            getPrivateFolloweringUnseenMediaContent(guid, fguid, albumId, numberOfAlbums );
                            
                        } else if (typeof(getPreviousItems) === "boolean" && getPreviousItems === true) { 
                       
                            // Get private album get older media content

                            if ( !isStringWithLength(lastMediaUrl) || !isStringWithLength(lastMediaTime) ) {
                                finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));    
                                return;
                            }

                            getPrivateFolloweringPreviousMediaContent(guid, fguid, albumId, lastMediaTime, lastMediaUrl, numberOfAlbums );

                        } else {
                            // Get private album start from beginning

                            getPrivateFolloweringMediaContent(guid, fguid, albumId, lastMediaTime, lastMediaUrl, numberOfAlbums );
                        }



                    } else if ( action.localeCompare(kDidViewMedia ) == 0) {
                        console.log('User exists, kDidViewMedia');
                        
                        checkAccessPermissions(guid);
                   
                    } else if ( action.localeCompare(kBookmarked ) == 0) {
                        console.log(action);
                         bookmarkAlbum(guid, fguid, albumId);
                    } else if ( action.localeCompare(kUnbookmarked ) == 0) {
                        console.log(action);
                        unbookmarkAlbum(guid, fguid, albumId);
                    } else if ( action.localeCompare("FlagMediaInAlbum" ) == 0) {
                        
                        console.log(action);
                        
                        if ( isInt(flagType ) && flagType >= 0 && flagType < 4) {
                            flagMediaInAlbum(guid, fguid, albumId, mediaUrl, flagType);
                        } else {
                            finalAppResponse( errorResponse( ErrorMessageGeneric));
                        }
                    }  
                    

                                     



                // // open friends album // 
                // } else if (pathParams.localeCompare("/albums/private/friends/album") == 0 ) {
                    
                //     checkAccessPermissions(guid);

                // // Update friend album new media viewed
                // } else if (pathParams.localeCompare("/albums/private/friend/album/media") == 0 ) {
                    
                //     checkAccessPermissions(guid);

                // } 
                    else {
                        finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));
                    }
                } else if ( pathParams.localeCompare("/albums/private/opinion" ) == 0 ) {
                    

                    var kOpinion     = "liked";
                    var opinionValue = requestBody[kOpinion];

                    getAlbumOpinion(guid, fguid, albumId, opinionValue) 


                    // if ( action.localeCompare("Liked" ) == 0) {
                    //     likeAlbum(guid);
                    // } else if ( action.localeCompare("Disliked" ) == 0) {
                    //     dislikeAlbum(guid);
                    // } else {
                    //     neutralAlbum(guid);
                    // }

                } else if ( pathParams.localeCompare("/albums/private/viewedAlbum" ) == 0 ) {
                    
                    
                    updateAlbumViewCount(guid, fguid, albumId);

                } else {
                    finalAppResponse( activeResponse(ActiveValues.Active, ErrorMessageGeneric ));    
                }
            } else {
                finalAppResponse( activeResponse(ActiveValues.DoesNotExist, activeErrorMessage(ActiveValues.DoesNotExist) ));
            } 
        });
    }
    
    // /albums/me              list my albums
    // /albums/me/album        open my album
    // /albums/me/album        Create album
    // /albums/me/album/acl    list album ACL

    // /albums/friends               list friends albums
    // /albums/friends/album         open friends album
    // /albums/friends/album/media   Viewed new media / DromoViewedMedia
    // /albums/friends/friend  list friend albums

    // /albums/friends/friend  list friend albums

    
    queryLoggedInUser();
};